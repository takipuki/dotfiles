((buffer-size . 1241) (buffer-checksum . "87f49a60408578b8465628a320ea4a6aab287eb4"))
((emacs-buffer-undo-list nil (27 . 33) ("Fall" . 27) ((marker* . 33) . 4) ((marker) . -4) ((marker) . -4) ((marker . 27) . -3) nil (" " . 26) (27 . 28) 26 ("2" . 25) (t 26176 45563 719311 761000) (26 . 27) 25 (t 26176 45563 719311 761000) nil ("
" . -1239) ((marker) . -1) 1236 nil (1239 . 1240) (1239 . 1240) nil ("
" . -1239) ((marker* . 1241) . 1) ((marker) . -1) ("
" . -1239) ((marker) . -1) 1236 nil (nil rear-nonsticky nil 550 . 551) ("
" . -1235) (550 . 1236) 533 nil (nil rear-nonsticky nil 554 . 555) (nil fontified nil 533 . 555) (533 . 555) (532 . 533) (531 . 532) (t 26176 41803 396066 300000) 530 nil (531 . 532) 530 nil (526 . 531) (525 . 526) (524 . 525) 524 nil (62 . 520) nil (nil rear-nonsticky nil 65 . 66) (nil fontified nil 44 . 66) (44 . 66) (43 . 44) (t 26176 41493 882996 995000) 43 nil (17 . 20) (16 . 17) (5 . 16) (4 . 5) (1 . 4) (1 . 2) (t 26176 41346 420155 93000) nil ("
" . 1) ((marker . 1238) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) nil (1 . 2) (t 26176 41346 420155 93000) 1 nil ("
```c:line-numbers
#include <stdio.h>

int is_prime(int x) {
    if (x < 2) return 0;
    for (int i = 2; i <= x/2; i++)
        if (x % i == 0) return 0;
    return 1;
}

int power_of_2(int x) {
    if (x == 0) return 0;
    if (x == 1) return 1;
    if (x % 2) return 0;
    return power_of_2(x / 2);
}

int is_mersenne(int x) {
    return is_prime(x) && power_of_2(x+1);
}

int main() {
    int n; scanf(\"%d\", &n);
    puts(is_mersenne(n) ? \"YES\" : \"NO\");
}
```


## 02

:::warning
The question says to add 70 for stage 2 pokemons but the sample adds 70.
The solution follows the question.
:::

```c:line-numbers
#include <stdio.h>

struct card {
    char name[60];
    int stage;
    int HP;
};

int ends_with(char *input, char letter) {
    for (; *input != letter && *input; input++)
        ;
    return *input;
}

int main() {
    int n; scanf(\"%d\", &n);
    struct card ar[n];
    int price = 0;
    for (int i = 0; i < n; i++) {
        scanf(\" %[^\\n]\", ar[i].name);
        scanf(\"%d\", &ar[i].stage);
        scanf(\"%d\", &ar[i].HP);

        price += 50;
        price += ar[i].HP;

        if (ar[i].stage == 1)      price += 30;
        else if (ar[i].stage == 2) price += 70;

        if (ends_with(ar[i].name, 'X')) price += 200;
    }

    printf(\"%d\\n\", price);
}
```
" . 23) ((marker . 1240) . -1284) nil (11 . 15) nil ("
" . -1) nil (1 . 2) (1 . 2) nil ("
" . -1) ("
" . -1) nil (1 . 1305) (t . -1)) (emacs-pending-undo-list (nil rear-nonsticky nil 550 . 551) ("
" . -1235) (550 . 1236) 533 nil (nil rear-nonsticky nil 554 . 555) (nil fontified nil 533 . 555) (533 . 555) (532 . 533) (531 . 532) (t 26176 41803 396066 300000) 530 nil (531 . 532) 530 nil (526 . 531) (525 . 526) (524 . 525) 524 nil (62 . 520) nil (nil rear-nonsticky nil 65 . 66) (nil fontified nil 44 . 66) (44 . 66) (43 . 44) (t 26176 41493 882996 995000) 43 nil (17 . 20) (16 . 17) (5 . 16) (4 . 5) (1 . 4) (1 . 2) (t 26176 41346 420155 93000) nil ("
" . 1) ((marker . 1238) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) nil (1 . 2) (t 26176 41346 420155 93000) 1 nil ("
```c:line-numbers
#include <stdio.h>

int is_prime(int x) {
    if (x < 2) return 0;
    for (int i = 2; i <= x/2; i++)
        if (x % i == 0) return 0;
    return 1;
}

int power_of_2(int x) {
    if (x == 0) return 0;
    if (x == 1) return 1;
    if (x % 2) return 0;
    return power_of_2(x / 2);
}

int is_mersenne(int x) {
    return is_prime(x) && power_of_2(x+1);
}

int main() {
    int n; scanf(\"%d\", &n);
    puts(is_mersenne(n) ? \"YES\" : \"NO\");
}
```


## 02

:::warning
The question says to add 70 for stage 2 pokemons but the sample adds 70.
The solution follows the question.
:::

```c:line-numbers
#include <stdio.h>

struct card {
    char name[60];
    int stage;
    int HP;
};

int ends_with(char *input, char letter) {
    for (; *input != letter && *input; input++)
        ;
    return *input;
}

int main() {
    int n; scanf(\"%d\", &n);
    struct card ar[n];
    int price = 0;
    for (int i = 0; i < n; i++) {
        scanf(\" %[^\\n]\", ar[i].name);
        scanf(\"%d\", &ar[i].stage);
        scanf(\"%d\", &ar[i].HP);

        price += 50;
        price += ar[i].HP;

        if (ar[i].stage == 1)      price += 30;
        else if (ar[i].stage == 2) price += 70;

        if (ends_with(ar[i].name, 'X')) price += 200;
    }

    printf(\"%d\\n\", price);
}
```
" . 23) ((marker . 1240) . -1284) nil (11 . 15) nil ("
" . -1) nil (1 . 2) (1 . 2) nil ("
" . -1) ("
" . -1) nil (1 . 1305) (t . -1)) (emacs-undo-equiv-table (-13 . -15) (-8 . -10) (4 . -1)))