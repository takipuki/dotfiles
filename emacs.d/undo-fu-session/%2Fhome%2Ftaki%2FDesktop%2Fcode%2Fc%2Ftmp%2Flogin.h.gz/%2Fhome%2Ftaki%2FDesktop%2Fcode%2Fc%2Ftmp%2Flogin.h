((buffer-size . 618) (buffer-checksum . "f5f0b07530f43a5bf5b65d99bab7f75f3a217a74"))
((emacs-buffer-undo-list (618 . 619) 1 nil ("
" . 1) ((marker* . 1) . 1) ((marker) . -1) nil ("#if
" . 1) ((marker . 1) . -3) ((marker . 1) . -3) ((marker* . 1) . 1) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -3) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker) . -4) 3 nil ("n" . -4) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker) . -1) ("d" . -5) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker) . -1) ("e" . -6) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker) . -1) ("f" . -7) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker) . -1) (" " . -8) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker) . -1) 9 (2 . 9) (1 . 2) ("#" . -1) ((marker . 1) . -1) 2 (1 . 2) (1 . 2) nil (1 . 2) (1 . 2) nil ("" . -469) (469 . 470) ("" . -420) (420 . 421) ("" . -404) (404 . 405) ("" . -387) (387 . 388) ("" . -348) (348 . 349) ("" . -331) (331 . 332) ("" . -296) (296 . 297) ("" . -264) (264 . 265) ("" . -200) (200 . 201) nil ("
" . -200) ((marker . 1) . -1) 136 nil (201 . 202) ("    " . 201) ((marker . 1) . -4) nil (201 . 205) ("
" . -201) ((marker . 1) . -1) nil ("
" . -264) ((marker) . -1) 202 nil ("
" . 297) ((marker) . -1) nil ("
" . 348) ((marker) . -1) nil ("

" . 403) ((marker . 472) . -1) ((marker . 1) . -1) ((marker . 407) . -1) ((marker . 471) . -1) ((marker . 1) . -1) ((marker) . -1) ((marker) . -1) ((marker) . -2) 404 nil ("    " . -420) ((marker . 423) . -4) ((marker . 423) . -4) ((marker . 423) . -4) ((marker . 423) . -4) ((marker . 423) . -4) ((marker . 423) . -4) ((marker . 423) . -4) ((marker . 423) . -4) nil ("    " . -472) ((marker . 472) . -4) ((marker . 472) . -4) ((marker . 472) . -4) ((marker . 472) . -4) ((marker . 1) . -4) ((marker . 472) . -4) ((marker . 472) . -4) ((marker . 472) . -4) ((marker . 472) . -4) ((marker . 472) . -4) ((marker) . -4) 476 (471 . 476) 424 nil (420 . 424) ("
" . -420) ((marker) . -1) nil (nil rear-nonsticky nil 468 . 469) ("
" . -614) (468 . 615) 421 nil ("//***************************************** Count the number of lines in the file to determine the number of users*******************************
" . 404) ((marker . 1) . -145) nil ("
{
    initscr();
    clear();
    cbreak();
    start_color();
    init_pair(1, COLOR_BLACK, COLOR_WHITE);
    init_pair(2, COLOR_RED, COLOR_WHITE);
    init_pair(3, COLOR_YELLOW, COLOR_GREEN);
    init_pair(4, COLOR_BLUE, COLOR_RED);
    init_pair(5, COLOR_WHITE, COLOR_MAGENTA);
    init_pair(6, COLOR_CYAN, COLOR_GREEN);
    int yMax, xMax;
    getmaxyx(stdscr, yMax, xMax);
    WINDOW *win = newwin(10, xMax / 3, yMax / 4, xMax / 3);
    box(win, 0, 0);
    refresh();
    wrefresh(win);

    FILE *file = fopen(\"input.txt\", \"r\");
    FILE *temp = fopen(\"temp.txt\", \"w\");
    if (file == NULL)
    {
        return;
    }

    bool flag = FALSE;
    char line[100];
    while (fgets(line, sizeof(line), file) != NULL)
    {
        line[strcspn(line, \"\\n\")] = '\\0';
        if (strcmp(line, username) == 0)
        {
            fgets(line, sizeof(line), file);
            line[strcspn(line, \"\\n\")] = '\\0';
            if (strcmp(line, password) == 0)
            {
                flag = TRUE;
            }
            else
            {
                fprintf(temp, \"%s\\n%s\\n\", username, line);
            }
        }
        else
        {
            fprintf(temp, \"%s\\n\", line);
        }
    }

    if (flag)
    {
        wattron(win, COLOR_PAIR(3) | A_BOLD);
        mvwprintw(win, 1, 5, \"Password Removed Successfully!\");
        wattroff(win, COLOR_PAIR(3) | A_BOLD);
        wrefresh(win);
        mvwprintw(win, 3, 5, \"Press Any Key to Back To The Previous Menu\");
        wrefresh(win);
    }
    else
    {
        wattron(win, COLOR_PAIR(2) | A_BOLD);
        mvwprintw(win, 1, xMax / 8, \"  Password Not Found!  \");
        wattroff(win, COLOR_PAIR(2) | A_BOLD);
        wrefresh(win);
        wattron(win, COLOR_PAIR(4) | A_BOLD);
        mvwprintw(win, 3, 18, \"  Press Any Key to Back To The Previous Menu  \");
        wattroff(win, COLOR_PAIR(4) | A_BOLD);
        wrefresh(win);
    }

    fclose(file);
    fclose(temp);
    remove(\"input.txt\");
    rename(\"temp.txt\", \"input.txt\");
    getch();
    clear();
    refresh();
    delwin(win);
    endwin();
}" . 614) ((marker . 1) . -1) ((marker . 1) . -2084) ((marker . 1) . -1) 615 nil ("{
    initscr();
    clear();
    cbreak();
    start_color();
    init_pair(1, COLOR_BLACK, COLOR_WHITE);
    init_pair(2, COLOR_RED, COLOR_WHITE);
    init_pair(3, COLOR_YELLOW, COLOR_GREEN);
    init_pair(4, COLOR_BLUE, COLOR_RED);
    init_pair(5, COLOR_WHITE, COLOR_MAGENTA);
    init_pair(6, COLOR_CYAN, COLOR_GREEN);
    int yMax, xMax;
    getmaxyx(stdscr, yMax, xMax);
    refresh();
    int wndw_Line = yMax - 5;
    FILE *file = fopen(\"input.txt\", \"r\");
    if (file == NULL)
    {
        return;
    }

    WINDOW *win = newwin(yMax - 2, xMax - 5, 1, 1);
    box(win, 0, 0);
    refresh();
    wrefresh(win);
    char line[100];
    int track_count = 1;
    int i = 1;
    int page_count = 1;
    mvwprintw(win, yMax - 8, xMax / 2 - 2, \"Page: %d\", page_count);
    wrefresh(win);
    while (fgets(line, sizeof(line), file) != NULL)
    {
        wattron(win, COLOR_PAIR(6) | A_BOLD);
        mvwprintw(win, 1, xMax / 2 - 2, \"  All Passwords  \");
        wattroff(win, COLOR_PAIR(6) | A_BOLD);
        line[strcspn(line, \"\\n\")] = '\\0';
        mvwprintw(win, i + 1, 1, \"User %d: %s\", track_count, line);
        wrefresh(win);
        if (fgets(line, sizeof(line), file) == NULL)
            break;
        line[strcspn(line, \"\\n\")] = '\\0';
        mvwprintw(win, i + 2, 1, \"Pass %d: %s\", track_count, line);
        wrefresh(win);
        track_count++;

        i += 3;
        if (i >= wndw_Line - 3)
        {
            page_count++;
            getch();
            wclear(win);
            box(win, 0, 0);
            wrefresh(win);
            i = 1;
            mvwprintw(win, yMax - 8, xMax / 2 - 2, \"Page: %d\", page_count);
            wrefresh(win);
        }
    }
    mvwprintw(win, yMax - 6, xMax / 2 - 2, \"End of File Reached!\");
    wrefresh(win);
    mvwprintw(win, yMax - 4, xMax / 2 - 2, \"Press Any Key to Continue ......\");
    wrefresh(win);

    fclose(file);
    getch();
    clear();
    refresh();
    delwin(win);
    endwin();
}
" . 566) ((marker . 1) . -1969) ((marker) . -1969) ((marker . 423) . -1968) ((marker . 423) . -1969) nil ("{
    initscr();
    int yMax, xMax;
    getmaxyx(stdscr, yMax, xMax);
    cbreak();
    curs_set(1);
    clear();
    WINDOW *win = newwin(yMax / 4 + 2, xMax / 2, yMax / 4, xMax / 4);
    box(win, 0, 0);
    refresh();

    wrefresh(win);
    wattron(win, COLOR_PAIR(6) | A_BOLD);
    mvwprintw(win, 1, xMax / 6 + 10, \"  Saving Password  \");
    wattroff(win, COLOR_PAIR(6) | A_BOLD);
    wrefresh(win);
    User pass;
    mvwprintw(win, 3, 2, \"Enter Username: \");
    wrefresh(win);
    mvwgetstr(win, 3, 18, pass.username);
    mvwprintw(win, 5, 2, \"Password: \");
    wrefresh(win);
    mvwgetstr(win, 5, 12, pass.password);
    wrefresh(win);
    FILE *file = fopen(\"input.txt\", \"a\");
    bool prompt_Success = FALSE;
    if (file != NULL && pass.username[0] != '\\0' && pass.password[0] != '\\0' && pass.username[0] != '\\n' && pass.password[0] != '\\n')
    {
        fprintf(file, \"%s\\n%s\\n\", pass.username, pass.password);
        fclose(file);
        prompt_Success = TRUE;
    }
    if (prompt_Success == FALSE)
    {
        refresh();

        wattron(win, COLOR_PAIR(2) | A_BOLD);
        mvwprintw(win, yMax / 4 - 5, xMax / 6 + 10, \"  Error Saving Password!  \");
        wattroff(win, COLOR_PAIR(2) | A_BOLD);
        wrefresh(win);
        wattron(win, COLOR_PAIR(4) | A_BOLD | A_REVERSE);
        mvwprintw(win, yMax / 4 - 3, xMax / 6 + 4, \"  Please Use non-empty Username and Password  \");
        wattroff(win, COLOR_PAIR(4) | A_BOLD | A_REVERSE);
        wattron(win, COLOR_PAIR(3) | A_BOLD | A_REVERSE);
        mvwprintw(win, yMax / 4 - 1, xMax / 6 + 10, \"  Press Any Key to Exit...  \");
        wattroff(win, COLOR_PAIR(3) | A_BOLD | A_REVERSE);
        wrefresh(win);

        refresh();
    }
    else
    {

        wattron(win, COLOR_PAIR(3) | A_BOLD);
        mvwprintw(win, yMax / 4 - 5, xMax / 6 + 10, \"  Password Saved Successfully!  \");
        wattroff(win, COLOR_PAIR(3) | A_BOLD);
        wrefresh(win);
        wattron(win, COLOR_PAIR(3) | A_BOLD | A_REVERSE);
        mvwprintw(win, yMax / 4 - 3, xMax / 6 + 12, \"  Press Any Key to Exit..  \");
        wattroff(win, COLOR_PAIR(3) | A_BOLD | A_REVERSE);
        wrefresh(win);
    }
    getch();
    clear();
    refresh();
    delwin(win); // Delete the wind
    return pass;

    endwin();
}
" . 403) ((marker . 1) . -2275) ((marker) . -2275) ((marker . 407) . -2274) ((marker . 407) . -2275) nil ("{
    initscr();
    clear();
    cbreak();
    start_color();
    init_pair(1, COLOR_BLACK, COLOR_WHITE);
    init_pair(2, COLOR_RED, COLOR_WHITE);
    init_pair(3, COLOR_YELLOW, COLOR_GREEN);
    init_pair(4, COLOR_BLUE, COLOR_RED);
    init_pair(5, COLOR_WHITE, COLOR_MAGENTA);
    init_pair(6, COLOR_CYAN, COLOR_GREEN);
    int yMax, xMax;
    getmaxyx(stdscr, yMax, xMax);
    refresh();
    int wndw_Line = yMax - 5;
    FILE *file = fopen(\"input.txt\", \"r\");
    if (file == NULL)
    {
        return;
    }

    WINDOW *win = newwin(yMax - 2, xMax / 2, 2, xMax / 3);
    box(win, 0, 0);
    refresh();
    wrefresh(win);
    char line[100];
    bool flag = FALSE;
    int windw_Line = yMax - 5;
    int page_count = 1;
    mvwprintw(win, yMax - 9, xMax / 5 - 2, \"Page: %d\", page_count);
    wrefresh(win);
    int i = 6;
    while (fgets(line, sizeof(line), file) != NULL)
    {
        line[strcspn(line, \"\\n\")] = '\\0';
        if (strcmp(line, userName) == 0)
        {
            wattron(win, COLOR_PAIR(6) | A_BOLD);
            mvwprintw(win, 1, 15, \"  Password Found  \");
            wattroff(win, COLOR_PAIR(6) | A_BOLD);
            wrefresh(win);
            mvwprintw(win, i, 15, \"UserName: %s  \", userName);
            wrefresh(win);
            fgets(line, sizeof(line), file);
            line[strcspn(line, \"\\n\")] = '\\0';
            mvwprintw(win, i + 2, 15, \"Password: %s\", line);
            wrefresh(win);
            i += 4;
            flag = TRUE;
            if (i >= wndw_Line - 3)
            {
                page_count++;
                getch();
                wclear(win);
                box(win, 0, 0);
                wrefresh(win);
                i = 6;
                mvwprintw(win, yMax - 8, xMax / 5 - 2, \"Page: %d\", page_count);
                wrefresh(win);
            }
        }
    }
    if (flag == FALSE)
    {
        clear();
        refresh();
        WINDOW *win2 = newwin(yMax / 4, xMax / 4, yMax / 3, xMax / 2 - 10);
        box(win2, 0, 0);
        mvwprintw(win2, 1, 10, \"UserName: %s  \", userName);
        wrefresh(win2);
        wattron(win2, COLOR_PAIR(2) | A_BOLD);
        mvwprintw(win2, 3, 7, \"  Password Not Found ! ! ! !\");
        wattroff(win2, COLOR_PAIR(2) | A_BOLD);
        wrefresh(win2);
        delwin(win2);
    }
    else
    {
        mvwprintw(win, yMax - 7, xMax / 4 - 15, \"End of File Reached!\");
        wrefresh(win);
        wattron(win, COLOR_PAIR(3) | A_BOLD | A_REVERSE);
        mvwprintw(win, yMax - 5, xMax / 4 - 15, \"  Press Any Key to Exit..  \");
        wattroff(win, COLOR_PAIR(3) | A_BOLD | A_REVERSE);
        wrefresh(win);
    }
    getch();
    clear();
    refresh();
    delwin(win);
    endwin();
}
" . 387) ((marker . 1) . -2710) ((marker) . -2710) ((marker . 390) . -2709) ((marker . 390) . -2710) nil ("{
    User pass;
    FILE *file = fopen(\"users.txt\", \"r\");
    if (file != NULL)
    {
        char line[100];
        while (fgets(line, sizeof(line), file) != NULL)
        {
            line[strcspn(line, \"\\n\")] = '\\0';
            // Check if the line contains the username
            if (strstr(line, \"admin\") != NULL)
            {
                // Check if the next line contains the password
                fgets(line, sizeof(line), file);
                strcpy(pass.password, line);
                break;
            }
        }
        // Close the file
        fclose(file);
    }
    return pass;
}
" . 348) ((marker . 1) . -616) ((marker) . -616) nil ("{

    User pass;
    const char charset[] = \"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@#&!$*\";
    const int charset_length = sizeof(charset) - 1;
    srand(time(NULL)); // Seed the random number generator
    for (int i = 0; i < length; i++)
    {
        int index = rand() % charset_length;
        pass.password[i] = charset[index];
    }

    return pass;
}
" . 332) ((marker . 1) . -384) ((marker) . -384) nil ("{
    int len = strlen(str);
    if (len > 0 && str[len - 1] == '\\n')
    {
        str[len - 1] = '\\0';
    }
}
" . 297) ((marker . 1) . -112) ((marker) . -112) nil ("{
    User matched_user = {\"\", \"\"}; // Initialize to empty strings

    // If username or password is empty, return an empty User
    if (username[0] == '\\0' || password[0] == '\\0')
    {
        return matched_user;
    }

    FILE *file = fopen(\"users.txt\", OpenMode);
    if (file != NULL)
    {
        char line[100];
        while (fgets(line, sizeof(line), file))
        {
            line[strcspn(line, \"\\n\")] = '\\0';
            if (strcmp(line, username) == 0)
            {
                if (fgets(line, sizeof(line), file) == NULL)
                {
                    break; // fgets failed, break the loop
                }
                line[strcspn(line, \"\\n\")] = '\\0';
                if (strcmp(line, password) == 0)
                {
                    strcpy(matched_user.username, username);
                    strcpy(matched_user.password, password);
                    break;
                }
            }
        }
        fclose(file);
    }
    return matched_user;
}
" . 265) ((marker . 1) . -1004) ((marker) . -1004) nil ("{
    User new_user;
    strcpy(new_user.username, username);
    strcpy(new_user.password, password);
    // Open the file in append mode to add new entries without overwriting existing ones
    FILE *file = fopen(\"users.txt\", OpenMode);
    if (file != NULL)
    {
        // Write the username and password to the file
        fprintf(file, \"%s\\n%s\\n\", new_user.username, new_user.password);
        // Close the file
        fclose(file);
    }
    return new_user;
}
" . 201) ((marker . 1) . -471) ((marker) . -471) nil ("
" . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker) . -1) nil (nil rear-nonsticky nil 1 . 2) ("
" . -12249) (1 . 12250) (t . -1)) (emacs-pending-undo-list ("
" . -264) ((marker) . -1) 202 nil ("
" . 297) ((marker) . -1) nil ("
" . 348) ((marker) . -1) nil ("

" . 403) ((marker . 472) . -1) ((marker . 1) . -1) ((marker . 407) . -1) ((marker . 471) . -1) ((marker . 1) . -1) ((marker) . -1) ((marker) . -1) ((marker) . -2) 404 nil ("    " . -420) ((marker . 423) . -4) ((marker . 423) . -4) ((marker . 423) . -4) ((marker . 423) . -4) ((marker . 423) . -4) ((marker . 423) . -4) ((marker . 423) . -4) ((marker . 423) . -4) nil ("    " . -472) ((marker . 472) . -4) ((marker . 472) . -4) ((marker . 472) . -4) ((marker . 472) . -4) ((marker . 1) . -4) ((marker . 472) . -4) ((marker . 472) . -4) ((marker . 472) . -4) ((marker . 472) . -4) ((marker . 472) . -4) ((marker) . -4) 476 (471 . 476) 424 nil (420 . 424) ("
" . -420) ((marker) . -1) nil (nil rear-nonsticky nil 468 . 469) ("
" . -614) (468 . 615) 421 nil ("//***************************************** Count the number of lines in the file to determine the number of users*******************************
" . 404) ((marker . 1) . -145) nil ("
{
    initscr();
    clear();
    cbreak();
    start_color();
    init_pair(1, COLOR_BLACK, COLOR_WHITE);
    init_pair(2, COLOR_RED, COLOR_WHITE);
    init_pair(3, COLOR_YELLOW, COLOR_GREEN);
    init_pair(4, COLOR_BLUE, COLOR_RED);
    init_pair(5, COLOR_WHITE, COLOR_MAGENTA);
    init_pair(6, COLOR_CYAN, COLOR_GREEN);
    int yMax, xMax;
    getmaxyx(stdscr, yMax, xMax);
    WINDOW *win = newwin(10, xMax / 3, yMax / 4, xMax / 3);
    box(win, 0, 0);
    refresh();
    wrefresh(win);

    FILE *file = fopen(\"input.txt\", \"r\");
    FILE *temp = fopen(\"temp.txt\", \"w\");
    if (file == NULL)
    {
        return;
    }

    bool flag = FALSE;
    char line[100];
    while (fgets(line, sizeof(line), file) != NULL)
    {
        line[strcspn(line, \"\\n\")] = '\\0';
        if (strcmp(line, username) == 0)
        {
            fgets(line, sizeof(line), file);
            line[strcspn(line, \"\\n\")] = '\\0';
            if (strcmp(line, password) == 0)
            {
                flag = TRUE;
            }
            else
            {
                fprintf(temp, \"%s\\n%s\\n\", username, line);
            }
        }
        else
        {
            fprintf(temp, \"%s\\n\", line);
        }
    }

    if (flag)
    {
        wattron(win, COLOR_PAIR(3) | A_BOLD);
        mvwprintw(win, 1, 5, \"Password Removed Successfully!\");
        wattroff(win, COLOR_PAIR(3) | A_BOLD);
        wrefresh(win);
        mvwprintw(win, 3, 5, \"Press Any Key to Back To The Previous Menu\");
        wrefresh(win);
    }
    else
    {
        wattron(win, COLOR_PAIR(2) | A_BOLD);
        mvwprintw(win, 1, xMax / 8, \"  Password Not Found!  \");
        wattroff(win, COLOR_PAIR(2) | A_BOLD);
        wrefresh(win);
        wattron(win, COLOR_PAIR(4) | A_BOLD);
        mvwprintw(win, 3, 18, \"  Press Any Key to Back To The Previous Menu  \");
        wattroff(win, COLOR_PAIR(4) | A_BOLD);
        wrefresh(win);
    }

    fclose(file);
    fclose(temp);
    remove(\"input.txt\");
    rename(\"temp.txt\", \"input.txt\");
    getch();
    clear();
    refresh();
    delwin(win);
    endwin();
}" . 614) ((marker . 1) . -1) ((marker . 1) . -2084) ((marker . 1) . -1) 615 nil ("{
    initscr();
    clear();
    cbreak();
    start_color();
    init_pair(1, COLOR_BLACK, COLOR_WHITE);
    init_pair(2, COLOR_RED, COLOR_WHITE);
    init_pair(3, COLOR_YELLOW, COLOR_GREEN);
    init_pair(4, COLOR_BLUE, COLOR_RED);
    init_pair(5, COLOR_WHITE, COLOR_MAGENTA);
    init_pair(6, COLOR_CYAN, COLOR_GREEN);
    int yMax, xMax;
    getmaxyx(stdscr, yMax, xMax);
    refresh();
    int wndw_Line = yMax - 5;
    FILE *file = fopen(\"input.txt\", \"r\");
    if (file == NULL)
    {
        return;
    }

    WINDOW *win = newwin(yMax - 2, xMax - 5, 1, 1);
    box(win, 0, 0);
    refresh();
    wrefresh(win);
    char line[100];
    int track_count = 1;
    int i = 1;
    int page_count = 1;
    mvwprintw(win, yMax - 8, xMax / 2 - 2, \"Page: %d\", page_count);
    wrefresh(win);
    while (fgets(line, sizeof(line), file) != NULL)
    {
        wattron(win, COLOR_PAIR(6) | A_BOLD);
        mvwprintw(win, 1, xMax / 2 - 2, \"  All Passwords  \");
        wattroff(win, COLOR_PAIR(6) | A_BOLD);
        line[strcspn(line, \"\\n\")] = '\\0';
        mvwprintw(win, i + 1, 1, \"User %d: %s\", track_count, line);
        wrefresh(win);
        if (fgets(line, sizeof(line), file) == NULL)
            break;
        line[strcspn(line, \"\\n\")] = '\\0';
        mvwprintw(win, i + 2, 1, \"Pass %d: %s\", track_count, line);
        wrefresh(win);
        track_count++;

        i += 3;
        if (i >= wndw_Line - 3)
        {
            page_count++;
            getch();
            wclear(win);
            box(win, 0, 0);
            wrefresh(win);
            i = 1;
            mvwprintw(win, yMax - 8, xMax / 2 - 2, \"Page: %d\", page_count);
            wrefresh(win);
        }
    }
    mvwprintw(win, yMax - 6, xMax / 2 - 2, \"End of File Reached!\");
    wrefresh(win);
    mvwprintw(win, yMax - 4, xMax / 2 - 2, \"Press Any Key to Continue ......\");
    wrefresh(win);

    fclose(file);
    getch();
    clear();
    refresh();
    delwin(win);
    endwin();
}
" . 566) ((marker . 1) . -1969) ((marker) . -1969) ((marker . 423) . -1968) ((marker . 423) . -1969) nil ("{
    initscr();
    int yMax, xMax;
    getmaxyx(stdscr, yMax, xMax);
    cbreak();
    curs_set(1);
    clear();
    WINDOW *win = newwin(yMax / 4 + 2, xMax / 2, yMax / 4, xMax / 4);
    box(win, 0, 0);
    refresh();

    wrefresh(win);
    wattron(win, COLOR_PAIR(6) | A_BOLD);
    mvwprintw(win, 1, xMax / 6 + 10, \"  Saving Password  \");
    wattroff(win, COLOR_PAIR(6) | A_BOLD);
    wrefresh(win);
    User pass;
    mvwprintw(win, 3, 2, \"Enter Username: \");
    wrefresh(win);
    mvwgetstr(win, 3, 18, pass.username);
    mvwprintw(win, 5, 2, \"Password: \");
    wrefresh(win);
    mvwgetstr(win, 5, 12, pass.password);
    wrefresh(win);
    FILE *file = fopen(\"input.txt\", \"a\");
    bool prompt_Success = FALSE;
    if (file != NULL && pass.username[0] != '\\0' && pass.password[0] != '\\0' && pass.username[0] != '\\n' && pass.password[0] != '\\n')
    {
        fprintf(file, \"%s\\n%s\\n\", pass.username, pass.password);
        fclose(file);
        prompt_Success = TRUE;
    }
    if (prompt_Success == FALSE)
    {
        refresh();

        wattron(win, COLOR_PAIR(2) | A_BOLD);
        mvwprintw(win, yMax / 4 - 5, xMax / 6 + 10, \"  Error Saving Password!  \");
        wattroff(win, COLOR_PAIR(2) | A_BOLD);
        wrefresh(win);
        wattron(win, COLOR_PAIR(4) | A_BOLD | A_REVERSE);
        mvwprintw(win, yMax / 4 - 3, xMax / 6 + 4, \"  Please Use non-empty Username and Password  \");
        wattroff(win, COLOR_PAIR(4) | A_BOLD | A_REVERSE);
        wattron(win, COLOR_PAIR(3) | A_BOLD | A_REVERSE);
        mvwprintw(win, yMax / 4 - 1, xMax / 6 + 10, \"  Press Any Key to Exit...  \");
        wattroff(win, COLOR_PAIR(3) | A_BOLD | A_REVERSE);
        wrefresh(win);

        refresh();
    }
    else
    {

        wattron(win, COLOR_PAIR(3) | A_BOLD);
        mvwprintw(win, yMax / 4 - 5, xMax / 6 + 10, \"  Password Saved Successfully!  \");
        wattroff(win, COLOR_PAIR(3) | A_BOLD);
        wrefresh(win);
        wattron(win, COLOR_PAIR(3) | A_BOLD | A_REVERSE);
        mvwprintw(win, yMax / 4 - 3, xMax / 6 + 12, \"  Press Any Key to Exit..  \");
        wattroff(win, COLOR_PAIR(3) | A_BOLD | A_REVERSE);
        wrefresh(win);
    }
    getch();
    clear();
    refresh();
    delwin(win); // Delete the wind
    return pass;

    endwin();
}
" . 403) ((marker . 1) . -2275) ((marker) . -2275) ((marker . 407) . -2274) ((marker . 407) . -2275) nil ("{
    initscr();
    clear();
    cbreak();
    start_color();
    init_pair(1, COLOR_BLACK, COLOR_WHITE);
    init_pair(2, COLOR_RED, COLOR_WHITE);
    init_pair(3, COLOR_YELLOW, COLOR_GREEN);
    init_pair(4, COLOR_BLUE, COLOR_RED);
    init_pair(5, COLOR_WHITE, COLOR_MAGENTA);
    init_pair(6, COLOR_CYAN, COLOR_GREEN);
    int yMax, xMax;
    getmaxyx(stdscr, yMax, xMax);
    refresh();
    int wndw_Line = yMax - 5;
    FILE *file = fopen(\"input.txt\", \"r\");
    if (file == NULL)
    {
        return;
    }

    WINDOW *win = newwin(yMax - 2, xMax / 2, 2, xMax / 3);
    box(win, 0, 0);
    refresh();
    wrefresh(win);
    char line[100];
    bool flag = FALSE;
    int windw_Line = yMax - 5;
    int page_count = 1;
    mvwprintw(win, yMax - 9, xMax / 5 - 2, \"Page: %d\", page_count);
    wrefresh(win);
    int i = 6;
    while (fgets(line, sizeof(line), file) != NULL)
    {
        line[strcspn(line, \"\\n\")] = '\\0';
        if (strcmp(line, userName) == 0)
        {
            wattron(win, COLOR_PAIR(6) | A_BOLD);
            mvwprintw(win, 1, 15, \"  Password Found  \");
            wattroff(win, COLOR_PAIR(6) | A_BOLD);
            wrefresh(win);
            mvwprintw(win, i, 15, \"UserName: %s  \", userName);
            wrefresh(win);
            fgets(line, sizeof(line), file);
            line[strcspn(line, \"\\n\")] = '\\0';
            mvwprintw(win, i + 2, 15, \"Password: %s\", line);
            wrefresh(win);
            i += 4;
            flag = TRUE;
            if (i >= wndw_Line - 3)
            {
                page_count++;
                getch();
                wclear(win);
                box(win, 0, 0);
                wrefresh(win);
                i = 6;
                mvwprintw(win, yMax - 8, xMax / 5 - 2, \"Page: %d\", page_count);
                wrefresh(win);
            }
        }
    }
    if (flag == FALSE)
    {
        clear();
        refresh();
        WINDOW *win2 = newwin(yMax / 4, xMax / 4, yMax / 3, xMax / 2 - 10);
        box(win2, 0, 0);
        mvwprintw(win2, 1, 10, \"UserName: %s  \", userName);
        wrefresh(win2);
        wattron(win2, COLOR_PAIR(2) | A_BOLD);
        mvwprintw(win2, 3, 7, \"  Password Not Found ! ! ! !\");
        wattroff(win2, COLOR_PAIR(2) | A_BOLD);
        wrefresh(win2);
        delwin(win2);
    }
    else
    {
        mvwprintw(win, yMax - 7, xMax / 4 - 15, \"End of File Reached!\");
        wrefresh(win);
        wattron(win, COLOR_PAIR(3) | A_BOLD | A_REVERSE);
        mvwprintw(win, yMax - 5, xMax / 4 - 15, \"  Press Any Key to Exit..  \");
        wattroff(win, COLOR_PAIR(3) | A_BOLD | A_REVERSE);
        wrefresh(win);
    }
    getch();
    clear();
    refresh();
    delwin(win);
    endwin();
}
" . 387) ((marker . 1) . -2710) ((marker) . -2710) ((marker . 390) . -2709) ((marker . 390) . -2710) nil ("{
    User pass;
    FILE *file = fopen(\"users.txt\", \"r\");
    if (file != NULL)
    {
        char line[100];
        while (fgets(line, sizeof(line), file) != NULL)
        {
            line[strcspn(line, \"\\n\")] = '\\0';
            // Check if the line contains the username
            if (strstr(line, \"admin\") != NULL)
            {
                // Check if the next line contains the password
                fgets(line, sizeof(line), file);
                strcpy(pass.password, line);
                break;
            }
        }
        // Close the file
        fclose(file);
    }
    return pass;
}
" . 348) ((marker . 1) . -616) ((marker) . -616) nil ("{

    User pass;
    const char charset[] = \"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@#&!$*\";
    const int charset_length = sizeof(charset) - 1;
    srand(time(NULL)); // Seed the random number generator
    for (int i = 0; i < length; i++)
    {
        int index = rand() % charset_length;
        pass.password[i] = charset[index];
    }

    return pass;
}
" . 332) ((marker . 1) . -384) ((marker) . -384) nil ("{
    int len = strlen(str);
    if (len > 0 && str[len - 1] == '\\n')
    {
        str[len - 1] = '\\0';
    }
}
" . 297) ((marker . 1) . -112) ((marker) . -112) nil ("{
    User matched_user = {\"\", \"\"}; // Initialize to empty strings

    // If username or password is empty, return an empty User
    if (username[0] == '\\0' || password[0] == '\\0')
    {
        return matched_user;
    }

    FILE *file = fopen(\"users.txt\", OpenMode);
    if (file != NULL)
    {
        char line[100];
        while (fgets(line, sizeof(line), file))
        {
            line[strcspn(line, \"\\n\")] = '\\0';
            if (strcmp(line, username) == 0)
            {
                if (fgets(line, sizeof(line), file) == NULL)
                {
                    break; // fgets failed, break the loop
                }
                line[strcspn(line, \"\\n\")] = '\\0';
                if (strcmp(line, password) == 0)
                {
                    strcpy(matched_user.username, username);
                    strcpy(matched_user.password, password);
                    break;
                }
            }
        }
        fclose(file);
    }
    return matched_user;
}
" . 265) ((marker . 1) . -1004) ((marker) . -1004) nil ("{
    User new_user;
    strcpy(new_user.username, username);
    strcpy(new_user.password, password);
    // Open the file in append mode to add new entries without overwriting existing ones
    FILE *file = fopen(\"users.txt\", OpenMode);
    if (file != NULL)
    {
        // Write the username and password to the file
        fprintf(file, \"%s\\n%s\\n\", new_user.username, new_user.password);
        // Close the file
        fclose(file);
    }
    return new_user;
}
" . 201) ((marker . 1) . -471) ((marker) . -471) nil ("
" . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker) . -1) nil (nil rear-nonsticky nil 1 . 2) ("
" . -12249) (1 . 12250) (t . -1)) (emacs-undo-equiv-table (7 . -1)))