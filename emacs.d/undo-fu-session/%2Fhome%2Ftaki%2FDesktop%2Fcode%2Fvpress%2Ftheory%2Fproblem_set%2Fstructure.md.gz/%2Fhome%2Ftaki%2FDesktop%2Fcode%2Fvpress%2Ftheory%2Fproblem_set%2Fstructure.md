((buffer-size . 5888) (buffer-checksum . "511f4a36fe0d9a5f03a65b72e0006bb4c2e5f268"))
((emacs-buffer-undo-list nil ("#+SETUPFILE: \"../../setup.org\"
#+OPTIONS: toc:t
" . 1) ((marker . 1) . -47) ((marker . 1) . -31) ((marker . 1) . -31) ((marker . 1) . -31) ((marker) . -31) ((marker) . -31) ((marker) . -48) 32 (t 26160 52473 876500 473000) nil (nil markdown-gfm-code (5447 5946) 5436 . 5437) (nil markdown-metadata-markup (5448 5462 5448 5449 5449 5450 5450 5462 #<buffer structure.md>) 5436 . 5437) (nil face (markdown-pre-face markdown-code-face) 5436 . 5437) (nil font-lock-multiline t 5436 . 5437) (nil markdown-gfm-code (5447 5946) 5435 . 5436) (nil markdown-metadata-key (5448 5462 5448 5449 5449 5450 5450 5462 #<buffer structure.md>) 5435 . 5436) (nil face (markdown-pre-face markdown-code-face) 5435 . 5436) (nil font-lock-multiline t 5435 . 5436) ("
c:" . -5435) (5438 . 5440) (nil markdown-gfm-code (4944 5432) 4933 . 4934) (nil markdown-metadata-markup (4944 4958 4944 4945 4945 4946 4946 4958 #<buffer structure.md>) 4933 . 4934) (nil face (markdown-pre-face markdown-code-face) 4933 . 4934) (nil font-lock-multiline t 4933 . 4934) (nil markdown-gfm-code (4944 5432) 4932 . 4933) (nil markdown-metadata-key (4944 4958 4944 4945 4945 4946 4946 4958 #<buffer structure.md>) 4932 . 4933) (nil face (markdown-pre-face markdown-code-face) 4932 . 4933) (nil font-lock-multiline t 4932 . 4933) ("
c:" . -4932) (4935 . 4937) (nil markdown-gfm-code (4481 4928) 4471 . 4472) (nil markdown-metadata-markup (4481 4495 4481 4482 4482 4483 4483 4495 #<buffer structure.md>) 4471 . 4472) (nil face (markdown-pre-face markdown-code-face) 4471 . 4472) (nil font-lock-multiline t 4471 . 4472) (nil markdown-gfm-code (4481 4928) 4470 . 4471) (nil markdown-metadata-key (4481 4495 4481 4482 4482 4483 4483 4495 #<buffer structure.md>) 4470 . 4471) (nil face (markdown-pre-face markdown-code-face) 4470 . 4471) (nil font-lock-multiline t 4470 . 4471) ("
c:" . -4470) (4473 . 4475) (nil markdown-gfm-code (4208 4465) 4199 . 4200) (nil markdown-metadata-markup (4208 4222 4208 4209 4209 4210 4210 4222 #<buffer structure.md>) 4199 . 4200) (nil face (markdown-pre-face markdown-code-face) 4199 . 4200) (nil font-lock-multiline t 4199 . 4200) (nil markdown-gfm-code (4208 4465) 4198 . 4199) (nil markdown-metadata-key (4208 4222 4208 4209 4209 4210 4210 4222 #<buffer structure.md>) 4198 . 4199) (nil face (markdown-pre-face markdown-code-face) 4198 . 4199) (nil font-lock-multiline t 4198 . 4199) ("
c:" . -4198) (4201 . 4203) (nil markdown-gfm-code (3375 4192) 3368 . 3369) (nil markdown-metadata-markup (3376 3390 3376 3377 3377 3378 3378 3390 #<buffer structure.md>) 3368 . 3369) (nil face (markdown-pre-face markdown-code-face) 3368 . 3369) (nil font-lock-multiline t 3368 . 3369) (nil markdown-gfm-code (3375 4192) 3367 . 3368) (nil markdown-metadata-key (3376 3390 3376 3377 3377 3378 3378 3390 #<buffer structure.md>) 3367 . 3368) (nil face (markdown-pre-face markdown-code-face) 3367 . 3368) (nil font-lock-multiline t 3367 . 3368) ("
c:" . -3367) (3370 . 3372) (nil markdown-gfm-code (3004 3360) 2997 . 2998) (nil markdown-metadata-markup (3004 3018 3004 3005 3005 3006 3006 3018 #<buffer structure.md>) 2997 . 2998) (nil face (markdown-pre-face markdown-code-face) 2997 . 2998) (nil font-lock-multiline t 2997 . 2998) (nil markdown-gfm-code (3004 3360) 2996 . 2997) (nil markdown-metadata-key (3004 3018 3004 3005 3005 3006 3006 3018 #<buffer structure.md>) 2996 . 2997) (nil face (markdown-pre-face markdown-code-face) 2996 . 2997) (nil font-lock-multiline t 2996 . 2997) ("
c:" . -2996) (2999 . 3001) (nil markdown-gfm-code (2550 2988) 2544 . 2545) (nil markdown-metadata-markup (2550 2564 2550 2551 2551 2552 2552 2564 #<buffer structure.md>) 2544 . 2545) (nil face (markdown-pre-face markdown-code-face) 2544 . 2545) (nil font-lock-multiline t 2544 . 2545) (nil markdown-gfm-code (2550 2988) 2543 . 2544) (nil markdown-metadata-key (2550 2564 2550 2551 2551 2552 2552 2564 #<buffer structure.md>) 2543 . 2544) (nil face (markdown-pre-face markdown-code-face) 2543 . 2544) (nil font-lock-multiline t 2543 . 2544) ("
c:" . -2543) (2546 . 2548) (nil markdown-gfm-code (2117 2534) 2113 . 2114) (nil markdown-metadata-markup (2118 2132 2118 2119 2119 2120 2120 2132 #<buffer structure.md>) 2113 . 2114) (nil face (markdown-pre-face markdown-code-face) 2113 . 2114) (nil font-lock-multiline t 2113 . 2114) (nil markdown-gfm-code (2117 2534) 2112 . 2113) (nil markdown-metadata-key (2118 2132 2118 2119 2119 2120 2120 2132 #<buffer structure.md>) 2112 . 2113) (nil face (markdown-pre-face markdown-code-face) 2112 . 2113) (nil font-lock-multiline t 2112 . 2113) ("
c:" . -2112) (2115 . 2117) (nil markdown-gfm-code (1908 2102) 1904 . 1905) (nil markdown-metadata-markup (1908 1922 1908 1909 1909 1910 1910 1922 #<buffer structure.md>) 1904 . 1905) (nil face (markdown-pre-face markdown-code-face) 1904 . 1905) (nil font-lock-multiline t 1904 . 1905) (nil markdown-gfm-code (1908 2102) 1903 . 1904) (nil markdown-metadata-key (1908 1922 1908 1909 1909 1910 1910 1922 #<buffer structure.md>) 1903 . 1904) (nil face (markdown-pre-face markdown-code-face) 1903 . 1904) (nil font-lock-multiline t 1903 . 1904) ("
c:" . -1903) (1906 . 1908) (nil markdown-gfm-code (1264 1892) 1261 . 1262) (nil markdown-metadata-markup (1264 1278 1264 1265 1265 1266 1266 1278 #<buffer structure.md>) 1261 . 1262) (nil face (markdown-pre-face markdown-code-face) 1261 . 1262) (nil font-lock-multiline t 1261 . 1262) (nil markdown-gfm-code (1264 1892) 1260 . 1261) (nil markdown-metadata-key (1264 1278 1264 1265 1265 1266 1266 1278 #<buffer structure.md>) 1260 . 1261) (nil face (markdown-pre-face markdown-code-face) 1260 . 1261) (nil font-lock-multiline t 1260 . 1261) ("
c:" . -1260) (1263 . 1265) (nil markdown-gfm-code (946 1248) 944 . 945) (nil markdown-metadata-markup (946 960 946 947 947 948 948 960 #<buffer structure.md>) 944 . 945) (nil face (markdown-pre-face markdown-code-face) 944 . 945) (nil font-lock-multiline t 944 . 945) (nil markdown-gfm-code (946 1248) 943 . 944) (nil markdown-metadata-key (946 960 946 947 947 948 948 960 #<buffer structure.md>) 943 . 944) (nil face (markdown-pre-face markdown-code-face) 943 . 944) (nil font-lock-multiline t 943 . 944) ("
c:" . -943) (946 . 948) (nil markdown-gfm-code (425 930) 424 . 425) (nil markdown-metadata-markup (425 439 425 426 426 427 427 439 #<buffer structure.md>) 424 . 425) (nil face (markdown-pre-face markdown-code-face) 424 . 425) (nil font-lock-multiline t 424 . 425) (nil fontified t 424 . 425) (nil markdown-gfm-code (425 930) 423 . 424) (nil markdown-metadata-key (425 439 425 426 426 427 427 439 #<buffer structure.md>) 423 . 424) (nil face (markdown-pre-face markdown-code-face) 423 . 424) (nil font-lock-multiline t 423 . 424) (nil fontified t 423 . 424) ("
c:" . -423) (426 . 428) (nil fontified t 74 . 75) (nil markdown-gfm-code (74 409) 74 . 75) (nil markdown-metadata-markup (74 88 74 75 75 76 76 88 #<buffer structure.md>) 74 . 75) (nil face (markdown-pre-face markdown-code-face) 74 . 75) (nil font-lock-multiline t 74 . 75) (nil fontified t 73 . 74) (nil markdown-gfm-code (74 409) 73 . 74) (nil markdown-metadata-key (74 88 74 75 75 76 76 88 #<buffer structure.md>) 73 . 74) (nil face (markdown-pre-face markdown-code-face) 73 . 74) (nil font-lock-multiline t 73 . 74) ("
c:" . -73) (76 . 78) nil (73 . 74) (" " . 73) nil (73 . 74) ("
" . -73) ((marker* . 25) . 1) ((marker) . -1) 72 nil ("
" . -5949) 5946 (t 26160 52433 534671 500000) nil (73 . 5950) ("c:line-numbers
#include <stdio.h>

typedef struct {
    char name[20];
    char id[20];
    float cgpa;
} std;

int main() {
    std s;
    scanf(\"%[^\\n]%*c\", s.name);
    scanf(\"%[^\\n]%*c\", s.id);
    scanf(\"%f\", &s.cgpa);

    printf(\"Name: %s\\n\", s.name);
    printf(\"Student ID: %s\\n\", s.id);
    printf(\"CGPA: %.2f\\n\", s.cgpa);
}
```
## 02 
```c:line-numbers
#include <stdio.h>

typedef struct {
    char name[20];
    char id[20];
    float cgpa;
} std;

int main() {
    int n; scanf(\"%d%*c\", &n);
    std s[n];
    for (int i = 0; i < n; i++) {
        scanf(\"%[^\\n]%*c\", s[i].name);
        scanf(\"%[^\\n]%*c\", s[i].id);
        scanf(\"%f%*c\", &s[i].cgpa);
    }

    for (int i = 0; i < n; i++) {
        printf(\"Student %d: %s\\n\", i+1, s[i].name);
        printf(\"Student ID: %s\\n\", s[i].id);
        printf(\"CGPA: %.2f\\n\", s[i].cgpa);
    }
}
```
## 03 
```c:line-numbers
#include <stdio.h>
#include <math.h>

typedef struct {
    int x, y;
} point;

int main() {
    point a, b;
    scanf(\"%d%d\", &a.x, &a.y);
    scanf(\"%d%d\", &b.x, &b.y);
    float dis = sqrt( (a.x-b.x)*(a.x-b.x) + (a.y-b.y)*(a.y-b.y) );
    printf(\"The distance is %.2f unit\\n\", dis);
}
```
## 04 
```c:line-numbers
#include <stdio.h>
#include <math.h>

typedef struct {
    int x, y;
} point;

float dis(point a, point b) {
    return sqrt( (a.x - b.x)*(a.x - b.x) + (a.y - b.y)*(a.y - b.y) );
}

int main() {
    point a, b, c;
    scanf(\"%d%d\", &a.x, &a.y);
    scanf(\"%d%d\", &b.x, &b.y);
    scanf(\"%d%d\", &c.x, &c.y);
    float A = dis(b, c);
    float B = dis(c, a);
    float C = dis(a, b);
    if (A+B <= C || B+C <= A || C+A <= B) {
        puts(\"They are in the same line\");
        return 0;
    }
    float s = (A+B+C) / 2;
    float area = sqrt( s*(s-A)*(s-B)*(s-C) );
    printf(\"The area is %.2f unit\\n\", area);
}
```
## 05 
```c:line-numbers
#include <stdio.h>

typedef struct {
    float real, img;
} complex;

int main() {
    complex c;
    scanf(\"%f%f\", &c.real, &c.img);
    printf(\"%.2f%+.2fi\\n\", c.real, c.img);
}
```
## 06 
```c:line-numbers
#include <stdio.h>
#include <math.h>

typedef struct {
    float real, img;
} complex;

int main() {
    complex c;
    scanf(\"%f%f\", &c.real, &c.img);

    float mod = sqrt( c.real*c.real + c.img*c.img );
    printf(\"Modulus = %.4f\\n\", mod);
    if (c.img*c.real < 0)
        printf(\"Argument = %.4f\\n\", 3.1416+atan(c.img/c.real));
    else
        printf(\"Argument = %.4f\\n\", atan(c.img/c.real));
}
```
## 07 
```c:line-numbers
#include <stdio.h>

typedef struct {
    int real, img;
} complex;

int main() {
    complex a, b;
    scanf(\"%d%d\", &a.real, &a.img);
    scanf(\"%d%d\", &b.real, &b.img);

    printf(\"(%d%+di)+(%d%+di)=%d%+di\\n\",
           a.real, a.img, b.real, b.img,
           a.real+b.real, a.img+b.img);
    
    printf(\"(%d%+di)-(%d%+di)=%d%+di\\n\",
           a.real, a.img, b.real, b.img,
           a.real-b.real, a.img-b.img);
}
```
## 08 
```c:line-numbers
#include <stdio.h>

typedef struct {
    int real, img;
} complex;

int main() {
    complex a, b;
    scanf(\"%d%d\", &a.real, &a.img);
    scanf(\"%d%d\", &b.real, &b.img);

    printf(\"(%d%+di)*(%d%+di)=%d%+di\\n\",
           a.real, a.img, b.real, b.img,
           (a.real*b.real)-(a.img*b.img),
           (a.real*b.img)+(a.img*b.real));
}
```
## 09 
```c:line-numbers
#include <stdio.h>

typedef struct {
    float real, img;
} complex;

complex mul(complex a, complex b) {
    return (complex) {
        (a.real*b.real)-(a.img*b.img),
        (a.real*b.img)+(a.img*b.real)
    };
}

complex conjugate(complex a) {
    return (complex) { a.real, -a.img };
}

complex div(complex a, complex b) {
    complex num = mul(a, conjugate(b));
    complex denom = mul(b, conjugate(b));
    return (complex) {
        num.real/denom.real, num.img/denom.real
    };
}

void print_complex(complex a) {
    printf(\"(%.2f%+.2fi)\", a.real, a.img);
}

int main() {
    complex a, b;
    scanf(\"%f%f\", &a.real, &a.img);
    scanf(\"%f%f\", &b.real, &b.img);

    print_complex(a);
    putchar('/');
    print_complex(b);
    putchar('=');
    print_complex(div(a, b));
    putchar(\\n);
}
```
## 10 
```c:line-numbers
#include <stdio.h>

typedef struct {
    int m, cm;
} length;

int main() {
    length l;
    scanf(\"%d%d\", &l.m, &l.cm);
    printf(\"Length in meter: %.2f\\n\", l.m + (float)l.cm/100);
    printf(\"Length in centimeter: %d\\n\", l.m*100+l.cm);
}
```
## 11 
```c:line-numbers
#include <stdio.h>

typedef struct {
    int m, cm;
} length;

length add(length a, length b) {
    return (length) {
        (a.cm + b.cm >= 100) ? a.m + b.m + 1 : a.m + b.m,
        (a.cm + b.cm >= 100) ? (a.cm+b.cm)%100 : a.cm + b.cm
    };
}

int main() {
    length a, b;
    scanf(\"%d%d\", &a.m, &a.cm);
    scanf(\"%d%d\", &b.m, &b.cm);

    length c = add(a, b);
    printf(\"The sum is %d meter %d centimeter\\n\", c.m, c.cm);
}
```
## 12 
```c:line-numbers
#include <stdio.h>

typedef struct {
    int h, m, s;
} time;

float h(time t) {
    return t.h + (float)t.m/60 + (float)t.s/3600;
}

float m(time t) {
    return t.h*60 + t.m + (float)t.s/60;
}

int s(time t) {
    return t.h*3600 + t.m*60 + t.s;
}

int main() {
    time t;
    scanf(\"%d%d%d\", &t.h, &t.m, &t.s);

    printf(\"Time interval in hour: %.2f\\n\", h(t));
    printf(\"Time interval in minute: %.2f\\n\", m(t));
    printf(\"Time interval in second: %d\\n\", s(t));
}
```
## 13 
```c:line-numbers
#include <stdio.h>

typedef struct {
    int h, m, s;
} time;

time sub(time a, time b) {
    time t = {
        a.h - b.h,
        a.m - b.m,
        a.s - b.s
    };
    if (t.s < 0) {
        t.s += 60;
        t.m -= 1;
    }
    if (t.m < 0) {
        t.m += 60;
        t.h -= 1;
    }
    return t;
}

int main() {
    time a, b;
    scanf(\"%d%d%d\", &a.h, &a.m, &a.s);
    scanf(\"%d%d%d\", &b.h, &b.m, &b.s);

    time c = sub(a, b);
    printf(\"%d %d %d\\n\", c.h, c.m, c.s);
}
```" . 73) ((marker . 1) . -1924) ((marker . 24) . -2068) ((marker . 1) . -2068) (t 26160 52416 303890 289000) nil (63 . 5415) ("* 01 
```c:line-numbers
#include <stdio.h>

typedef struct {
    char name[20];
    char id[20];
    float cgpa;
} std;

int main() {
    std s;
    scanf(\"%[^\\n]%*c\", s.name);
    scanf(\"%[^\\n]%*c\", s.id);
    scanf(\"%f\", &s.cgpa);

    printf(\"Name: %s\\n\", s.name);
    printf(\"Student ID: %s\\n\", s.id);
    printf(\"CGPA: %.2f\\n\", s.cgpa);
}
```
* 02 
```c:line-numbers
#include <stdio.h>

typedef struct {
    char name[20];
    char id[20];
    float cgpa;
} std;

int main() {
    int n; scanf(\"%d%*c\", &n);
    std s[n];
    for (int i = 0; i < n; i++) {
        scanf(\"%[^\\n]%*c\", s[i].name);
        scanf(\"%[^\\n]%*c\", s[i].id);
        scanf(\"%f%*c\", &s[i].cgpa);
    }

    for (int i = 0; i < n; i++) {
        printf(\"Student %d: %s\\n\", i+1, s[i].name);
        printf(\"Student ID: %s\\n\", s[i].id);
        printf(\"CGPA: %.2f\\n\", s[i].cgpa);
    }
}
```
* 03 
```c:line-numbers
#include <stdio.h>
#include <math.h>

typedef struct {
    int x, y;
} point;

int main() {
    point a, b;
    scanf(\"%d%d\", &a.x, &a.y);
    scanf(\"%d%d\", &b.x, &b.y);
    float dis = sqrt( (a.x-b.x)*(a.x-b.x) + (a.y-b.y)*(a.y-b.y) );
    printf(\"The distance is %.2f unit\\n\", dis);
}
```
* 04 
```c:line-numbers
#include <stdio.h>
#include <math.h>

typedef struct {
    int x, y;
} point;

float dis(point a, point b) {
    return sqrt( (a.x - b.x)*(a.x - b.x) + (a.y - b.y)*(a.y - b.y) );
}

int main() {
    point a, b, c;
    scanf(\"%d%d\", &a.x, &a.y);
    scanf(\"%d%d\", &b.x, &b.y);
    scanf(\"%d%d\", &c.x, &c.y);
    float A = dis(b, c);
    float B = dis(c, a);
    float C = dis(a, b);
    if (A+B <= C || B+C <= A || C+A <= B) {
        puts(\"They are in the same line\");
        return 0;
    }
    float s = (A+B+C) / 2;
    float area = sqrt( s*(s-A)*(s-B)*(s-C) );
    printf(\"The area is %.2f unit\\n\", area);
}
```
* 05 
```c:line-numbers
#include <stdio.h>

typedef struct {
    float real, img;
} complex;

int main() {
    complex c;
    scanf(\"%f%f\", &c.real, &c.img);
    printf(\"%.2f%+.2fi\\n\", c.real, c.img);
}
```
* 06 
```c:line-numbers
#include <stdio.h>
#include <math.h>

typedef struct {
    float real, img;
} complex;

int main() {
    complex c;
    scanf(\"%f%f\", &c.real, &c.img);

    float mod = sqrt( c.real*c.real + c.img*c.img );
    printf(\"Modulus = %.4f\\n\", mod);
    if (c.img*c.real < 0)
        printf(\"Argument = %.4f\\n\", 3.1416+atan(c.img/c.real));
    else
        printf(\"Argument = %.4f\\n\", atan(c.img/c.real));
}
```
* 07 
```c:line-numbers
#include <stdio.h>

typedef struct {
    int real, img;
} complex;

int main() {
    complex a, b;
    scanf(\"%d%d\", &a.real, &a.img);
    scanf(\"%d%d\", &b.real, &b.img);

    printf(\"(%d%+di)+(%d%+di)=%d%+di\\n\",
           a.real, a.img, b.real, b.img,
           a.real+b.real, a.img+b.img);
    
    printf(\"(%d%+di)-(%d%+di)=%d%+di\\n\",
           a.real, a.img, b.real, b.img,
           a.real-b.real, a.img-b.img);
}
```
* 08 
```c:line-numbers
#include <stdio.h>

typedef struct {
    int real, img;
} complex;

int main() {
    complex a, b;
    scanf(\"%d%d\", &a.real, &a.img);
    scanf(\"%d%d\", &b.real, &b.img);

    printf(\"(%d%+di)*(%d%+di)=%d%+di\\n\",
           a.real, a.img, b.real, b.img,
           (a.real*b.real)-(a.img*b.img),
           (a.real*b.img)+(a.img*b.real));
}
```
* 09 
```c:line-numbers
#include <stdio.h>

typedef struct {
    float real, img;
} complex;

complex mul(complex a, complex b) {
    return (complex) {
        (a.real*b.real)-(a.img*b.img),
        (a.real*b.img)+(a.img*b.real)
    };
}

complex conjugate(complex a) {
    return (complex) { a.real, -a.img };
}

complex div(complex a, complex b) {
    complex num = mul(a, conjugate(b));
    complex denom = mul(b, conjugate(b));
    return (complex) {
        num.real/denom.real, num.img/denom.real
    };
}

void print_complex(complex a) {
    printf(\"(%.2f%+.2fi)\", a.real, a.img);
}

int main() {
    complex a, b;
    scanf(\"%f%f\", &a.real, &a.img);
    scanf(\"%f%f\", &b.real, &b.img);

    print_complex(a);
    putchar('/');
    print_complex(b);
    putchar('=');
    print_complex(div(a, b));
    putchar(\\n);
}
```
* 10 
```c:line-numbers
#include <stdio.h>

typedef struct {
    int m, cm;
} length;

int main() {
    length l;
    scanf(\"%d%d\", &l.m, &l.cm);
    printf(\"Length in meter: %.2f\\n\", l.m + (float)l.cm/100);
    printf(\"Length in centimeter: %d\\n\", l.m*100+l.cm);
}
```
* 11 
```c:line-numbers
#include <stdio.h>

typedef struct {
    int m, cm;
} length;

length add(length a, length b) {
    return (length) {
        (a.cm + b.cm >= 100) ? a.m + b.m + 1 : a.m + b.m,
        (a.cm + b.cm >= 100) ? (a.cm+b.cm)%100 : a.cm + b.cm
    };
}

int main() {
    length a, b;
    scanf(\"%d%d\", &a.m, &a.cm);
    scanf(\"%d%d\", &b.m, &b.cm);

    length c = add(a, b);
    printf(\"The sum is %d meter %d centimeter\\n\", c.m, c.cm);
}
```
* 12 
```c:line-numbers
#include <stdio.h>

typedef struct {
    int h, m, s;
} time;

float h(time t) {
    return t.h + (float)t.m/60 + (float)t.s/3600;
}

float m(time t) {
    return t.h*60 + t.m + (float)t.s/60;
}

int s(time t) {
    return t.h*3600 + t.m*60 + t.s;
}

int main() {
    time t;
    scanf(\"%d%d%d\", &t.h, &t.m, &t.s);

    printf(\"Time interval in hour: %.2f\\n\", h(t));
    printf(\"Time interval in minute: %.2f\\n\", m(t));
    printf(\"Time interval in second: %d\\n\", s(t));
}
```
*" . 63) (t 26160 52331 720055 287000) nil ("+TITLE:" . 51) (t 26160 52327 286520 931000) nil (414 . 5918) ("#+end_src
* 02 
```c:line-numbers
#include <stdio.h>

typedef struct {
    char name[20];
    char id[20];
    float cgpa;
} std;

int main() {
    int n; scanf(\"%d%*c\", &n);
    std s[n];
    for (int i = 0; i < n; i++) {
        scanf(\"%[^\\n]%*c\", s[i].name);
        scanf(\"%[^\\n]%*c\", s[i].id);
        scanf(\"%f%*c\", &s[i].cgpa);
    }

    for (int i = 0; i < n; i++) {
        printf(\"Student %d: %s\\n\", i+1, s[i].name);
        printf(\"Student ID: %s\\n\", s[i].id);
        printf(\"CGPA: %.2f\\n\", s[i].cgpa);
    }
}
#+end_src
* 03 
```c:line-numbers
#include <stdio.h>
#include <math.h>

typedef struct {
    int x, y;
} point;

int main() {
    point a, b;
    scanf(\"%d%d\", &a.x, &a.y);
    scanf(\"%d%d\", &b.x, &b.y);
    float dis = sqrt( (a.x-b.x)*(a.x-b.x) + (a.y-b.y)*(a.y-b.y) );
    printf(\"The distance is %.2f unit\\n\", dis);
}
#+end_src
* 04 
```c:line-numbers
#include <stdio.h>
#include <math.h>

typedef struct {
    int x, y;
} point;

float dis(point a, point b) {
    return sqrt( (a.x - b.x)*(a.x - b.x) + (a.y - b.y)*(a.y - b.y) );
}

int main() {
    point a, b, c;
    scanf(\"%d%d\", &a.x, &a.y);
    scanf(\"%d%d\", &b.x, &b.y);
    scanf(\"%d%d\", &c.x, &c.y);
    float A = dis(b, c);
    float B = dis(c, a);
    float C = dis(a, b);
    if (A+B <= C || B+C <= A || C+A <= B) {
        puts(\"They are in the same line\");
        return 0;
    }
    float s = (A+B+C) / 2;
    float area = sqrt( s*(s-A)*(s-B)*(s-C) );
    printf(\"The area is %.2f unit\\n\", area);
}
#+end_src
* 05 
```c:line-numbers
#include <stdio.h>

typedef struct {
    float real, img;
} complex;

int main() {
    complex c;
    scanf(\"%f%f\", &c.real, &c.img);
    printf(\"%.2f%+.2fi\\n\", c.real, c.img);
}
#+end_src
* 06 
```c:line-numbers
#include <stdio.h>
#include <math.h>

typedef struct {
    float real, img;
} complex;

int main() {
    complex c;
    scanf(\"%f%f\", &c.real, &c.img);

    float mod = sqrt( c.real*c.real + c.img*c.img );
    printf(\"Modulus = %.4f\\n\", mod);
    if (c.img*c.real < 0)
        printf(\"Argument = %.4f\\n\", 3.1416+atan(c.img/c.real));
    else
        printf(\"Argument = %.4f\\n\", atan(c.img/c.real));
}
#+end_src
* 07 
```c:line-numbers
#include <stdio.h>

typedef struct {
    int real, img;
} complex;

int main() {
    complex a, b;
    scanf(\"%d%d\", &a.real, &a.img);
    scanf(\"%d%d\", &b.real, &b.img);

    printf(\"(%d%+di)+(%d%+di)=%d%+di\\n\",
           a.real, a.img, b.real, b.img,
           a.real+b.real, a.img+b.img);
    
    printf(\"(%d%+di)-(%d%+di)=%d%+di\\n\",
           a.real, a.img, b.real, b.img,
           a.real-b.real, a.img-b.img);
}
#+end_src
* 08 
```c:line-numbers
#include <stdio.h>

typedef struct {
    int real, img;
} complex;

int main() {
    complex a, b;
    scanf(\"%d%d\", &a.real, &a.img);
    scanf(\"%d%d\", &b.real, &b.img);

    printf(\"(%d%+di)*(%d%+di)=%d%+di\\n\",
           a.real, a.img, b.real, b.img,
           (a.real*b.real)-(a.img*b.img),
           (a.real*b.img)+(a.img*b.real));
}
#+end_src
* 09 
```c:line-numbers
#include <stdio.h>

typedef struct {
    float real, img;
} complex;

complex mul(complex a, complex b) {
    return (complex) {
        (a.real*b.real)-(a.img*b.img),
        (a.real*b.img)+(a.img*b.real)
    };
}

complex conjugate(complex a) {
    return (complex) { a.real, -a.img };
}

complex div(complex a, complex b) {
    complex num = mul(a, conjugate(b));
    complex denom = mul(b, conjugate(b));
    return (complex) {
        num.real/denom.real, num.img/denom.real
    };
}

void print_complex(complex a) {
    printf(\"(%.2f%+.2fi)\", a.real, a.img);
}

int main() {
    complex a, b;
    scanf(\"%f%f\", &a.real, &a.img);
    scanf(\"%f%f\", &b.real, &b.img);

    print_complex(a);
    putchar('/');
    print_complex(b);
    putchar('=');
    print_complex(div(a, b));
    putchar(\\n);
}
#+end_src
* 10 
```c:line-numbers
#include <stdio.h>

typedef struct {
    int m, cm;
} length;

int main() {
    length l;
    scanf(\"%d%d\", &l.m, &l.cm);
    printf(\"Length in meter: %.2f\\n\", l.m + (float)l.cm/100);
    printf(\"Length in centimeter: %d\\n\", l.m*100+l.cm);
}
#+end_src
* 11 
```c:line-numbers
#include <stdio.h>

typedef struct {
    int m, cm;
} length;

length add(length a, length b) {
    return (length) {
        (a.cm + b.cm >= 100) ? a.m + b.m + 1 : a.m + b.m,
        (a.cm + b.cm >= 100) ? (a.cm+b.cm)%100 : a.cm + b.cm
    };
}

int main() {
    length a, b;
    scanf(\"%d%d\", &a.m, &a.cm);
    scanf(\"%d%d\", &b.m, &b.cm);

    length c = add(a, b);
    printf(\"The sum is %d meter %d centimeter\\n\", c.m, c.cm);
}
#+end_src
* 12 
```c:line-numbers
#include <stdio.h>

typedef struct {
    int h, m, s;
} time;

float h(time t) {
    return t.h + (float)t.m/60 + (float)t.s/3600;
}

float m(time t) {
    return t.h*60 + t.m + (float)t.s/60;
}

int s(time t) {
    return t.h*3600 + t.m*60 + t.s;
}

int main() {
    time t;
    scanf(\"%d%d%d\", &t.h, &t.m, &t.s);

    printf(\"Time interval in hour: %.2f\\n\", h(t));
    printf(\"Time interval in minute: %.2f\\n\", m(t));
    printf(\"Time interval in second: %d\\n\", s(t));
}
#+end_src
* 13 
```c:line-numbers
#include <stdio.h>

typedef struct {
    int h, m, s;
} time;

time sub(time a, time b) {
    time t = {
        a.h - b.h,
        a.m - b.m,
        a.s - b.s
    };
    if (t.s < 0) {
        t.s += 60;
        t.m -= 1;
    }
    if (t.m < 0) {
        t.m += 60;
        t.h -= 1;
    }
    return t;
}

int main() {
    time a, b;
    scanf(\"%d%d%d\", &a.h, &a.m, &a.s);
    scanf(\"%d%d%d\", &b.h, &b.m, &b.s);

    time c = sub(a, b);
    printf(\"%d %d %d\\n\", c.h, c.m, c.s);
}
#+end_src" . 414) (t 26160 52273 664089 537000) nil (76 . 5503) ("#+begin_src C -n
#include <stdio.h>

typedef struct {
    char name[20];
    char id[20];
    float cgpa;
} std;

int main() {
    std s;
    scanf(\"%[^\\n]%*c\", s.name);
    scanf(\"%[^\\n]%*c\", s.id);
    scanf(\"%f\", &s.cgpa);

    printf(\"Name: %s\\n\", s.name);
    printf(\"Student ID: %s\\n\", s.id);
    printf(\"CGPA: %.2f\\n\", s.cgpa);
}
#+end_src
* 02 
#+begin_src C -n
#include <stdio.h>

typedef struct {
    char name[20];
    char id[20];
    float cgpa;
} std;

int main() {
    int n; scanf(\"%d%*c\", &n);
    std s[n];
    for (int i = 0; i < n; i++) {
        scanf(\"%[^\\n]%*c\", s[i].name);
        scanf(\"%[^\\n]%*c\", s[i].id);
        scanf(\"%f%*c\", &s[i].cgpa);
    }

    for (int i = 0; i < n; i++) {
        printf(\"Student %d: %s\\n\", i+1, s[i].name);
        printf(\"Student ID: %s\\n\", s[i].id);
        printf(\"CGPA: %.2f\\n\", s[i].cgpa);
    }
}
#+end_src
* 03 
#+begin_src C -n
#include <stdio.h>
#include <math.h>

typedef struct {
    int x, y;
} point;

int main() {
    point a, b;
    scanf(\"%d%d\", &a.x, &a.y);
    scanf(\"%d%d\", &b.x, &b.y);
    float dis = sqrt( (a.x-b.x)*(a.x-b.x) + (a.y-b.y)*(a.y-b.y) );
    printf(\"The distance is %.2f unit\\n\", dis);
}
#+end_src
* 04 
#+begin_src C -n
#include <stdio.h>
#include <math.h>

typedef struct {
    int x, y;
} point;

float dis(point a, point b) {
    return sqrt( (a.x - b.x)*(a.x - b.x) + (a.y - b.y)*(a.y - b.y) );
}

int main() {
    point a, b, c;
    scanf(\"%d%d\", &a.x, &a.y);
    scanf(\"%d%d\", &b.x, &b.y);
    scanf(\"%d%d\", &c.x, &c.y);
    float A = dis(b, c);
    float B = dis(c, a);
    float C = dis(a, b);
    if (A+B <= C || B+C <= A || C+A <= B) {
        puts(\"They are in the same line\");
        return 0;
    }
    float s = (A+B+C) / 2;
    float area = sqrt( s*(s-A)*(s-B)*(s-C) );
    printf(\"The area is %.2f unit\\n\", area);
}
#+end_src
* 05 
#+begin_src C -n
#include <stdio.h>

typedef struct {
    float real, img;
} complex;

int main() {
    complex c;
    scanf(\"%f%f\", &c.real, &c.img);
    printf(\"%.2f%+.2fi\\n\", c.real, c.img);
}
#+end_src
* 06 
#+begin_src C -n
#include <stdio.h>
#include <math.h>

typedef struct {
    float real, img;
} complex;

int main() {
    complex c;
    scanf(\"%f%f\", &c.real, &c.img);

    float mod = sqrt( c.real*c.real + c.img*c.img );
    printf(\"Modulus = %.4f\\n\", mod);
    if (c.img*c.real < 0)
        printf(\"Argument = %.4f\\n\", 3.1416+atan(c.img/c.real));
    else
        printf(\"Argument = %.4f\\n\", atan(c.img/c.real));
}
#+end_src
* 07 
#+begin_src C -n
#include <stdio.h>

typedef struct {
    int real, img;
} complex;

int main() {
    complex a, b;
    scanf(\"%d%d\", &a.real, &a.img);
    scanf(\"%d%d\", &b.real, &b.img);

    printf(\"(%d%+di)+(%d%+di)=%d%+di\\n\",
           a.real, a.img, b.real, b.img,
           a.real+b.real, a.img+b.img);
    
    printf(\"(%d%+di)-(%d%+di)=%d%+di\\n\",
           a.real, a.img, b.real, b.img,
           a.real-b.real, a.img-b.img);
}
#+end_src
* 08 
#+begin_src C -n
#include <stdio.h>

typedef struct {
    int real, img;
} complex;

int main() {
    complex a, b;
    scanf(\"%d%d\", &a.real, &a.img);
    scanf(\"%d%d\", &b.real, &b.img);

    printf(\"(%d%+di)*(%d%+di)=%d%+di\\n\",
           a.real, a.img, b.real, b.img,
           (a.real*b.real)-(a.img*b.img),
           (a.real*b.img)+(a.img*b.real));
}
#+end_src
* 09 
#+begin_src C -n
#include <stdio.h>

typedef struct {
    float real, img;
} complex;

complex mul(complex a, complex b) {
    return (complex) {
        (a.real*b.real)-(a.img*b.img),
        (a.real*b.img)+(a.img*b.real)
    };
}

complex conjugate(complex a) {
    return (complex) { a.real, -a.img };
}

complex div(complex a, complex b) {
    complex num = mul(a, conjugate(b));
    complex denom = mul(b, conjugate(b));
    return (complex) {
        num.real/denom.real, num.img/denom.real
    };
}

void print_complex(complex a) {
    printf(\"(%.2f%+.2fi)\", a.real, a.img);
}

int main() {
    complex a, b;
    scanf(\"%f%f\", &a.real, &a.img);
    scanf(\"%f%f\", &b.real, &b.img);

    print_complex(a);
    putchar('/');
    print_complex(b);
    putchar('=');
    print_complex(div(a, b));
    putchar(\\n);
}
#+end_src
* 10 
#+begin_src C -n
#include <stdio.h>

typedef struct {
    int m, cm;
} length;

int main() {
    length l;
    scanf(\"%d%d\", &l.m, &l.cm);
    printf(\"Length in meter: %.2f\\n\", l.m + (float)l.cm/100);
    printf(\"Length in centimeter: %d\\n\", l.m*100+l.cm);
}
#+end_src
* 11 
#+begin_src C -n
#include <stdio.h>

typedef struct {
    int m, cm;
} length;

length add(length a, length b) {
    return (length) {
        (a.cm + b.cm >= 100) ? a.m + b.m + 1 : a.m + b.m,
        (a.cm + b.cm >= 100) ? (a.cm+b.cm)%100 : a.cm + b.cm
    };
}

int main() {
    length a, b;
    scanf(\"%d%d\", &a.m, &a.cm);
    scanf(\"%d%d\", &b.m, &b.cm);

    length c = add(a, b);
    printf(\"The sum is %d meter %d centimeter\\n\", c.m, c.cm);
}
#+end_src
* 12 
#+begin_src C -n
#include <stdio.h>

typedef struct {
    int h, m, s;
} time;

float h(time t) {
    return t.h + (float)t.m/60 + (float)t.s/3600;
}

float m(time t) {
    return t.h*60 + t.m + (float)t.s/60;
}

int s(time t) {
    return t.h*3600 + t.m*60 + t.s;
}

int main() {
    time t;
    scanf(\"%d%d%d\", &t.h, &t.m, &t.s);

    printf(\"Time interval in hour: %.2f\\n\", h(t));
    printf(\"Time interval in minute: %.2f\\n\", m(t));
    printf(\"Time interval in second: %d\\n\", s(t));
}
#+end_src
* 13 
#+begin_src C -n" . 76) (t 26160 52195 223865 895000) nil ("
" . -1) nil (1 . 5985) (t . -1)) (emacs-pending-undo-list ("
" . -5949) 5946 (t 26160 52433 534671 500000) nil (73 . 5950) ("c:line-numbers
#include <stdio.h>

typedef struct {
    char name[20];
    char id[20];
    float cgpa;
} std;

int main() {
    std s;
    scanf(\"%[^\\n]%*c\", s.name);
    scanf(\"%[^\\n]%*c\", s.id);
    scanf(\"%f\", &s.cgpa);

    printf(\"Name: %s\\n\", s.name);
    printf(\"Student ID: %s\\n\", s.id);
    printf(\"CGPA: %.2f\\n\", s.cgpa);
}
```
## 02 
```c:line-numbers
#include <stdio.h>

typedef struct {
    char name[20];
    char id[20];
    float cgpa;
} std;

int main() {
    int n; scanf(\"%d%*c\", &n);
    std s[n];
    for (int i = 0; i < n; i++) {
        scanf(\"%[^\\n]%*c\", s[i].name);
        scanf(\"%[^\\n]%*c\", s[i].id);
        scanf(\"%f%*c\", &s[i].cgpa);
    }

    for (int i = 0; i < n; i++) {
        printf(\"Student %d: %s\\n\", i+1, s[i].name);
        printf(\"Student ID: %s\\n\", s[i].id);
        printf(\"CGPA: %.2f\\n\", s[i].cgpa);
    }
}
```
## 03 
```c:line-numbers
#include <stdio.h>
#include <math.h>

typedef struct {
    int x, y;
} point;

int main() {
    point a, b;
    scanf(\"%d%d\", &a.x, &a.y);
    scanf(\"%d%d\", &b.x, &b.y);
    float dis = sqrt( (a.x-b.x)*(a.x-b.x) + (a.y-b.y)*(a.y-b.y) );
    printf(\"The distance is %.2f unit\\n\", dis);
}
```
## 04 
```c:line-numbers
#include <stdio.h>
#include <math.h>

typedef struct {
    int x, y;
} point;

float dis(point a, point b) {
    return sqrt( (a.x - b.x)*(a.x - b.x) + (a.y - b.y)*(a.y - b.y) );
}

int main() {
    point a, b, c;
    scanf(\"%d%d\", &a.x, &a.y);
    scanf(\"%d%d\", &b.x, &b.y);
    scanf(\"%d%d\", &c.x, &c.y);
    float A = dis(b, c);
    float B = dis(c, a);
    float C = dis(a, b);
    if (A+B <= C || B+C <= A || C+A <= B) {
        puts(\"They are in the same line\");
        return 0;
    }
    float s = (A+B+C) / 2;
    float area = sqrt( s*(s-A)*(s-B)*(s-C) );
    printf(\"The area is %.2f unit\\n\", area);
}
```
## 05 
```c:line-numbers
#include <stdio.h>

typedef struct {
    float real, img;
} complex;

int main() {
    complex c;
    scanf(\"%f%f\", &c.real, &c.img);
    printf(\"%.2f%+.2fi\\n\", c.real, c.img);
}
```
## 06 
```c:line-numbers
#include <stdio.h>
#include <math.h>

typedef struct {
    float real, img;
} complex;

int main() {
    complex c;
    scanf(\"%f%f\", &c.real, &c.img);

    float mod = sqrt( c.real*c.real + c.img*c.img );
    printf(\"Modulus = %.4f\\n\", mod);
    if (c.img*c.real < 0)
        printf(\"Argument = %.4f\\n\", 3.1416+atan(c.img/c.real));
    else
        printf(\"Argument = %.4f\\n\", atan(c.img/c.real));
}
```
## 07 
```c:line-numbers
#include <stdio.h>

typedef struct {
    int real, img;
} complex;

int main() {
    complex a, b;
    scanf(\"%d%d\", &a.real, &a.img);
    scanf(\"%d%d\", &b.real, &b.img);

    printf(\"(%d%+di)+(%d%+di)=%d%+di\\n\",
           a.real, a.img, b.real, b.img,
           a.real+b.real, a.img+b.img);
    
    printf(\"(%d%+di)-(%d%+di)=%d%+di\\n\",
           a.real, a.img, b.real, b.img,
           a.real-b.real, a.img-b.img);
}
```
## 08 
```c:line-numbers
#include <stdio.h>

typedef struct {
    int real, img;
} complex;

int main() {
    complex a, b;
    scanf(\"%d%d\", &a.real, &a.img);
    scanf(\"%d%d\", &b.real, &b.img);

    printf(\"(%d%+di)*(%d%+di)=%d%+di\\n\",
           a.real, a.img, b.real, b.img,
           (a.real*b.real)-(a.img*b.img),
           (a.real*b.img)+(a.img*b.real));
}
```
## 09 
```c:line-numbers
#include <stdio.h>

typedef struct {
    float real, img;
} complex;

complex mul(complex a, complex b) {
    return (complex) {
        (a.real*b.real)-(a.img*b.img),
        (a.real*b.img)+(a.img*b.real)
    };
}

complex conjugate(complex a) {
    return (complex) { a.real, -a.img };
}

complex div(complex a, complex b) {
    complex num = mul(a, conjugate(b));
    complex denom = mul(b, conjugate(b));
    return (complex) {
        num.real/denom.real, num.img/denom.real
    };
}

void print_complex(complex a) {
    printf(\"(%.2f%+.2fi)\", a.real, a.img);
}

int main() {
    complex a, b;
    scanf(\"%f%f\", &a.real, &a.img);
    scanf(\"%f%f\", &b.real, &b.img);

    print_complex(a);
    putchar('/');
    print_complex(b);
    putchar('=');
    print_complex(div(a, b));
    putchar(\\n);
}
```
## 10 
```c:line-numbers
#include <stdio.h>

typedef struct {
    int m, cm;
} length;

int main() {
    length l;
    scanf(\"%d%d\", &l.m, &l.cm);
    printf(\"Length in meter: %.2f\\n\", l.m + (float)l.cm/100);
    printf(\"Length in centimeter: %d\\n\", l.m*100+l.cm);
}
```
## 11 
```c:line-numbers
#include <stdio.h>

typedef struct {
    int m, cm;
} length;

length add(length a, length b) {
    return (length) {
        (a.cm + b.cm >= 100) ? a.m + b.m + 1 : a.m + b.m,
        (a.cm + b.cm >= 100) ? (a.cm+b.cm)%100 : a.cm + b.cm
    };
}

int main() {
    length a, b;
    scanf(\"%d%d\", &a.m, &a.cm);
    scanf(\"%d%d\", &b.m, &b.cm);

    length c = add(a, b);
    printf(\"The sum is %d meter %d centimeter\\n\", c.m, c.cm);
}
```
## 12 
```c:line-numbers
#include <stdio.h>

typedef struct {
    int h, m, s;
} time;

float h(time t) {
    return t.h + (float)t.m/60 + (float)t.s/3600;
}

float m(time t) {
    return t.h*60 + t.m + (float)t.s/60;
}

int s(time t) {
    return t.h*3600 + t.m*60 + t.s;
}

int main() {
    time t;
    scanf(\"%d%d%d\", &t.h, &t.m, &t.s);

    printf(\"Time interval in hour: %.2f\\n\", h(t));
    printf(\"Time interval in minute: %.2f\\n\", m(t));
    printf(\"Time interval in second: %d\\n\", s(t));
}
```
## 13 
```c:line-numbers
#include <stdio.h>

typedef struct {
    int h, m, s;
} time;

time sub(time a, time b) {
    time t = {
        a.h - b.h,
        a.m - b.m,
        a.s - b.s
    };
    if (t.s < 0) {
        t.s += 60;
        t.m -= 1;
    }
    if (t.m < 0) {
        t.m += 60;
        t.h -= 1;
    }
    return t;
}

int main() {
    time a, b;
    scanf(\"%d%d%d\", &a.h, &a.m, &a.s);
    scanf(\"%d%d%d\", &b.h, &b.m, &b.s);

    time c = sub(a, b);
    printf(\"%d %d %d\\n\", c.h, c.m, c.s);
}
```" . 73) ((marker . 1) . -1924) ((marker . 24) . -2068) ((marker . 1) . -2068) (t 26160 52416 303890 289000) nil (63 . 5415) ("* 01 
```c:line-numbers
#include <stdio.h>

typedef struct {
    char name[20];
    char id[20];
    float cgpa;
} std;

int main() {
    std s;
    scanf(\"%[^\\n]%*c\", s.name);
    scanf(\"%[^\\n]%*c\", s.id);
    scanf(\"%f\", &s.cgpa);

    printf(\"Name: %s\\n\", s.name);
    printf(\"Student ID: %s\\n\", s.id);
    printf(\"CGPA: %.2f\\n\", s.cgpa);
}
```
* 02 
```c:line-numbers
#include <stdio.h>

typedef struct {
    char name[20];
    char id[20];
    float cgpa;
} std;

int main() {
    int n; scanf(\"%d%*c\", &n);
    std s[n];
    for (int i = 0; i < n; i++) {
        scanf(\"%[^\\n]%*c\", s[i].name);
        scanf(\"%[^\\n]%*c\", s[i].id);
        scanf(\"%f%*c\", &s[i].cgpa);
    }

    for (int i = 0; i < n; i++) {
        printf(\"Student %d: %s\\n\", i+1, s[i].name);
        printf(\"Student ID: %s\\n\", s[i].id);
        printf(\"CGPA: %.2f\\n\", s[i].cgpa);
    }
}
```
* 03 
```c:line-numbers
#include <stdio.h>
#include <math.h>

typedef struct {
    int x, y;
} point;

int main() {
    point a, b;
    scanf(\"%d%d\", &a.x, &a.y);
    scanf(\"%d%d\", &b.x, &b.y);
    float dis = sqrt( (a.x-b.x)*(a.x-b.x) + (a.y-b.y)*(a.y-b.y) );
    printf(\"The distance is %.2f unit\\n\", dis);
}
```
* 04 
```c:line-numbers
#include <stdio.h>
#include <math.h>

typedef struct {
    int x, y;
} point;

float dis(point a, point b) {
    return sqrt( (a.x - b.x)*(a.x - b.x) + (a.y - b.y)*(a.y - b.y) );
}

int main() {
    point a, b, c;
    scanf(\"%d%d\", &a.x, &a.y);
    scanf(\"%d%d\", &b.x, &b.y);
    scanf(\"%d%d\", &c.x, &c.y);
    float A = dis(b, c);
    float B = dis(c, a);
    float C = dis(a, b);
    if (A+B <= C || B+C <= A || C+A <= B) {
        puts(\"They are in the same line\");
        return 0;
    }
    float s = (A+B+C) / 2;
    float area = sqrt( s*(s-A)*(s-B)*(s-C) );
    printf(\"The area is %.2f unit\\n\", area);
}
```
* 05 
```c:line-numbers
#include <stdio.h>

typedef struct {
    float real, img;
} complex;

int main() {
    complex c;
    scanf(\"%f%f\", &c.real, &c.img);
    printf(\"%.2f%+.2fi\\n\", c.real, c.img);
}
```
* 06 
```c:line-numbers
#include <stdio.h>
#include <math.h>

typedef struct {
    float real, img;
} complex;

int main() {
    complex c;
    scanf(\"%f%f\", &c.real, &c.img);

    float mod = sqrt( c.real*c.real + c.img*c.img );
    printf(\"Modulus = %.4f\\n\", mod);
    if (c.img*c.real < 0)
        printf(\"Argument = %.4f\\n\", 3.1416+atan(c.img/c.real));
    else
        printf(\"Argument = %.4f\\n\", atan(c.img/c.real));
}
```
* 07 
```c:line-numbers
#include <stdio.h>

typedef struct {
    int real, img;
} complex;

int main() {
    complex a, b;
    scanf(\"%d%d\", &a.real, &a.img);
    scanf(\"%d%d\", &b.real, &b.img);

    printf(\"(%d%+di)+(%d%+di)=%d%+di\\n\",
           a.real, a.img, b.real, b.img,
           a.real+b.real, a.img+b.img);
    
    printf(\"(%d%+di)-(%d%+di)=%d%+di\\n\",
           a.real, a.img, b.real, b.img,
           a.real-b.real, a.img-b.img);
}
```
* 08 
```c:line-numbers
#include <stdio.h>

typedef struct {
    int real, img;
} complex;

int main() {
    complex a, b;
    scanf(\"%d%d\", &a.real, &a.img);
    scanf(\"%d%d\", &b.real, &b.img);

    printf(\"(%d%+di)*(%d%+di)=%d%+di\\n\",
           a.real, a.img, b.real, b.img,
           (a.real*b.real)-(a.img*b.img),
           (a.real*b.img)+(a.img*b.real));
}
```
* 09 
```c:line-numbers
#include <stdio.h>

typedef struct {
    float real, img;
} complex;

complex mul(complex a, complex b) {
    return (complex) {
        (a.real*b.real)-(a.img*b.img),
        (a.real*b.img)+(a.img*b.real)
    };
}

complex conjugate(complex a) {
    return (complex) { a.real, -a.img };
}

complex div(complex a, complex b) {
    complex num = mul(a, conjugate(b));
    complex denom = mul(b, conjugate(b));
    return (complex) {
        num.real/denom.real, num.img/denom.real
    };
}

void print_complex(complex a) {
    printf(\"(%.2f%+.2fi)\", a.real, a.img);
}

int main() {
    complex a, b;
    scanf(\"%f%f\", &a.real, &a.img);
    scanf(\"%f%f\", &b.real, &b.img);

    print_complex(a);
    putchar('/');
    print_complex(b);
    putchar('=');
    print_complex(div(a, b));
    putchar(\\n);
}
```
* 10 
```c:line-numbers
#include <stdio.h>

typedef struct {
    int m, cm;
} length;

int main() {
    length l;
    scanf(\"%d%d\", &l.m, &l.cm);
    printf(\"Length in meter: %.2f\\n\", l.m + (float)l.cm/100);
    printf(\"Length in centimeter: %d\\n\", l.m*100+l.cm);
}
```
* 11 
```c:line-numbers
#include <stdio.h>

typedef struct {
    int m, cm;
} length;

length add(length a, length b) {
    return (length) {
        (a.cm + b.cm >= 100) ? a.m + b.m + 1 : a.m + b.m,
        (a.cm + b.cm >= 100) ? (a.cm+b.cm)%100 : a.cm + b.cm
    };
}

int main() {
    length a, b;
    scanf(\"%d%d\", &a.m, &a.cm);
    scanf(\"%d%d\", &b.m, &b.cm);

    length c = add(a, b);
    printf(\"The sum is %d meter %d centimeter\\n\", c.m, c.cm);
}
```
* 12 
```c:line-numbers
#include <stdio.h>

typedef struct {
    int h, m, s;
} time;

float h(time t) {
    return t.h + (float)t.m/60 + (float)t.s/3600;
}

float m(time t) {
    return t.h*60 + t.m + (float)t.s/60;
}

int s(time t) {
    return t.h*3600 + t.m*60 + t.s;
}

int main() {
    time t;
    scanf(\"%d%d%d\", &t.h, &t.m, &t.s);

    printf(\"Time interval in hour: %.2f\\n\", h(t));
    printf(\"Time interval in minute: %.2f\\n\", m(t));
    printf(\"Time interval in second: %d\\n\", s(t));
}
```
*" . 63) (t 26160 52331 720055 287000) nil ("+TITLE:" . 51) (t 26160 52327 286520 931000) nil (414 . 5918) ("#+end_src
* 02 
```c:line-numbers
#include <stdio.h>

typedef struct {
    char name[20];
    char id[20];
    float cgpa;
} std;

int main() {
    int n; scanf(\"%d%*c\", &n);
    std s[n];
    for (int i = 0; i < n; i++) {
        scanf(\"%[^\\n]%*c\", s[i].name);
        scanf(\"%[^\\n]%*c\", s[i].id);
        scanf(\"%f%*c\", &s[i].cgpa);
    }

    for (int i = 0; i < n; i++) {
        printf(\"Student %d: %s\\n\", i+1, s[i].name);
        printf(\"Student ID: %s\\n\", s[i].id);
        printf(\"CGPA: %.2f\\n\", s[i].cgpa);
    }
}
#+end_src
* 03 
```c:line-numbers
#include <stdio.h>
#include <math.h>

typedef struct {
    int x, y;
} point;

int main() {
    point a, b;
    scanf(\"%d%d\", &a.x, &a.y);
    scanf(\"%d%d\", &b.x, &b.y);
    float dis = sqrt( (a.x-b.x)*(a.x-b.x) + (a.y-b.y)*(a.y-b.y) );
    printf(\"The distance is %.2f unit\\n\", dis);
}
#+end_src
* 04 
```c:line-numbers
#include <stdio.h>
#include <math.h>

typedef struct {
    int x, y;
} point;

float dis(point a, point b) {
    return sqrt( (a.x - b.x)*(a.x - b.x) + (a.y - b.y)*(a.y - b.y) );
}

int main() {
    point a, b, c;
    scanf(\"%d%d\", &a.x, &a.y);
    scanf(\"%d%d\", &b.x, &b.y);
    scanf(\"%d%d\", &c.x, &c.y);
    float A = dis(b, c);
    float B = dis(c, a);
    float C = dis(a, b);
    if (A+B <= C || B+C <= A || C+A <= B) {
        puts(\"They are in the same line\");
        return 0;
    }
    float s = (A+B+C) / 2;
    float area = sqrt( s*(s-A)*(s-B)*(s-C) );
    printf(\"The area is %.2f unit\\n\", area);
}
#+end_src
* 05 
```c:line-numbers
#include <stdio.h>

typedef struct {
    float real, img;
} complex;

int main() {
    complex c;
    scanf(\"%f%f\", &c.real, &c.img);
    printf(\"%.2f%+.2fi\\n\", c.real, c.img);
}
#+end_src
* 06 
```c:line-numbers
#include <stdio.h>
#include <math.h>

typedef struct {
    float real, img;
} complex;

int main() {
    complex c;
    scanf(\"%f%f\", &c.real, &c.img);

    float mod = sqrt( c.real*c.real + c.img*c.img );
    printf(\"Modulus = %.4f\\n\", mod);
    if (c.img*c.real < 0)
        printf(\"Argument = %.4f\\n\", 3.1416+atan(c.img/c.real));
    else
        printf(\"Argument = %.4f\\n\", atan(c.img/c.real));
}
#+end_src
* 07 
```c:line-numbers
#include <stdio.h>

typedef struct {
    int real, img;
} complex;

int main() {
    complex a, b;
    scanf(\"%d%d\", &a.real, &a.img);
    scanf(\"%d%d\", &b.real, &b.img);

    printf(\"(%d%+di)+(%d%+di)=%d%+di\\n\",
           a.real, a.img, b.real, b.img,
           a.real+b.real, a.img+b.img);
    
    printf(\"(%d%+di)-(%d%+di)=%d%+di\\n\",
           a.real, a.img, b.real, b.img,
           a.real-b.real, a.img-b.img);
}
#+end_src
* 08 
```c:line-numbers
#include <stdio.h>

typedef struct {
    int real, img;
} complex;

int main() {
    complex a, b;
    scanf(\"%d%d\", &a.real, &a.img);
    scanf(\"%d%d\", &b.real, &b.img);

    printf(\"(%d%+di)*(%d%+di)=%d%+di\\n\",
           a.real, a.img, b.real, b.img,
           (a.real*b.real)-(a.img*b.img),
           (a.real*b.img)+(a.img*b.real));
}
#+end_src
* 09 
```c:line-numbers
#include <stdio.h>

typedef struct {
    float real, img;
} complex;

complex mul(complex a, complex b) {
    return (complex) {
        (a.real*b.real)-(a.img*b.img),
        (a.real*b.img)+(a.img*b.real)
    };
}

complex conjugate(complex a) {
    return (complex) { a.real, -a.img };
}

complex div(complex a, complex b) {
    complex num = mul(a, conjugate(b));
    complex denom = mul(b, conjugate(b));
    return (complex) {
        num.real/denom.real, num.img/denom.real
    };
}

void print_complex(complex a) {
    printf(\"(%.2f%+.2fi)\", a.real, a.img);
}

int main() {
    complex a, b;
    scanf(\"%f%f\", &a.real, &a.img);
    scanf(\"%f%f\", &b.real, &b.img);

    print_complex(a);
    putchar('/');
    print_complex(b);
    putchar('=');
    print_complex(div(a, b));
    putchar(\\n);
}
#+end_src
* 10 
```c:line-numbers
#include <stdio.h>

typedef struct {
    int m, cm;
} length;

int main() {
    length l;
    scanf(\"%d%d\", &l.m, &l.cm);
    printf(\"Length in meter: %.2f\\n\", l.m + (float)l.cm/100);
    printf(\"Length in centimeter: %d\\n\", l.m*100+l.cm);
}
#+end_src
* 11 
```c:line-numbers
#include <stdio.h>

typedef struct {
    int m, cm;
} length;

length add(length a, length b) {
    return (length) {
        (a.cm + b.cm >= 100) ? a.m + b.m + 1 : a.m + b.m,
        (a.cm + b.cm >= 100) ? (a.cm+b.cm)%100 : a.cm + b.cm
    };
}

int main() {
    length a, b;
    scanf(\"%d%d\", &a.m, &a.cm);
    scanf(\"%d%d\", &b.m, &b.cm);

    length c = add(a, b);
    printf(\"The sum is %d meter %d centimeter\\n\", c.m, c.cm);
}
#+end_src
* 12 
```c:line-numbers
#include <stdio.h>

typedef struct {
    int h, m, s;
} time;

float h(time t) {
    return t.h + (float)t.m/60 + (float)t.s/3600;
}

float m(time t) {
    return t.h*60 + t.m + (float)t.s/60;
}

int s(time t) {
    return t.h*3600 + t.m*60 + t.s;
}

int main() {
    time t;
    scanf(\"%d%d%d\", &t.h, &t.m, &t.s);

    printf(\"Time interval in hour: %.2f\\n\", h(t));
    printf(\"Time interval in minute: %.2f\\n\", m(t));
    printf(\"Time interval in second: %d\\n\", s(t));
}
#+end_src
* 13 
```c:line-numbers
#include <stdio.h>

typedef struct {
    int h, m, s;
} time;

time sub(time a, time b) {
    time t = {
        a.h - b.h,
        a.m - b.m,
        a.s - b.s
    };
    if (t.s < 0) {
        t.s += 60;
        t.m -= 1;
    }
    if (t.m < 0) {
        t.m += 60;
        t.h -= 1;
    }
    return t;
}

int main() {
    time a, b;
    scanf(\"%d%d%d\", &a.h, &a.m, &a.s);
    scanf(\"%d%d%d\", &b.h, &b.m, &b.s);

    time c = sub(a, b);
    printf(\"%d %d %d\\n\", c.h, c.m, c.s);
}
#+end_src" . 414) (t 26160 52273 664089 537000) nil (76 . 5503) ("#+begin_src C -n
#include <stdio.h>

typedef struct {
    char name[20];
    char id[20];
    float cgpa;
} std;

int main() {
    std s;
    scanf(\"%[^\\n]%*c\", s.name);
    scanf(\"%[^\\n]%*c\", s.id);
    scanf(\"%f\", &s.cgpa);

    printf(\"Name: %s\\n\", s.name);
    printf(\"Student ID: %s\\n\", s.id);
    printf(\"CGPA: %.2f\\n\", s.cgpa);
}
#+end_src
* 02 
#+begin_src C -n
#include <stdio.h>

typedef struct {
    char name[20];
    char id[20];
    float cgpa;
} std;

int main() {
    int n; scanf(\"%d%*c\", &n);
    std s[n];
    for (int i = 0; i < n; i++) {
        scanf(\"%[^\\n]%*c\", s[i].name);
        scanf(\"%[^\\n]%*c\", s[i].id);
        scanf(\"%f%*c\", &s[i].cgpa);
    }

    for (int i = 0; i < n; i++) {
        printf(\"Student %d: %s\\n\", i+1, s[i].name);
        printf(\"Student ID: %s\\n\", s[i].id);
        printf(\"CGPA: %.2f\\n\", s[i].cgpa);
    }
}
#+end_src
* 03 
#+begin_src C -n
#include <stdio.h>
#include <math.h>

typedef struct {
    int x, y;
} point;

int main() {
    point a, b;
    scanf(\"%d%d\", &a.x, &a.y);
    scanf(\"%d%d\", &b.x, &b.y);
    float dis = sqrt( (a.x-b.x)*(a.x-b.x) + (a.y-b.y)*(a.y-b.y) );
    printf(\"The distance is %.2f unit\\n\", dis);
}
#+end_src
* 04 
#+begin_src C -n
#include <stdio.h>
#include <math.h>

typedef struct {
    int x, y;
} point;

float dis(point a, point b) {
    return sqrt( (a.x - b.x)*(a.x - b.x) + (a.y - b.y)*(a.y - b.y) );
}

int main() {
    point a, b, c;
    scanf(\"%d%d\", &a.x, &a.y);
    scanf(\"%d%d\", &b.x, &b.y);
    scanf(\"%d%d\", &c.x, &c.y);
    float A = dis(b, c);
    float B = dis(c, a);
    float C = dis(a, b);
    if (A+B <= C || B+C <= A || C+A <= B) {
        puts(\"They are in the same line\");
        return 0;
    }
    float s = (A+B+C) / 2;
    float area = sqrt( s*(s-A)*(s-B)*(s-C) );
    printf(\"The area is %.2f unit\\n\", area);
}
#+end_src
* 05 
#+begin_src C -n
#include <stdio.h>

typedef struct {
    float real, img;
} complex;

int main() {
    complex c;
    scanf(\"%f%f\", &c.real, &c.img);
    printf(\"%.2f%+.2fi\\n\", c.real, c.img);
}
#+end_src
* 06 
#+begin_src C -n
#include <stdio.h>
#include <math.h>

typedef struct {
    float real, img;
} complex;

int main() {
    complex c;
    scanf(\"%f%f\", &c.real, &c.img);

    float mod = sqrt( c.real*c.real + c.img*c.img );
    printf(\"Modulus = %.4f\\n\", mod);
    if (c.img*c.real < 0)
        printf(\"Argument = %.4f\\n\", 3.1416+atan(c.img/c.real));
    else
        printf(\"Argument = %.4f\\n\", atan(c.img/c.real));
}
#+end_src
* 07 
#+begin_src C -n
#include <stdio.h>

typedef struct {
    int real, img;
} complex;

int main() {
    complex a, b;
    scanf(\"%d%d\", &a.real, &a.img);
    scanf(\"%d%d\", &b.real, &b.img);

    printf(\"(%d%+di)+(%d%+di)=%d%+di\\n\",
           a.real, a.img, b.real, b.img,
           a.real+b.real, a.img+b.img);
    
    printf(\"(%d%+di)-(%d%+di)=%d%+di\\n\",
           a.real, a.img, b.real, b.img,
           a.real-b.real, a.img-b.img);
}
#+end_src
* 08 
#+begin_src C -n
#include <stdio.h>

typedef struct {
    int real, img;
} complex;

int main() {
    complex a, b;
    scanf(\"%d%d\", &a.real, &a.img);
    scanf(\"%d%d\", &b.real, &b.img);

    printf(\"(%d%+di)*(%d%+di)=%d%+di\\n\",
           a.real, a.img, b.real, b.img,
           (a.real*b.real)-(a.img*b.img),
           (a.real*b.img)+(a.img*b.real));
}
#+end_src
* 09 
#+begin_src C -n
#include <stdio.h>

typedef struct {
    float real, img;
} complex;

complex mul(complex a, complex b) {
    return (complex) {
        (a.real*b.real)-(a.img*b.img),
        (a.real*b.img)+(a.img*b.real)
    };
}

complex conjugate(complex a) {
    return (complex) { a.real, -a.img };
}

complex div(complex a, complex b) {
    complex num = mul(a, conjugate(b));
    complex denom = mul(b, conjugate(b));
    return (complex) {
        num.real/denom.real, num.img/denom.real
    };
}

void print_complex(complex a) {
    printf(\"(%.2f%+.2fi)\", a.real, a.img);
}

int main() {
    complex a, b;
    scanf(\"%f%f\", &a.real, &a.img);
    scanf(\"%f%f\", &b.real, &b.img);

    print_complex(a);
    putchar('/');
    print_complex(b);
    putchar('=');
    print_complex(div(a, b));
    putchar(\\n);
}
#+end_src
* 10 
#+begin_src C -n
#include <stdio.h>

typedef struct {
    int m, cm;
} length;

int main() {
    length l;
    scanf(\"%d%d\", &l.m, &l.cm);
    printf(\"Length in meter: %.2f\\n\", l.m + (float)l.cm/100);
    printf(\"Length in centimeter: %d\\n\", l.m*100+l.cm);
}
#+end_src
* 11 
#+begin_src C -n
#include <stdio.h>

typedef struct {
    int m, cm;
} length;

length add(length a, length b) {
    return (length) {
        (a.cm + b.cm >= 100) ? a.m + b.m + 1 : a.m + b.m,
        (a.cm + b.cm >= 100) ? (a.cm+b.cm)%100 : a.cm + b.cm
    };
}

int main() {
    length a, b;
    scanf(\"%d%d\", &a.m, &a.cm);
    scanf(\"%d%d\", &b.m, &b.cm);

    length c = add(a, b);
    printf(\"The sum is %d meter %d centimeter\\n\", c.m, c.cm);
}
#+end_src
* 12 
#+begin_src C -n
#include <stdio.h>

typedef struct {
    int h, m, s;
} time;

float h(time t) {
    return t.h + (float)t.m/60 + (float)t.s/3600;
}

float m(time t) {
    return t.h*60 + t.m + (float)t.s/60;
}

int s(time t) {
    return t.h*3600 + t.m*60 + t.s;
}

int main() {
    time t;
    scanf(\"%d%d%d\", &t.h, &t.m, &t.s);

    printf(\"Time interval in hour: %.2f\\n\", h(t));
    printf(\"Time interval in minute: %.2f\\n\", m(t));
    printf(\"Time interval in second: %d\\n\", s(t));
}
#+end_src
* 13 
#+begin_src C -n" . 76) (t 26160 52195 223865 895000) nil ("
" . -1) nil (1 . 5985) (t . -1)) (emacs-undo-equiv-table (3 . -1)))