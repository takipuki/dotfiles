((buffer-size . 2991) (buffer-checksum . "3692391fbff3932ce8d218ac523f2ba7d90c9bc8"))
((emacs-buffer-undo-list nil (":line-numbers" . 2601) ((marker . 2601) . -12) ((marker) . -13) ((marker) . -13) nil (2618 . 2624) nil ("c" . 2601) nil (2635 . 2638) (2616 . 2619) (2595 . 2598) 2597 nil ("
" . -2632) ((marker . 2633) . -1) ((marker . 2633) . -1) ((marker . 2633) . -1) ((marker . 2633) . -1) 2631 nil ("
" . -2632) 2631 nil (" " . 2628) ((marker . 2601) . -1) ("
" . -2629) 2613 nil (nil rear-nonsticky nil 2629 . 2630) (nil fontified nil 2613 . 2630) (2613 . 2630) nil (2612 . 2613) 2595 nil (nil rear-nonsticky nil 2616 . 2617) (nil fontified nil 2595 . 2617) (2595 . 2617) (2594 . 2595) 2549 nil (2594 . 2595) 2593 nil (2591 . 2594) (2570 . 2591) nil ("after " . -2570) ((marker . 2633) . -6) ((marker . 2633) . -6) ((marker . 2600) . -6) 2576 ("execution" . -2576) ((marker . 2633) . -2) ((marker . 2633) . -2) ((marker . 2600) . -9) 2585 (2580 . 2585) ("t" . -2580) ((marker . 2600) . -1) 2581 (2570 . 2581) ("at " . -2570) ((marker . 2633) . -1) ((marker . 2633) . -1) ((marker . 2600) . -3) 2573 (2570 . 2573) ("a" . -2570) ((marker . 2633) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) ("f" . -2571) ((marker . 2600) . -1) 2572 (2552 . 2572) ("Last " . -2552) ((marker . 2633) . -5) ((marker . 2633) . -5) ((marker . 2600) . -5) 2557 ("value " . -2557) ((marker . 2633) . -6) ((marker . 2633) . -6) ((marker . 2600) . -6) 2563 ("of " . -2563) ((marker . 2633) . -1) ((marker . 2633) . -1) ((marker . 2600) . -3) 2566 (2549 . 2566) (2548 . 2549) (2547 . 2548) (t 26173 8288 86318 493000) 2542 nil (2899 . 2902) (2894 . 2897) ("    " . -2880) (2874 . 2880) ("    " . -2846) (2840 . 2846) ("    " . -2807) (2801 . 2807) ("    " . -2786) (2780 . 2786) ("            " . -2770) (2755 . 2770) ("        " . -2739) (2730 . 2739) ("    " . -2686) (2680 . 2686) ("    " . -2667) (2661 . 2667) ("    " . -2622) (2616 . 2622) (2600 . 2603) (2577 . 2580) (2556 . 2559) nil (nil rear-nonsticky nil 2573 . 2574) ("
" . -2868) (2573 . 2869) 2556 nil (nil rear-nonsticky nil 2577 . 2578) (nil fontified nil 2577 . 2578) (nil fontified nil 2574 . 2577) (nil fontified nil 2573 . 2574) (nil fontified nil 2556 . 2573) (2556 . 2578) (2555 . 2556) (2552 . 2555) ("b" . -2552) ((marker . 2633) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) 2553 (2552 . 2553) nil (2549 . 2552) (2548 . 2549) (2547 . 2548) 2546 nil (2542 . 2547) (2541 . 2542) 2541 nil (2533 . 2536) (2528 . 2531) ("    " . -2501) (2495 . 2501) ("    " . -2466) (2460 . 2466) ("    " . -2420) (2414 . 2420) ("    " . -2402) (2396 . 2402) (2380 . 2383) (2374 . 2377) ("    " . -2353) (2347 . 2353) ("    " . -2319) (2313 . 2319) (2233 . 2236) (2211 . 2214) (2189 . 2192) (2168 . 2171) nil (nil rear-nonsticky nil 2185 . 2186) ("
" . -2499) (2185 . 2500) 2168 nil (nil rear-nonsticky nil 2189 . 2190) (nil fontified nil 2168 . 2190) (2168 . 2190) (2167 . 2168) (2164 . 2167) ("w" . -2164) ((marker . 2633) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) 2165 (2161 . 2165) ("   " . -2161) ((marker . 2600) . -3) 2164 (2160 . 2164) (2156 . 2160) (t 26173 7287 827262 666000) 2150 nil (2143 . 2149) nil ("void function(int num) {
if (num > 0) {
function(num / 8);
printf(\"%d\", num % 8);
}
}" . 2143) ((marker . 2601) . -84) ((marker . 2602) . -84) ((marker . 2600) . -84) ((marker . 2143) . -84) (nil rear-nonsticky nil 2227 . 2228) nil (nil rear-nonsticky nil 2227 . 2228) (nil fontified nil 2143 . 2228) (2143 . 2228) nil ("   " . -2143) ((marker . 2600) . -3) 2146 (2142 . 2146) 2129 nil (2129 . 2130) nil (":" . 2129) nil ("c" . 2129) nil (2144 . 2147) (2123 . 2126) 2125 nil ("
" . -2144) 2141 nil (nil rear-nonsticky nil 2144 . 2145) (nil fontified nil 2123 . 2145) (2123 . 2145) (2122 . 2123) (2113 . 2122) (2111 . 2113) (2106 . 2111) (2105 . 2106) (2104 . 2105) (2103 . 2104) (t 26173 6982 895672 785000) 2100 nil (2103 . 2104) 2100 nil (nil rear-nonsticky nil 1363 . 1364) ("
" . -2099) (1363 . 2100) 1348 nil ("
```c:line-numbers
```
" . 1363) ((marker . 2601) . -1) ((marker . 2601) . -22) ((marker . 2602) . -1) ((marker . 2600) . -1) ((marker . 1363) . -1) ((marker . 1363) . -1) (1385 . 1386) (nil rear-nonsticky nil 1363 . 1364) nil (nil rear-nonsticky nil 1363 . 1364) ("
" . -1385) (1363 . 1386) 1348 nil (1364 . 1367) (1363 . 1364) (1355 . 1363) ("s" . -1355) ((marker . 2600) . -1) 1356 (1346 . 1356) nil (1345 . 1346) 1345 nil ("
" . -1344) 1339 nil (1337 . 1338) 1337 nil (1344 . 1345) (1343 . 1344) 1342 nil (1338 . 1343) (1337 . 1338) (t 26173 5622 527291 29000) 1337 nil ("
" . 1337) ((marker . 2602) . -1) ((marker . 2600) . -1) ((marker . 1337) . -1) ("3." . 1338) ((marker . 2602) . -1) ((marker . 2600) . -1) ((marker . 1337) . -1) nil (1338 . 1340) (1337 . 1338) (t 26173 5622 527291 29000) 1337 nil (1336 . 1337) 915 nil ("      " . -1333) (1330 . 1333) nil ("   " . -1336) (1330 . 1336) (1325 . 1328) ("    " . -1310) (1304 . 1310) ("    " . -1302) (1296 . 1302) ("            " . -1283) (1268 . 1283) ("        " . -1263) (1254 . 1263) ("            " . -1239) (1224 . 1239) ("        " . -1163) (1154 . 1163) ("            " . -1141) (1126 . 1141) ("        " . -1091) (1082 . 1091) ("            " . -1064) (1049 . 1064) ("        " . -1021) (1012 . 1021) ("    " . -981) (975 . 981) ("    " . -937) (931 . 937) (915 . 918) (891 . 894) (869 . 872) nil ("   " . 869) ("   " . 891) ("   " . 915) ("      " . 931) (937 . 941) ("      " . 975) (981 . 985) ("         " . 1012) (1021 . 1029) ("               " . 1049) (1064 . 1076) ("         " . 1082) (1091 . 1099) ("               " . 1126) (1141 . 1153) ("         " . 1154) (1163 . 1171) ("               " . 1224) (1239 . 1251) ("         " . 1254) (1263 . 1271) ("               " . 1268) (1283 . 1295) ("      " . 1296) (1302 . 1306) ("      " . 1304) (1310 . 1314) ("   " . 1325) ("      " . 1330) (1336 . 1339) nil ("   " . -1336) (1330 . 1336) (1325 . 1328) ("    " . -1310) (1304 . 1310) ("    " . -1302) (1296 . 1302) ("            " . -1283) (1268 . 1283) ("        " . -1263) (1254 . 1263) ("            " . -1239) (1224 . 1239) ("        " . -1163) (1154 . 1163) ("            " . -1141) (1126 . 1141) ("        " . -1091) (1082 . 1091) ("            " . -1064) (1049 . 1064) ("        " . -1021) (1012 . 1021) ("    " . -981) (975 . 981) ("    " . -937) (931 . 937) (915 . 918) (891 . 894) (869 . 872) nil ("   " . 869) ((marker . 2602) . -2) ((marker . 2600) . -2) ((marker . 869) . -2) ((marker . 869) . -2) ("   " . 891) ("   " . 914) ("   " . 918) (934 . 938) (972 . 976) ("        " . 972) (1011 . 1019) ("            " . 1011) (1051 . 1063) ("                " . 1051) (1085 . 1093) ("            " . 1085) (1132 . 1144) ("                " . 1132) (1161 . 1169) ("            " . 1161) (1234 . 1246) ("                " . 1234) (1265 . 1273) ("            " . 1265) (1282 . 1294) ("                " . 1282) (1311 . 1315) (1313 . 1317) ("        " . 1313) ("    " . 1336) nil (1336 . 1340) (1313 . 1321) ("    " . 1313) ("    " . -1311) (1282 . 1298) ("            " . 1282) (1265 . 1277) ("        " . 1265) (1234 . 1250) ("            " . 1234) (1161 . 1173) ("        " . 1161) (1132 . 1148) ("            " . 1132) (1085 . 1097) ("        " . 1085) (1051 . 1067) ("            " . 1051) (1011 . 1023) ("        " . 1011) (972 . 980) ("    " . 972) ("    " . -934) (918 . 921) (914 . 917) (891 . 894) (869 . 872) nil ("
" . -868) 848 nil (nil rear-nonsticky nil 869 . 870) ("
" . -1294) (869 . 1295) nil ("   " . -869) ((marker . 2600) . -3) 872 (868 . 872) 853 nil (872 . 875) (868 . 872) 867 nil (864 . 868) ("e" . -864) ((marker . 2600) . -1) ("r" . -865) ((marker . 2600) . -1) 866 (851 . 866) (848 . 851) (847 . 848) 846 nil (841 . 847) (840 . 841) (t 26173 3259 175667 537000) 840 nil (744 . 745) (" " . -744) ((marker . 2600) . -1) 745 (739 . 745) (738 . 739) (737 . 738) 737 nil (738 . 739) ("3" . 738) (t 26173 2539 435539 831000) nil (831 . 832) 820 nil (811 . 814) (785 . 788) (768 . 771) 777 nil ("
" . -815) 805 nil (nil rear-nonsticky nil 815 . 816) (nil fontified nil 768 . 816) (768 . 816) nil ("   " . -768) ((marker . 2600) . -3) 771 (767 . 771) 753 nil (771 . 774) (767 . 771) (766 . 767) (760 . 766) ("nu" . -760) ((marker . 2633) . -2) ((marker . 2633) . -2) ((marker . 2600) . -2) 762 (751 . 762) (748 . 751) (747 . 748) ("
" . -747) ((marker . 2600) . -1) 748 ("  " . -748) ((marker . 2600) . -2) 750 (748 . 750) (747 . 748) 743 nil (642 . 643) nil (739 . 746) nil (737 . 739) (736 . 737) (t 26172 63639 703924 932000) 736 nil (735 . 736) 729 nil (717 . 718) (716 . 717) (715 . 716) (698 . 699) (697 . 698) (696 . 697) (682 . 683) (681 . 682) (680 . 681) (666 . 669) nil ("
" . 717) ((marker* . 2611) . 1) nil (nil rear-nonsticky nil 716 . 717) (nil fontified nil 666 . 717) (666 . 717) nil ("copy" . 666) ((marker . 2601) . -3) ((marker . 2602) . -3) ((marker . 2600) . -3) (nil rear-nonsticky nil 669 . 670) nil (nil rear-nonsticky nil 669 . 670) (nil fontified nil 666 . 670) (666 . 670) nil ("   " . -666) ((marker . 2600) . -3) 669 (665 . 669) 648 nil (666 . 669) nil 668 nil (666 . 669) nil ("   " . -666) ((marker . 2600) . -3) 669 (665 . 669) 664 nil (658 . 665) ("c" . -658) ((marker . 2633) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) ("n" . -659) ((marker . 2600) . -1) 660 (652 . 660) ("l" . -652) ((marker . 2633) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) ("i" . -653) ((marker . 2633) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) ("n" . -654) ((marker . 2633) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) 655 (646 . 655) (645 . 646) (640 . 645) nil (637 . 640) ("   " . -637) ((marker . 2600) . -3) 640 (636 . 640) (632 . 636) 628 nil (623 . 624) (622 . 623) (621 . 622) (568 . 569) (567 . 568) (566 . 567) (532 . 533) (531 . 532) (530 . 531) (506 . 507) (505 . 506) (504 . 505) (487 . 488) (486 . 487) (485 . 486) (471 . 472) (470 . 471) (469 . 470) (467 . 468) (466 . 467) (465 . 466) (462 . 463) (461 . 462) (460 . 461) (443 . 444) (442 . 443) (441 . 442) (390 . 391) (389 . 390) (388 . 389) (355 . 356) (354 . 355) (353 . 354) (323 . 324) (322 . 323) (321 . 322) (271 . 272) (270 . 271) (269 . 270) (267 . 268) (266 . 267) (265 . 266) (262 . 263) (261 . 262) (260 . 261) (224 . 225) (223 . 224) (222 . 223) (189 . 190) (188 . 189) (187 . 188) (139 . 140) (138 . 139) (137 . 138) (135 . 136) (134 . 135) (133 . 134) (111 . 114) nil ("    " . 111) ("    " . 135) ("        " . 186) (194 . 198) ("            " . 222) (234 . 242) ("    " . 261) ("    " . 268) ("        " . 321) (329 . 333) ("        " . 354) (362 . 366) ("            " . 390) (402 . 410) ("        " . 444) (452 . 456) ("    " . 464) ("    " . 471) ("        " . 488) (496 . 500) ("        " . 508) (516 . 520) ("        " . 535) (543 . 547) ("        " . 572) (580 . 584) ("    " . 628) ("    " . 634) (638 . 641) nil ("   " . -638) (634 . 638) (628 . 632) ("    " . -580) (572 . 580) ("    " . -543) (535 . 543) ("    " . -516) (508 . 516) ("    " . -496) (488 . 496) (471 . 475) (464 . 468) ("    " . -452) (444 . 452) ("        " . -402) (390 . 402) ("    " . -362) (354 . 362) ("    " . -329) (321 . 329) (268 . 272) (261 . 265) ("        " . -234) (222 . 234) ("    " . -194) (186 . 194) (135 . 139) (111 . 115) 128 nil ("
" . -110) ((marker . 2602) . -1) 90 nil (nil rear-nonsticky nil 111 . 112) ("
" . -566) (111 . 567) nil ("https://nurulalamador.github.io/UIUQuestionBank/question.html?id=CSE1112&term=final&tri=231-B" . 111) ((marker . 2601) . -92) ((marker . 2602) . -92) ((marker . 2600) . -92) (nil rear-nonsticky nil 203 . 204) nil (nil rear-nonsticky nil 203 . 204) (nil fontified nil 111 . 204) (111 . 204) nil ("   " . -111) ((marker . 2600) . -3) 114 (110 . 114) 95 nil (114 . 117) (110 . 114) 109 nil (90 . 110) (89 . 90) ("
" . -89) ((marker . 2600) . -1) ("
" . -90) ((marker . 2600) . -1) 91 (89 . 91) (83 . 89) nil (82 . 83) 82 nil ("
1. WAP
   ```c:line-numbers
   #include <stdio.h>
   
   int isEven(int n) {
       return !(n % 2);
   }
   
   int ComputeEvenSum(int *ar, int n) {
       int sum = 0;
       for (int i = 0; i < n; i++)
           if (isEven(ar[i])) sum += ar[i];
       return sum;
   }
   
   int main() {
       int ar[] = {1, 2, 3, 2};
       printf(\"%d\\n\", ComputeEvenSum(ar, 4));
   }
   ```

2. output
   ```:line-numbers
   1 3 5 2
   8 3 4 2
   16 3 4 12
   32 29 4 12
   ```
   

## 02

1. output
   ```:line-numbers
   Hello
   # Gen Z
   ```

2. WAP
   ```c:line-numbers
   #include <stdio.h>
   
   int main() {
       char s[100];
       int slen = 0;
       for (; (s[slen] = getchar()) != '\\n'; slen++) {
           if (s[slen] >= 'A' && s[slen] <= 'Z')
               s[slen] += ' ';
       }
       s[slen] = '\\0';
   
       char sub[100];
       int sublen = 0;
       for (; (sub[sublen] = getchar()) != '\\n'; sublen++) {
           if (sub[sublen] >= 'A' && sub[sublen] <= 'Z')
               sub[sublen] += ' ';
       }
       sub[sublen] = '\\0';
   
       int count = 0;
       for (int i = 0; i < slen - (sublen - 1); i++) {
           if (s[i] == sub[0]) {
               int flag = 1;
               for (int j = 1; j < sublen; j++)
                   if (s[i+j] != sub[j])
                       flag = 0;
               if (flag) count++;
           }
       }
       printf(\"%d\\n\", count);
   }
   ```
   

## 03

```c:line-numbers
#include <stdio.h>
#include <string.h>

typedef struct {
    char name[50], country[50], type[10];
    int wickets[30], runs[30], matches;
    float score;
} Cricketer;

#define n 100

int main() {
    Cricketer ar[n];
    int max_score = 0, max_indx = 0;
    for (int i = 0; i < n; i++) {
        scanf(\" %[^\\n]\", ar[i].name);
        scanf(\" %[^\\n]\", ar[i].country);
        scanf(\" %[^\\n]\", ar[i].type);

        int wicks = 0;
        for (int j = 0; j < 30; j++) {
            scanf(\"%d\", &ar[i].wickets[j]);
            wicks += ar[i].wickets[j];
        }

        int runs = 0;
        for (int j = 0; j < 30; j++) {
            scanf(\"%d\", &ar[i].runs[j]);
            runs += ar[i].runs[j];
        }

        scanf(\"%d\", &ar[i].matches);

        if (strcmp(ar[i].type, \"bowler\") == 0)
            ar[i].score = (float)wicks / ar[i].matches;
        else
            ar[i].score = (float)runs / ar[i].matches;

        if (ar[i].score > max_score) {
            max_score = ar[i].score;
            max_indx = i;
        }
    }

    printf(\"Name: %s\\n\", ar[max_indx].name);
    printf(\"Country: %s\\n\", ar[max_indx].country);
    printf(\"Type: %s\\n\", ar[max_indx].type);

    printf(\"Wickets:\");
    for (int i = 0; i < 30; i++)
        printf(\" %d\", ar[max_indx].wickets[i]);
    putchar('\\n');

    printf(\"Runs: \");
    for (int i = 0; i < 30; i++)
        printf(\" %d\", ar[max_indx].runs[i]);
    putchar('\\n');
    
    printf(\"Matches: %d\\n\", ar[max_indx].matches);
    printf(\"Score: %.2f\\n\", ar[max_indx].score);
}
```


## 04

1. output
   ```:line-numbers
   10 21 40
   20 24 40
   ```
   
2. output
   ```:line-numbers
   0 1 2 0 3 0 1
   ```
   
   
## 05

1. WAP
   ```c:line-numbers
   #include <stdio.h>
   
   int main() {
       FILE *fptr = fopen(\"sample.txt\", \"r\");
       int sum = 0;
       for (int i; fscanf(fptr, \" %d \", &i) != EOF;) {
           if (i % 2 == 0 && i % 4 == 0)
               sum += i;
       }
   
       printf(\"%d\\n\", sum);
   
       fclose(fptr);
   }
   ```
   
2. WAP
   ```c:line-numbers
   #include <stdio.h>
   
   int sumOfOddElements(int *arr, int size) {
       if (size == 0) return 0;
       if (*arr % 2)
           return *arr + sumOfOddElements(arr+1, size-1);
       return sumOfOddElements(arr+1, size-1);
   }
   
   int main() {
       int numbers[] = {10, 21, 35, 42, 57, 68, 73};
       int n = sizeof(numbers) / sizeof(numbers[0]);
       int sum = sumOfOddElements(numbers, n);
       printf(\"Sum of odd elements: %d\\n\", sum);
       return 0;
   }
   ```
" . 82) ((marker . 2601) . -3983) nil (73 . 74) ("t" . -73) ((marker . 2600) . -1) 74 (69 . 74) ("ummer" . 69) ((marker . 2601) . -4) (t 26172 59835 480038 862000) nil (69 . 74) ("sp" . 69) ((marker . 2602) . -1) ((marker . 2600) . -1) nil (69 . 71) ("ummer" . 69) ((marker . 2601) . -4) (t 26172 59835 480038 862000) nil ("
" . -1) nil (1 . 4067) (t . -1) nil ("
---
head:
  - - link
    - href: /custom.css
      rel: stylesheet
---

# 23 Summer

## 01

1. WAP
   ```c:line-numbers
   #include <stdio.h>
   
   int isEven(int n) {
       return !(n % 2);
   }
   
   int ComputeEvenSum(int *ar, int n) {
       int sum = 0;
       for (int i = 0; i < n; i++)
           if (isEven(ar[i])) sum += ar[i];
       return sum;
   }
   
   int main() {
       int ar[] = {1, 2, 3, 2};
       printf(\"%d\\n\", ComputeEvenSum(ar, 4));
   }
   ```

2. output
   ```:line-numbers
   1 3 5 2
   8 3 4 2
   16 3 4 12
   32 29 4 12
   ```
   

## 02

1. output
   ```:line-numbers
   Hello
   # Gen Z
   ```

2. WAP
   ```c:line-numbers
   #include <stdio.h>
   
   int main() {
       char s[100];
       int slen = 0;
       for (; (s[slen] = getchar()) != '\\n'; slen++) {
           if (s[slen] >= 'A' && s[slen] <= 'Z')
               s[slen] += ' ';
       }
       s[slen] = '\\0';
   
       char sub[100];
       int sublen = 0;
       for (; (sub[sublen] = getchar()) != '\\n'; sublen++) {
           if (sub[sublen] >= 'A' && sub[sublen] <= 'Z')
               sub[sublen] += ' ';
       }
       sub[sublen] = '\\0';
   
       int count = 0;
       for (int i = 0; i < slen - (sublen - 1); i++) {
           if (s[i] == sub[0]) {
               int flag = 1;
               for (int j = 1; j < sublen; j++)
                   if (s[i+j] != sub[j])
                       flag = 0;
               if (flag) count++;
           }
       }
       printf(\"%d\\n\", count);
   }
   ```
   

## 03

```c:line-numbers
#include <stdio.h>
#include <string.h>

typedef struct {
    char name[50], country[50], type[10];
    int wickets[30], runs[30], matches;
    float score;
} Cricketer;

#define n 100

int main() {
    Cricketer ar[n];
    int max_score = 0, max_indx = 0;
    for (int i = 0; i < n; i++) {
        scanf(\" %[^\\n]\", ar[i].name);
        scanf(\" %[^\\n]\", ar[i].country);
        scanf(\" %[^\\n]\", ar[i].type);

        int wicks = 0;
        for (int j = 0; j < 30; j++) {
            scanf(\"%d\", &ar[i].wickets[j]);
            wicks += ar[i].wickets[j];
        }

        int runs = 0;
        for (int j = 0; j < 30; j++) {
            scanf(\"%d\", &ar[i].runs[j]);
            runs += ar[i].runs[j];
        }

        scanf(\"%d\", &ar[i].matches);

        if (strcmp(ar[i].type, \"bowler\") == 0)
            ar[i].score = (float)wicks / ar[i].matches;
        else
            ar[i].score = (float)runs / ar[i].matches;

        if (ar[i].score > max_score) {
            max_score = ar[i].score;
            max_indx = i;
        }
    }

    printf(\"Name: %s\\n\", ar[max_indx].name);
    printf(\"Country: %s\\n\", ar[max_indx].country);
    printf(\"Type: %s\\n\", ar[max_indx].type);

    printf(\"Wickets:\");
    for (int i = 0; i < 30; i++)
        printf(\" %d\", ar[max_indx].wickets[i]);
    putchar('\\n');

    printf(\"Runs: \");
    for (int i = 0; i < 30; i++)
        printf(\" %d\", ar[max_indx].runs[i]);
    putchar('\\n');
    
    printf(\"Matches: %d\\n\", ar[max_indx].matches);
    printf(\"Score: %.2f\\n\", ar[max_indx].score);
}
```


## 04

1. output
   ```:line-numbers
   10 21 40
   20 24 40
   ```
   
2. output
   ```:line-numbers
   0 1 2 0 3 0 1
   ```
   
   
## 05

1. WAP
   ```c:line-numbers
   #include <stdio.h>
   
   int main() {
       FILE *fptr = fopen(\"sample.txt\", \"r\");
       int sum = 0;
       for (int i; fscanf(fptr, \" %d \", &i) != EOF;) {
           if (i % 2 == 0 && i % 4 == 0)
               sum += i;
       }
   
       printf(\"%d\\n\", sum);
   
       fclose(fptr);
   }
   ```
   
2. WAP
   ```c:line-numbers
   #include <stdio.h>
   
   int sumOfOddElements(int *arr, int size) {
       if (size == 0) return 0;
       if (*arr % 2)
           return *arr + sumOfOddElements(arr+1, size-1);
       return sumOfOddElements(arr+1, size-1);
   }
   
   int main() {
       int numbers[] = {10, 21, 35, 42, 57, 68, 73};
       int n = sizeof(numbers) / sizeof(numbers[0]);
       int sum = sumOfOddElements(numbers, n);
       printf(\"Sum of odd elements: %d\\n\", sum);
       return 0;
   }
   ```
" . 1) ((marker . 2633) . -36) ((marker . 2601) . -71) ((marker . 2601) . -71) ((marker . 2602) . -48) ((marker* . 2992) . 4005) ((marker . 1348) . -68) ((marker* . 2611) . 4005) ((marker . 2633) . -36) ((marker . 2600) . -48) nil ("
ol li {
    list-style-type: lower-alpha;
}
" . 72) ((marker . 2601) . -44) ((marker . 2601) . -44) ((marker* . 2992) . 44) (116 . 117) (nil rear-nonsticky nil 72 . 73) nil (1 . 73) ("
" . 1) ("<style>" . 1) ((marker . 2633) . -5) ((marker . 2633) . -5) nil ("
<style>
" . 52) ((marker . 2601) . -1) ((marker . 2601) . -8) ((marker . 2602) . -2) ((marker* . 2611) . 7) ((marker . 2600) . -2) (60 . 61) (nil rear-nonsticky nil 52 . 53) nil ("/" . 54) nil (54 . 55) nil (nil rear-nonsticky nil 52 . 53) ("
" . -60) (52 . 61) 51 nil (1 . 8) (1 . 2) ("
---
head:
  - - link
    - href: /custom.css
      rel: stylesheet
---
" . 1) ((marker . 2633) . -36) ((marker . 2601) . -71) ((marker . 2602) . -68) ((marker . 1348) . -68) ((marker . 2633) . -36) nil (nil rear-nonsticky nil 72 . 73) ("
" . -116) (72 . 117) 71 nil ("
ol li {
    list-style-type: lower-alpha;
}
" . 68) ((marker . 2600) . -1) ((marker . 2601) . -1) ((marker . 2601) . -44) ((marker . 2602) . -1) (112 . 113) (nil rear-nonsticky nil 68 . 69) nil (nil rear-nonsticky nil 68 . 69) ("
" . -112) (68 . 113) 61 nil (1 . 4077) (t . -1)) (emacs-pending-undo-list (207 . 208) 206 nil (nil face (rainbow-delimiters-depth-1-face font-lock-string-face) 35 . 36) (nil fontified t 35 . 36) (nil c-in-sws t 35 . 36) (35 . 36) 18 nil (261 . 265) (220 . 224) (199 . 203) (189 . 197) (138 . 150) (105 . 113) (70 . 74) 1 (t 26173 8391 920870 812000) nil ("
 " . 253) ((marker . 356) . -2) ((marker . 356) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker) . -1) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 2633) . -2) ((marker . 2600) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ("for" . 255) ((marker . 356) . -2) ((marker . 356) . -2) ((marker . 299) . -1) ((marker . 299) . -1) ((marker . 299) . -1) ((marker . 299) . -1) ((marker . 299) . -1) ((marker . 299) . -1) ((marker . 299) . -1) ((marker . 299) . -1) ((marker . 299) . -1) ((marker . 299) . -1) ((marker . 299) . -1) ((marker . 299) . -1) ((marker . 299) . -1) ((marker . 299) . -1) ((marker . 299) . -1) ((marker . 299) . -1) ((marker . 299) . -1) ((marker . 299) . -1) ((marker . 299) . -1) ((marker . 299) . -1) ((marker . 299) . -1) ((marker . 299) . -1) ((marker . 299) . -1) ((marker . 299) . -1) ((marker . 299) . -1) ((marker . 299) . -1) ((marker . 299) . -1) ((marker . 299) . -1) ((marker . 299) . -1) ((marker . 299) . -1) ((marker . 299) . -1) ((marker . 299) . -1) ((marker . 299) . -1) ((marker . 299) . -1) ((marker . 299) . -1) ((marker . 299) . -1) ((marker . 299) . -1) ((marker . 299) . -1) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -3) ((marker . 299) . -3) ((marker . 299) . -3) ((marker . 299) . -3) ((marker . 299) . -3) ((marker . 299) . -3) ((marker . 299) . -3) ((marker . 299) . -3) ((marker . 299) . -3) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 2633) . -2) ((marker . 2600) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) ((marker . 299) . -2) nil (255 . 258) (253 . 255) (t 26173 8391 920870 812000) 221 nil (255 . 256) 254 nil (nil rear-nonsticky nil 254 . 255) (nil fontified nil 37 . 255) (nil fontified nil 36 . 37) (nil fontified nil 19 . 36) (nil fontified nil 18 . 19) (18 . 255) nil ("#include <stdio.h>

int main() {
    FILE *fptr = fopen(\"Sample.txt\", \"r\");
    int sum = 0;
    for (int i; fscanf(fptr, \"%d\", &i) != EOF;)
        if (i % 7 == 0)
            sum += i;
    fclose(fptr);

    fptr = fopen(\"Output.txt\", \"w\");
    fprintf(fptr, \"%d\\n\", sum);
    fclose(fptr);
}
" . 18) ((marker . 35) . -18) ((marker . 18) . -19) ((marker . 18) . -19) ((marker . 18) . -19) ((marker . 381) . -294) ((marker* . 357) . 173) ((marker . 18) . -19) ((marker . 18) . -19) ((marker . 18) . -19) ((marker . 18) . -19) ((marker . 18) . -19) ((marker . 18) . -19) ((marker . 18) . -19) ((marker . 18) . -19) ((marker . 18) . -19) ((marker . 18) . -19) ((marker . 18) . -19) ((marker . 18) . -19) ((marker . 18) . -19) ((marker . 18) . -19) ((marker . 18) . -19) ((marker . 18) . -19) ((marker . 18) . -19) ((marker . 18) . -19) ((marker . 18) . -19) ((marker . 18) . -202) ((marker . 18) . -202) ((marker . 18) . -202) ((marker . 18) . -202) ((marker . 18) . -202) ((marker . 18) . -202) ((marker . 18) . -202) ((marker . 18) . -202) ((marker . 18) . -202) ((marker . 18) . -202) ((marker . 18) . -202) ((marker . 18) . -202) ((marker . 18) . -202) ((marker . 18) . -202) ((marker . 18) . -202) ((marker . 18) . -202) ((marker . 18) . -202) ((marker . 18) . -202) ((marker . 18) . -202) ((marker . 18) . -202) ((marker . 18) . -202) ((marker . 18) . -202) ((marker . 18) . -202) ((marker . 18) . -202) ((marker . 18) . -202) ((marker . 18) . -80) ((marker . 18) . -80) ((marker . 18) . -80) ((marker . 18) . -80) ((marker . 18) . -80) ((marker . 18) . -80) ((marker . 18) . -80) ((marker . 18) . -80) ((marker . 18) . -80) ((marker . 18) . -80) ((marker . 18) . -80) ((marker . 18) . -80) ((marker . 18) . -80) ((marker . 18) . -80) ((marker . 18) . -80) ((marker . 18) . -80) ((marker . 18) . -80) ((marker . 18) . -191) ((marker . 18) . -186) ((marker . 18) . -186) ((marker . 18) . -204) ((marker . 18) . -204) ((marker . 18) . -93) ((marker . 18) . -93) (t 26173 8260 221765 798000) nil (139 . 140) (138 . 139) (134 . 138) (t 26173 8251 618056 176000) nil (285 . 286) (")" . -284) (284 . 285) (")" . -284) (284 . 285) (280 . 284) (279 . 280) ("\"" . -278) (278 . 279) ("\"" . -278) (277 . 279) (274 . 277) (273 . 275) ("\"" . -273) (272 . 274) (271 . 272) (267 . 271) ("\"" . -267) ((marker . 2600) . -1) ("\"" . 268) (267 . 269) ("\"" . -267) (267 . 268) (266 . 268) (259 . 266) (254 . 259) 222 nil (nil rear-nonsticky nil 258 . 259) ("
" . -272) (254 . 273) 253 nil ("    " . 254) ("
" . -254) 221 nil (254 . 259) (253 . 254) (")" . -252) (252 . 253) (")" . -252) (252 . 253) ("\"" . -251) (251 . 252) ("\"" . -251) (250 . 252) (249 . 251) ("\"" . -249) (248 . 250) (247 . 248) ("\"" . -246) (246 . 247) ("\"" . -246) (236 . 247) (235 . 237) ("\"" . -235) (235 . 236) (234 . 236) (222 . 234) (218 . 222) ("    " . 217) ((marker . 2600) . -4) (221 . 222) (216 . 221) 199 nil ("
    " . 216) ((marker . 356) . -1) ((marker . 2600) . -5) ((marker . 18) . -1) (217 . 221) nil ("    " . -217) ((marker . 2600) . -4) 221 (216 . 221) 199 nil ("
    " . 198) ((marker . 356) . -1) ((marker . 2600) . -5) ((marker . 18) . -1) (199 . 203) nil ("    " . -199) ((marker . 2600) . -4) 203 (198 . 203) 177 nil (109 . 110) (98 . 109) ("i" . -98) ((marker . 18) . -1) ((marker . 18) . -1) ((marker . 18) . -1) ((marker . 18) . -1) ((marker . 18) . -1) ((marker . 18) . -1) ((marker . 18) . -1) ((marker . 18) . -1) ((marker . 18) . -1) ((marker . 18) . -1) ((marker . 18) . -1) ((marker . 18) . -1) ((marker . 2600) . -1) ((marker . 18) . -1) ((marker . 18) . -1) ((marker . 18) . -1) ((marker . 18) . -1) ((marker . 18) . -1) ((marker) . -1) 99 (98 . 99) (93 . 98) 71 nil (180 . 181) (172 . 180) (159 . 172) (")" . -158) (158 . 159) (")" . -158) (158 . 159) (155 . 158) (" " . -155) ((marker . 2600) . -1) 156 (151 . 156) (148 . 151) (147 . 149) (144 . 147) (135 . 144) (" " . -135) ((marker . 2600) . -1) 136 ("{" . -136) ((marker . 2600) . -1) ("}" . 137) (136 . 138) (135 . 136) ("
" . -135) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) 136 ("        " . -136) ((marker . 356) . -8) ((marker . 2633) . -8) ((marker . 2600) . -8) 144 ("sum " . -144) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -4) 148 ("+= " . -148) ((marker . 2600) . -3) 151 (144 . 151) (135 . 144) (")" . -134) (134 . 135) (")" . -134) (134 . 135) (" " . -134) ((marker . 2600) . -1) 135 (134 . 135) (133 . 134) (126 . 133) (")" . -125) (125 . 126) (")" . -125) (125 . 126) (122 . 125) (121 . 122) ("\"" . -120) (120 . 121) ("\"" . -120) (118 . 121) (117 . 119) ("\"" . -117) (117 . 118) (116 . 118) (111 . 116) ("c" . -111) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) ("s" . -112) ((marker . 2600) . -1) 113 (112 . 113) ("a" . -112) ((marker . 2600) . -1) ("n" . -113) ((marker . 2600) . -1) ("f" . -114) ((marker . 2600) . -1) 115 (109 . 115) (108 . 109) (103 . 108) ("f" . -103) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) 104 (103 . 104) ("int " . -103) ((marker . 2600) . -4) 107 (103 . 107) (102 . 104) (98 . 102) (94 . 98) (94 . 95) 110 nil (110 . 111) (")" . -109) (109 . 110) (")" . -109) (109 . 110) ("0" . -109) ((marker . 18) . -1) ((marker . 18) . -1) ((marker . 18) . -1) ((marker . 18) . -1) ((marker . 18) . -1) ((marker . 18) . -1) ((marker . 18) . -1) ((marker . 18) . -1) ((marker . 18) . -1) ((marker . 18) . -1) ((marker . 18) . -1) ((marker . 18) . -1) ((marker . 18) . -1) ((marker . 18) . -1) ((marker . 18) . -1) ((marker . 18) . -1) ((marker . 18) . -1) ((marker . 18) . -1) ((marker . 18) . -1) ((marker . 18) . -1) ((marker . 2600) . -1) ((marker . 18) . -1) ((marker . 18) . -1) ((marker . 18) . -1) ((marker . 18) . -1) ((marker . 18) . -1) ((marker) . -1) (";" . -110) ((marker . 18) . -1) ((marker . 18) . -1) ((marker . 18) . -1) ((marker . 2600) . -1) ((marker . 18) . -1) ((marker . 18) . -1) ((marker . 18) . -1) ((marker . 18) . -1) ((marker . 18) . -1) ((marker) . -1) 111 (110 . 111) (105 . 110) ("FILE *stream" . 105) (98 . 118) ("fcl" . -98) ((marker . 356) . -3) ((marker . 2633) . -3) ((marker . 2600) . -3) 101 (98 . 101) (93 . 98) 67 nil (61 . 68) (60 . 61) (55 . 60) nil 79 nil (79 . 80) nil (")" . -77) ((marker . 2600) . -1) 78 (77 . 78) (")" . -77) (77 . 78) (76 . 77) (75 . 77) ("\"" . -75) (74 . 76) (73 . 74) ("\"" . -72) (72 . 73) ("\"" . -72) (62 . 73) ("s" . -62) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) ("a" . -63) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) ("m" . -64) ((marker . 2600) . -1) ("p" . -65) ((marker . 2600) . -1) 66 (62 . 66) (61 . 63) ("\"" . -61) (61 . 62) (60 . 62) (55 . 60) (apply yas--snippet-revive 38 57 #s(yas--snippet nil nil #s(yas--exit 55 nil) 11 nil nil nil nil)) (apply yas--take-care-of-redo #s(yas--snippet nil nil #s(yas--exit 55 nil) 11 nil nil nil nil)) (38 . 57) ("main()" . 38) ((marker . 2600) . -6) 44 (")" . -43) (43 . 44) (")" . -43) (43 . 44) (42 . 44) (38 . 42) (37 . 38) (37 . 38) ("#include <math.h>

void calc(float x, float a, float b, float c, float d, float *w, float *m) {
    *w = c * (1 - exp(-(d*x)));
    *m = a * pow(*w, b);
}

int main() {
    float w, m;
    calc(35, 0.87, 0.45, 800, 3.5, &w, &m);
    printf(\"weight: %.2f\\n\", w);
    printf(\"milk: %.2f\\n\", m);
}
" . 37) ((marker . 35) . -17) ((marker . 18) . -118) ((marker* . 382) . 177) ((marker . 18) . -118) ((marker . 18) . -118) ((marker . 381) . -294) ((marker* . 357) . 178) ((marker . 18) . -293) ((marker . 18) . -118) ((marker . 18) . -153) ((marker . 18) . -153) ((marker . 18) . -153) ((marker . 18) . -118) ((marker . 18) . -118) ((marker . 18) . -118) ((marker . 18) . -114) ((marker . 18) . -114) ((marker . 18) . -293) ((marker . 18) . -293) ((marker . 18) . -293) ((marker . 18) . -117) ((marker . 18) . -117) ((marker . 18) . -117) (t 26173 7471 744709 615000) nil (37 . 54) nil ("#include <math.h>" . 37) ((marker . 35) . -17) ((marker . 381) . -16) (t 26173 7471 744709 615000) nil (331 . 332) 155 nil (" " . 155) nil ("2.718," . 155) ((marker . 18) . -6) ((marker . 381) . -5) ((marker . 18) . -6) ((marker . 18) . -6) ((marker . 18) . -6) nil (154 . 161) nil (154 . 155) nil (" " . 154) ((marker* . 357) . 1) nil ("(2.718," . 154) ((marker . 18) . -1) ((marker . 18) . -1) ((marker . 18) . -7) ((marker . 381) . -6) ((marker* . 357) . 7) ((marker . 18) . -1) ((marker . 18) . -7) ((marker . 18) . -7) ((marker . 18) . -7) nil (151 . 154) ("pow" . 151) ((marker . 381) . -2) ((marker . 18) . -2) ((marker . 18) . -2) ((marker . 2600) . -2) 153 nil ("
" . 338) ((marker* . 357) . 1) (t 26173 7456 870764 800000) nil (337 . 338) ("kj" . 337) ((marker . 356) . -1) ((marker . 2600) . -1) ((marker . 18) . -1) nil (337 . 339) ("}" . 337) (t 26173 7456 870764 800000) nil (338 . 339) 153 nil (151 . 154) ("exp" . 151) ((marker . 356) . -3) ((marker . 2633) . -3) nil ("
" . 338) (t 26173 7452 690593 212000) nil (338 . 339) 161 nil (155 . 162) nil ("
" . 331) (t 26173 7447 267037 427000) nil (331 . 332) 190 nil ("2.718, " . 155) ((marker . 356) . -6) ((marker . 18) . -6) ((marker . 381) . -6) ((marker . 2600) . -6) 161 nil (151 . 154) ("pow" . 151) ((marker . 381) . -2) ((marker . 2600) . -2) 153 nil (nil rear-nonsticky nil 337 . 338) (nil fontified nil 57 . 338) (nil fontified nil 55 . 57) (nil fontified nil 38 . 55) (nil fontified nil 37 . 38) (nil fontified nil 19 . 37) (nil fontified nil 18 . 19) (18 . 338) nil ("#include <stdio.h>

void function(int num) {
    if (num > 0) {
        function(num / 8);
        printf(\"%d\", num % 8);
    }
}

95
 |--> 11
       |--> 1
            |--> 0
            |1
       |3
 |7

int main() {
    function(95);
}
" . 18) ((marker . 35) . -18) ((marker . 356) . -237) ((marker . 18) . -237) ((marker . 381) . -238) ((marker . 356) . -239) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -20) ((marker . 18) . -45) ((marker . 18) . -211) ((marker . 18) . -211) ((marker . 18) . -130) ((marker . 18) . -130) ((marker . 18) . -130) ((marker . 18) . -130) ((marker . 18) . -66) ((marker . 18) . -66) ((marker . 18) . -132) ((marker . 18) . -132) ((marker . 18) . -128) ((marker . 18) . -128) ((marker . 18) . -93) ((marker . 18) . -203) ((marker . 18) . -133) ((marker . 18) . -133) ((marker . 18) . -131) ((marker . 2633) . -239) nil ("// 13
" . 257) ((marker . 381) . -5) ((marker . 356) . -4) ((marker* . 357) . 1) ((marker . 2633) . -4) ((marker . 2600) . -4) 261 nil ("7" . 262) nil (apply 42 149 224 undo--wrap-and-run-primitive-undo 149 224 (("/* " . 149) (" */" . 154) ("/* " . 158) (" */" . 169) ("/* " . 173) (" */" . 189) ("/* " . 193) (" */" . 214) ("/* " . 218) (" */" . 235) ("/* " . 239) (" */" . 251) ("/* " . 255) (" */" . 261) ((marker . 18) . -3) 154)) nil (apply -42 149 266 undo--wrap-and-run-primitive-undo 149 266 ((261 . 264) (255 . 258) (251 . 254) (239 . 242) (235 . 238) (218 . 221) (214 . 217) (193 . 196) (189 . 192) (173 . 176) (169 . 172) (158 . 161) (154 . 157) (149 . 152))) nil (262 . 263) nil (261 . 262) (" " . -261) ((marker . 2600) . -1) 262 (259 . 262) (257 . 259) (256 . 257) 255 nil (221 . 222) (219 . 221) (" " . -219) ((marker . 2600) . -1) (" " . -220) ((marker . 2600) . -1) (" " . -221) ((marker . 2600) . -1) (" " . -222) ((marker . 2600) . -1) (" " . -223) ((marker . 2600) . -1) (" " . -224) ((marker . 2600) . -1) (" " . -225) ((marker . 2600) . -1) 226 (219 . 226) (218 . 219) 217 nil (217 . 218) (216 . 217) (" " . -216) ((marker . 2600) . -1) 217 (209 . 217) (208 . 209) 207 nil (207 . 208) (194 . 207) (193 . 194) 192 nil (175 . 193) (174 . 175) nil (173 . 174) nil ("8" . 159) (160 . 161) 159 ("8" . 158) (159 . 160) 158 nil (161 . 173) (160 . 161) nil (158 . 160) (157 . 158) nil (">" . 154) nil (154 . 155) nil (154 . 155) nil ("-" . 154) nil (154 . 155) nil ("-" . 154) nil (152 . 153) nil (149 . 150) ("8" . 149) nil (153 . 156) ("_" . -153) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) ("_" . -154) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) 155 (152 . 155) (" " . -152) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) ("|" . -153) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) (">" . -154) ((marker . 2600) . -1) 155 (154 . 155) (" " . -154) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) ("-" . -155) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) (">" . -156) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) 157 (152 . 157) ("|" . -152) ((marker . 2600) . -1) 153 (152 . 153) (" " . -152) ((marker . 2600) . -1) 153 ("|" . -153) ((marker . 2600) . -1) 154 (152 . 154) ("|" . -152) ((marker . 2600) . -1) 153 (152 . 153) (151 . 152) (" " . -151) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) ("-" . -152) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) (">" . -153) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) (" " . -154) ((marker . 2600) . -1) 155 (149 . 155) (148 . 149) (148 . 149) nil ("
" . 148) ((marker . 356) . -1) ((marker . 2600) . -1) ((marker . 18) . -1) nil (148 . 149) 148 nil ("
" . 148) ((marker . 356) . -1) ((marker . 2600) . -1) ((marker . 18) . -1) nil (148 . 149) 148 nil (179 . 180) (" " . 179) nil (161 . 166) (" " . 161) nil (apply yas--snippet-revive 18 36 #s(yas--snippet nil nil nil 10 nil nil nil nil)) (apply yas--take-care-of-redo #s(yas--snippet nil nil nil 10 nil nil nil nil)) (18 . 36) ("io" . 18) ((marker . 2600) . -2) 20 (18 . 20) (17 . 18) 1 nil (17 . 18) (t 26173 7075 302390 732000) 6 nil (43 . 156) ("if (num > 0) {
function(num / 8);
printf(\"%d\", num % 8);
}
}

int main() {
    function(95);
" . 43) ((marker . 356) . -79) ((marker . 1) . -75) ((marker . 381) . -92) ((marker . 356) . -79) ((marker* . 357) . 1) ((marker . 2633) . -75) ((marker . 2600) . -75) (t 26173 7071 435579 891000) nil (137 . 138) 118 nil (134 . 135) (133 . 134) (")" . -133) (133 . 134) (131 . 133) ("8" . -131) ((marker . 2600) . -1) ("5" . -132) ((marker . 2600) . -1) (")" . -133) ((marker . 2600) . -1) 134 (")" . -133) (133 . 134) (")" . -133) (133 . 134) (131 . 133) ("int num" . 131) (122 . 139) ("fu" . -122) ((marker . 356) . -2) ((marker . 2633) . -2) ((marker . 2600) . -2) 124 (122 . 124) (apply yas--snippet-revive 105 124 #s(yas--snippet nil nil #s(yas--exit 122 nil) 9 nil nil nil nil)) (apply yas--take-care-of-redo #s(yas--snippet nil nil #s(yas--exit 122 nil) 9 nil nil nil nil)) (105 . 124) ("main()" . 105) ((marker . 2600) . -6) 111 (")" . -110) (110 . 111) (")" . -110) (110 . 111) (109 . 111) (105 . 109) (104 . 105) (t 26173 7052 911558 828000) 104 nil (103 . 104) 102 nil (nil rear-nonsticky nil 102 . 103) (nil fontified nil 19 . 103) (nil fontified nil 18 . 19) (18 . 103) nil ("#include <stdio.h>

typedef struct {
    int id;
    char name[50];
    float salary;
    int scores[12];
} Employee;

#define N 3

int main() {
    Employee ar[N];
    for (int i = 0; i < N; i++) {
        scanf(\"%d\", &ar[i].id);
        scanf(\" %[^\\n]\", ar[i].name);
        scanf(\"%f\", &ar[i].salary);
        for (int j = 0; j < 12; j++)
            scanf(\"%d\", ar[i].scores+j);
    }

    for (int i = 0; i < N; i++) {
        float sum = 0;
        for (int j = 0; j < 12; j++)
            sum += ar[i].scores[j];
        if (sum / 12 > 80)
            printf(\"Employee with id=%d is eligible for increment.\\n\", ar[i].id);
        else
            printf(\"Employee with id=%d is not eligible for increment.\\n\", ar[i].id);
    }
}
" . 18) ((marker . 35) . -18) ((marker . 356) . -736) ((marker . 381) . -735) ((marker* . 357) . 47) ((marker . 18) . -18) ((marker . 18) . -117) ((marker . 18) . -117) ((marker . 18) . -117) ((marker . 18) . -117) ((marker . 18) . -119) ((marker . 18) . -119) ((marker . 18) . -119) ((marker . 18) . -119) ((marker . 18) . -144) ((marker . 18) . -143) ((marker . 18) . -230) ((marker . 18) . -230) ((marker . 18) . -438) ((marker . 18) . -438) ((marker . 18) . -438) ((marker . 18) . -131) ((marker . 18) . -736) ((marker . 18) . -736) (t 26173 6832 80038 731000) nil (753 . 754) 750 nil (703 . 707) nil (nil rear-nonsticky nil 671 . 672) ("
" . -741) (659 . 742) 658 nil (" " . 659) nil (" x" . -659) (659 . 661) ("else" . 659) ((marker . 356) . -4) ((marker . 2633) . -4) (655 . 659) 660 (659 . 660) (" x" . -659) (659 . 661) ("else" . 659) ((marker . 356) . -4) ((marker . 2633) . -4) ((marker . 2600) . -4) (655 . 659) 659 (655 . 659) (647 . 655) (647 . 648) ("        }
" . 647) ((marker . 381) . -9) ((marker . 2600) . -8) 655 nil (" {" . 564) ((marker . 381) . -1) nil (647 . 648) (")" . -646) (646 . 647) (")" . -646) (646 . 647) (643 . 646) ("]" . -642) (642 . 643) ("]" . -642) (641 . 643) (638 . 642) (637 . 638) (636 . 637) nil (632 . 633) nil (633 . 634) (612 . 633) (603 . 612) (" " . -603) ((marker . 2600) . -1) ("%" . -604) ((marker . 2600) . -1) 605 (595 . 605) (587 . 595) ("Empl" . -587) ((marker . 356) . -4) ((marker . 2633) . -4) ((marker . 2600) . -4) 591 (587 . 591) ("%" . -587) ((marker . 2600) . -1) 588 (587 . 588) (586 . 588) ("\"" . -586) (586 . 587) (585 . 587) (579 . 585) (567 . 579) (566 . 576) (565 . 567) (564 . 565) ("{}" . 564) ((marker . 381) . -1) ((marker* . 357) . 1) nil ("        " . 565) ((marker* . 357) . 8) ("
" . -565) ((marker* . 357) . 1) ("            " . 565) ("
" . -565) 564 nil (566 . 578) (565 . 575) (564 . 566) ("
" . -564) ((marker . 2600) . -1) 565 ("            " . -565) ((marker . 2600) . -12) 577 (564 . 577) (" " . -564) ((marker . 2600) . -1) 565 (564 . 565) (")" . -563) (563 . 564) (")" . -563) (563 . 564) (555 . 563) (554 . 555) (550 . 554) (549 . 551) (546 . 549) ("a" . -546) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) ("v" . -547) ((marker . 2600) . -1) 548 (546 . 548) (537 . 546) 506 nil ("        }
" . 538) ((marker . 381) . -9) ((marker . 2600) . -8) 546 nil (" {" . 501) ((marker . 381) . -1) nil (538 . 539) ("]" . -537) (537 . 538) ("]" . -537) (536 . 538) (535 . 537) ("+" . -535) ((marker . 2600) . -1) 536 (535 . 536) (529 . 535) ("sco" . -529) ((marker . 356) . -3) ((marker . 2633) . -3) ((marker . 2600) . -3) 532 (528 . 532) ("]" . -527) (527 . 528) ("]" . -527) (526 . 528) ("i" . -526) ((marker . 2600) . -1) 527 (526 . 527) (521 . 527) ("+" . -521) ((marker . 2600) . -1) (" " . -522) ((marker . 2600) . -1) 523 (516 . 523) (apply yas--snippet-revive 473 526 #s(yas--snippet nil (#s(yas--field 1 478 487 nil nil nil t #s(yas--field 2 489 495 nil nil nil t #s(yas--field 3 497 500 nil nil nil t #s(yas--exit 516 nil)))) #s(yas--field 2 489 495 nil nil nil t #s(yas--field 3 497 500 nil nil nil t #s(yas--exit 516 nil))) #s(yas--field 3 497 500 nil nil nil t #s(yas--exit 516 nil))) #s(yas--exit 516 nil) 8 nil #s(yas--field 3 497 500 nil nil nil t #s(yas--exit 516 nil)) nil nil)) (498 . 500) ("++i" . 498) (497 . 498) (493 . 495) ("n" . -493) ((marker . 2600) . -1) 494 (490 . 494) ("i < N" . 490) (489 . 490) (479 . 487) ("i = 0" . 479) (478 . 479) (apply yas--take-care-of-redo #s(yas--snippet nil (#s(yas--field 1 478 487 nil nil nil t #s(yas--field 2 489 495 nil nil nil t #s(yas--field 3 497 500 nil nil nil t #s(yas--exit 516 nil)))) #s(yas--field 2 489 495 nil nil nil t #s(yas--field 3 497 500 nil nil nil t #s(yas--exit 516 nil))) #s(yas--field 3 497 500 nil nil nil t #s(yas--exit 516 nil))) #s(yas--exit 516 nil) 8 nil #s(yas--field 3 497 500 nil nil nil t #s(yas--exit 516 nil)) nil nil)) (512 . 520) (499 . 511) ("    " . -499) (473 . 505) ("for" . 473) ((marker . 356) . -2) ((marker . 2633) . -2) ((marker . 2600) . -3) 476 (473 . 476) (464 . 473) 446 nil ("        for (int j = 0; j < )
" . 465) ((marker . 381) . -29) ((marker . 356) . -14) ((marker* . 357) . 2) ((marker . 2633) . -14) ((marker . 2600) . -27) 492 nil (488 . 493) (487 . 488) (482 . 487) ("i" . -482) ((marker . 2600) . -1) (" " . -483) ((marker . 2600) . -1) 484 (479 . 484) ("t" . -479) ((marker . 2600) . -1) ("n" . -480) ((marker . 2600) . -1) 481 (478 . 481) (477 . 479) (474 . 477) (473 . 474) (464 . 473) 462 nil (459 . 463) nil ("i" . 460) ((marker . 356) . -1) ((marker . 2633) . -1) nil (460 . 461) nil (456 . 459) ("avg" . 456) ((marker . 381) . -2) ((marker . 18) . -2) ((marker . 18) . -3) ((marker . 2600) . -1) 457 nil (450 . 455) ("l" . -450) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) ("f" . -451) ((marker . 2600) . -1) 452 (450 . 452) ("int" . 450) ((marker . 381) . -2) ((marker . 356) . -2) nil (450 . 453) ("float" . 450) ((marker . 381) . -4) ((marker . 356) . -4) ((marker . 2633) . -4) ((marker . 2600) . -2) 452 nil (458 . 459) ("i" . 458) nil (458 . 459) ("g" . 458) nil (459 . 460) (" " . -459) ((marker . 2600) . -1) ("=" . -460) ((marker . 2600) . -1) (" " . -461) ((marker . 2600) . -1) ("0" . -462) ((marker . 2600) . -1) 463 (450 . 463) (442 . 450) (441 . 447) (440 . 442) (439 . 440) (")" . -438) (438 . 439) (")" . -438) (438 . 439) (434 . 438) (433 . 434) (427 . 433) (426 . 427) (417 . 426) (416 . 418) (412 . 416) (408 . 412) ("    " . 407) ((marker . 2600) . -4) (411 . 412) (406 . 411) 401 nil (399 . 400) (")" . -398) (398 . 399) (")" . -398) (398 . 399) (396 . 398) (390 . 396) ("sco" . -390) ((marker . 356) . -3) ((marker . 2633) . -3) ((marker . 2600) . -3) 393 (389 . 393) ("]" . -388) (388 . 389) ("]" . -388) (387 . 389) (384 . 388) (383 . 384) (382 . 383) ("\"" . -381) (381 . 382) ("\"" . -381) (380 . 382) (379 . 380) (378 . 380) ("\"" . -378) (378 . 379) (377 . 379) (372 . 377) (359 . 372) 343 nil (307 . 308) nil (237 . 238) nil ("            " . 357) ("
" . -357) 332 nil (357 . 370) (" " . -357) ((marker . 2600) . -1) 358 ("{" . -358) ((marker . 2600) . -1) ("}" . 359) (358 . 360) (357 . 358) (")" . -356) (356 . 357) (")" . -356) (356 . 357) (352 . 356) (351 . 352) (345 . 351) (" " . -345) ((marker . 2600) . -1) 346 (344 . 346) (343 . 344) (338 . 343) ("i" . -338) ((marker . 2600) . -1) (" " . -339) ((marker . 2600) . -1) ("=" . -340) ((marker . 2600) . -1) (" " . -341) ((marker . 2600) . -1) 342 (334 . 342) (333 . 335) (329 . 333) (320 . 329) 317 nil (312 . 318) ("sala" . -312) ((marker . 356) . -4) ((marker . 2633) . -4) ((marker . 2600) . -4) 316 (312 . 316) ("id" . 312) ((marker . 381) . -1) nil (302 . 303) ("d" . 302) nil (279 . 283) ("id" . 279) ((marker . 381) . -1) nil (266 . 269) (265 . 267) ("d" . 265) nil (263 . 264) nil (nil rear-nonsticky nil 255 . 256) ("
" . -309) (247 . 310) 246 nil ("
        scanf(\"%d\", ar[i].id);
        scanf(\"%d\", ar[i].id);
        scanf(\"%d\", ar[i].id);
" . 247) ((marker . 356) . -9) ((marker . 1) . -1) ((marker . 381) . -93) ((marker . 2600) . -9) ((marker . 18) . -9) ((marker . 18) . -9) (340 . 341) (nil rear-nonsticky t 255 . 256) nil (nil rear-nonsticky nil 255 . 256) ("
" . -340) (247 . 341) 246 nil (246 . 247) (")" . -245) (245 . 246) (")" . -245) (245 . 246) (243 . 245) ("n" . -243) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) ("a" . -244) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) ("m" . -245) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) ("e" . -246) ((marker . 2600) . -1) 247 (242 . 247) ("]" . -241) (241 . 242) ("]" . -241) (240 . 242) (236 . 241) (235 . 236) ("\"" . -234) (234 . 235) ("\"" . -234) (232 . 235) (231 . 233) ("\"" . -231) (231 . 232) (230 . 232) (225 . 230) (217 . 225) (216 . 222) (215 . 217) (214 . 215) (")" . -213) (213 . 214) (")" . -213) (213 . 214) (209 . 213) (208 . 209) (202 . 208) (201 . 202) (192 . 201) (191 . 193) (187 . 191) (182 . 187) (181 . 182) ("]" . -180) (180 . 181) ("]" . -180) (179 . 181) (175 . 180) (167 . 175) ("Emp" . -167) ((marker . 356) . -3) ((marker . 2633) . -3) ((marker . 2600) . -3) 170 (167 . 170) (162 . 167) 160 nil (145 . 148) (apply yas--snippet-revive 137 145 #s(yas--snippet nil nil #s(yas--exit 145 nil) 7 nil nil nil nil)) (apply yas--take-care-of-redo #s(yas--snippet nil nil #s(yas--exit 145 nil) 7 nil nil nil nil)) (137 . 145) ("d" . 137) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) 138 (137 . 138) (137 . 138) nil ("#define () {}
" . 137) ((marker . 35) . -13) ((marker . 381) . -13) ((marker . 2600) . -11) 148 nil ("
" . -164) ((marker* . 357) . 1) 163 nil ("
    " . 164) ((marker . 356) . -4) ((marker . 2600) . -4) ((marker . 18) . -4) nil (164 . 169) 163 nil (147 . 150) (")" . -146) (146 . 147) (")" . -146) (146 . 147) (145 . 147) (143 . 145) (" " . -143) ((marker . 35) . -1) ((marker . 2600) . -1) 144 (143 . 144) ("e" . -143) ((marker . 35) . -1) ((marker . 2600) . -1) ("n" . -144) ((marker . 35) . -1) ((marker . 2600) . -1) 145 ("(" . -145) ((marker . 35) . -1) ((marker . 2600) . -1) (")" . 146) ((marker . 35) . -1) (144 . 147) (" " . -144) ((marker . 35) . -1) ((marker . 2600) . -1) ("(" . -145) ((marker . 35) . -1) ((marker . 2600) . -1) (")" . -146) ((marker . 35) . -1) ((marker . 2600) . -1) (" " . -147) ((marker . 35) . -1) ((marker . 2600) . -1) 148 ("{" . -148) ((marker . 35) . -1) ((marker . 2600) . -1) ("}" . 149) ((marker . 35) . -1) (147 . 150) (")" . -146) (146 . 147) (")" . -146) (146 . 147) (145 . 147) (apply yas--snippet-revive 137 145 #s(yas--snippet nil nil #s(yas--exit 145 nil) 6 nil nil nil nil)) (apply yas--take-care-of-redo #s(yas--snippet nil nil #s(yas--exit 145 nil) 6 nil nil nil nil)) (137 . 145) ("d" . 137) ((marker . 356) . -1) ((marker . 356) . -1) ((marker . 18) . -1) ((marker . 18) . -1) ((marker . 2600) . -1) 138 nil (137 . 138) ("d" . 137) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) (137 . 138) ("#define " . 137) ((marker . 35) . -8) ((marker . 356) . -7) ((marker . 2600) . -7) ((marker . 18) . -7) nil (apply yas--snippet-revive 137 145 #s(yas--snippet nil nil #s(yas--exit #<marker at 18 in main.c> nil) 5 nil nil nil nil)) (apply yas--take-care-of-redo #s(yas--snippet nil nil #s(yas--exit #<marker at 18 in main.c> nil) 5 nil nil nil nil)) (137 . 145) ("d" . 137) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) 138 (137 . 138) ("d" . 137) ((marker . 356) . -1) ((marker . 356) . -1) ((marker . 18) . -1) ((marker . 18) . -1) nil ("
" . 138) ((marker . 356) . -1) ((marker . 2600) . -1) ((marker . 18) . -1) nil (138 . 139) 137 nil (137 . 138) ("de" . 137) ((marker . 356) . -1) ((marker . 356) . -2) ((marker . 2633) . -2) ((marker . 2600) . -1) ((marker . 18) . -1) nil (137 . 139) ("d" . -137) ((marker . 356) . -1) ((marker . 18) . -1) ((marker . 2600) . -1) 138 nil (137 . 138) (136 . 137) (135 . 136) 124 nil ("
" . 135) ((marker . 18) . -1) ((marker . 35) . -1) ((marker . 356) . -1) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) ((marker . 18) . -1) ("
" . 136) ((marker . 18) . -1) ((marker . 35) . -1) ((marker . 356) . -1) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) ((marker . 18) . -1) ("d" . 137) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) (137 . 138) ("d " . 137) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -2) (137 . 139) ("#define " . 137) ((marker . 35) . -8) ((marker . 356) . -7) ((marker . 2600) . -7) ((marker . 18) . -7) nil (apply yas--snippet-revive 137 145 #s(yas--snippet nil nil #s(yas--exit #<marker at 18 in main.c> nil) 4 nil nil nil nil)) (apply yas--take-care-of-redo #s(yas--snippet nil nil #s(yas--exit #<marker at 18 in main.c> nil) 4 nil nil nil nil)) (137 . 145) ("d" . 137) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) 138 (" " . -138) ((marker . 2600) . -1) 139 (137 . 139) ("d" . -137) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) 138 (137 . 138) (136 . 137) (135 . 136) 124 nil ("
" . 135) ((marker . 356) . -1) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) ((marker . 18) . -1) ("
" . 136) ((marker . 356) . -1) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) ((marker . 18) . -1) ("d" . 137) ((marker . 356) . -1) ((marker . 2633) . -1) nil (137 . 138) (136 . 137) (135 . 136) 124 nil ("
" . 135) ((marker . 356) . -1) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) ((marker . 18) . -1) ("
" . 136) ((marker . 356) . -1) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) ((marker . 18) . -1) ("define" . 137) ((marker . 356) . -5) ((marker . 356) . -2) ((marker . 2633) . -2) ((marker . 2600) . -5) ((marker . 18) . -5) nil (137 . 143) (136 . 137) (135 . 136) 124 nil ("
" . 135) ((marker . 356) . -1) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) ((marker . 18) . -1) ("define" . 136) ((marker . 356) . -6) ((marker . 356) . -2) ((marker . 2633) . -2) ((marker . 2600) . -6) ((marker . 18) . -6) ("
" . 142) ((marker . 356) . -1) ((marker . 2600) . -1) ((marker . 18) . -1) nil (142 . 143) (136 . 142) (135 . 136) 124 nil ("    " . -150) ((marker . 2600) . -4) 154 (149 . 154) 147 nil (134 . 135) nil (131 . 134) (125 . 131) nil (122 . 123) ("]" . -121) (121 . 122) ("]" . -121) (119 . 122) (114 . 120) ("r" . -114) ((marker . 2600) . -1) ("o" . -115) ((marker . 2600) . -1) 116 (108 . 116) (103 . 108) (102 . 103) (90 . 102) (85 . 90) (84 . 85) ("]" . -83) (83 . 84) ("]" . -83) (83 . 84) (";" . -83) ((marker . 2600) . -1) 84 (83 . 84) (81 . 83) (71 . 82) (66 . 71) (65 . 66) (59 . 65) (55 . 59) (54 . 56) (53 . 55) (52 . 53) (46 . 52) ("stru" . -46) ((marker . 356) . -4) ((marker . 2633) . -4) ((marker . 2600) . -4) 50 (45 . 50) (38 . 45) ("ty" . -38) ((marker . 356) . -2) ((marker . 2633) . -2) ((marker . 2600) . -2) 40 (38 . 40) (37 . 38) (nil face (rainbow-delimiters-depth-1-face font-lock-string-face) 36 . 37) (nil fontified t 36 . 37) (nil c-in-sws t 36 . 37) (36 . 37) 29 nil ("
" . 36) ((marker . 356) . -1) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) ((marker . 18) . -1) (nil fontified nil 36 . 37) (nil face nil 36 . 37) ("
" . 37) ((marker . 356) . -1) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) ((marker . 18) . -1) ("ty" . 38) ((marker . 356) . -2) ((marker . 2633) . -2) ((marker . 2600) . -2) (38 . 40) ("typedef" . 38) ((marker . 356) . -6) ((marker . 2600) . -6) ((marker . 18) . -6) nil (38 . 45) ("ty" . -38) ((marker . 356) . -2) ((marker . 2633) . -2) ((marker . 2600) . -2) 40 (38 . 40) (37 . 38) (nil face (rainbow-delimiters-depth-1-face font-lock-string-face) 36 . 37) (nil fontified t 36 . 37) (nil c-in-sws t 36 . 37) (36 . 37) 29 nil ("
" . -50) ((marker . 2600) . -1) 51 ("    " . -51) ((marker . 2600) . -4) 55 (apply yas--snippet-revive 38 57 #s(yas--snippet nil nil #s(yas--exit 55 nil) 3 nil nil nil nil)) (apply yas--take-care-of-redo #s(yas--snippet nil nil #s(yas--exit 55 nil) 3 nil nil nil nil)) (38 . 57) ("main()" . 38) ((marker . 2600) . -6) 44 (")" . -43) (43 . 44) (")" . -43) (43 . 44) (42 . 44) (38 . 42) (36 . 38) (apply yas--snippet-revive 18 36 #s(yas--snippet nil nil nil 2 nil nil nil nil)) (apply yas--take-care-of-redo #s(yas--snippet nil nil nil 2 nil nil nil nil)) (18 . 36) ("io" . 18) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -2) 20 (18 . 20) nil ("
" . 18) ((marker . 356) . -1) ((marker . 2600) . -1) ((marker . 18) . -1) ((marker . 18) . -1) ("main" . 19) ((marker . 2600) . -4) ("()" . 23) ((marker . 2600) . -2) (")" . 24) (24 . 25) (")" . 24) (24 . 25) (19 . 25) ("int main() {
    
}" . 19) ((marker . 356) . -16) ((marker* . 357) . 2) ((marker . 2600) . -16) ((marker . 18) . -16) ((marker . 18) . -16) nil (apply yas--snippet-revive 19 38 #s(yas--snippet nil nil #s(yas--exit #<marker at 18 in main.c> nil) 1 nil nil nil nil)) (apply yas--take-care-of-redo #s(yas--snippet nil nil #s(yas--exit #<marker at 18 in main.c> nil) 1 nil nil nil nil)) (19 . 38) ("main()" . 19) ((marker . 2600) . -6) 25 (")" . -24) (24 . 25) (")" . -24) (24 . 25) (23 . 25) (19 . 23) (18 . 19) 18 nil ("#include <stdio.h>
#include <string.h>

int main() {
    char str[100]; scanf(\" %[^\\n]\", str);
    for (char *s = str; *s; s++) {
        if (*s == 'z' || *s == 'Z')
            putchar(*s - 25);
        else if (strchr(\"aeiouAEIOU\", *s))
            putchar(*s);
        else if ((*s >= 'a' && *s <= 'z') || *s >= 'A' && *s <= 'Z')
            putchar(*s+1);
        else
            putchar(*s);
    }
    putchar('\\n');
}
" . 18) ((marker . 35) . -18) ((marker . 18) . -281) ((marker* . 382) . 119) ((marker . 18) . -281) ((marker . 18) . -281) ((marker . 381) . -424) ((marker* . 357) . 6) ((marker . 18) . -423) ((marker . 18) . -423) ((marker . 18) . -423) ((marker . 18) . -423) ((marker . 18) . -423) ((marker . 18) . -423) ((marker . 18) . -423) ((marker . 18) . -276) ((marker . 18) . -231) ((marker . 18) . -272) ((marker . 18) . -272) ((marker . 18) . -272) ((marker . 18) . -216) ((marker . 18) . -221) ((marker . 18) . -355) ((marker . 18) . -261) ((marker . 18) . -404) (t 26173 5534 803239 71000) nil (435 . 437) (434 . 436) ("'" . -434) (434 . 435) ("\\" . -434) ((marker . 2600) . -1) 435 (434 . 435) ("10" . 434) ((marker . 381) . -1) nil ("This is Karim reporting. We are ready to start from the zoo.
" . 416) ((marker . 381) . -60) ((marker* . 357) . 1) nil (447 . 448) ("
" . -447) 443 nil (nil rear-nonsticky nil 475 . 476) (nil fontified nil 416 . 476) (416 . 476) nil ("        " . -416) ((marker . 2600) . -8) 424 (415 . 424) (t 26173 5492 821301 456000) 413 nil ("1" . 413) nil ("+" . 413) nil (nil rear-nonsticky nil 402 . 403) ("
" . -417) (390 . 418) 389 nil (" x" . -390) (390 . 392) ("else" . 390) ((marker . 356) . -4) ((marker . 2633) . -4) ((marker . 2600) . -4) (386 . 390) 390 (386 . 390) (377 . 386) (t 26173 5488 157752 950000) 376 nil (334 . 335) ("a" . 334) nil (347 . 348) ("z" . 347) ((marker . 381) . -1) nil (nil rear-nonsticky nil 348 . 349) (nil fontified nil 327 . 349) (327 . 349) nil (nil rear-nonsticky nil 323 . 324) (nil fontified nil 323 . 324) (323 . 324) 322 nil (" " . 322) nil (nil rear-nonsticky nil 322 . 323) (nil fontified nil 300 . 323) (300 . 323) (299 . 301) ("*s >= 'a' && *s <= 'z' " . 299) ((marker . 356) . -22) ((marker . 18) . -22) ((marker . 381) . -22) ((marker . 356) . -15) ((marker . 2633) . -15) nil ("*" . -325) ((marker . 2600) . -1) 326 (325 . 326) (321 . 325) ("'" . -320) (320 . 321) ("'" . -320) (319 . 321) (318 . 320) ("'" . -318) (313 . 319) (312 . 313) (308 . 312) ("'" . -307) (307 . 308) ("'" . -307) (306 . 308) ("z" . -306) ((marker . 2600) . -1) 307 (306 . 307) (305 . 307) ("'" . -305) (305 . 306) (300 . 305) (299 . 300) (298 . 300) (295 . 298) (294 . 295) (" x" . -294) (294 . 296) ("else" . 294) ((marker . 18) . -4) ((marker . 2600) . -4) (290 . 294) 294 nil (239 . 249) ("bb" . 239) ((marker . 381) . -1) ((marker . 356) . -1) ((marker . 2633) . -1) (240 . 241) ("cdfgh" . 240) ((marker . 381) . -5) ("jklmnpqrstv" . 245) ((marker . 381) . -10) (255 . 256) ("u" . 255) (255 . 256) ("v" . 255) (255 . 256) ("vw" . 255) ((marker . 381) . -2) ("xyz" . 257) ((marker . 381) . -2) nil ("+1" . 290) nil (330 . 331) nil (330 . 331) (t 26173 5442 372307 856000) nil (239 . 260) nil ("bcdfghjklmnpqrstvwxyz" . 239) ((marker . 381) . -20) ((marker . 356) . -1) ((marker . 2633) . -1) (t 26173 5442 372307 856000) nil ("1" . 330) nil ("+" . 330) nil (290 . 292) (t 26173 5437 182068 556000) nil (257 . 260) (255 . 257) ("v" . -255) ((marker . 2600) . -1) 256 (255 . 256) ("u" . -255) ((marker . 2600) . -1) 256 (255 . 256) ("v" . -255) ((marker . 2600) . -1) 256 (245 . 256) (240 . 245) ("b" . -240) ((marker . 2600) . -1) 241 (239 . 241) ("aeiouAEIOU" . 239) ((marker . 381) . -9) ((marker . 18) . -10) ((marker . 2600) . -2) 241 nil ("else" . 290) ((marker . 356) . -4) ((marker . 1) . -4) ((marker . 381) . -4) ((marker . 356) . -4) ((marker . 18) . -4) ((marker . 18) . -4) ((marker . 2633) . -4) ((marker . 18) . -4) (294 . 298) (" x" . 294) (294 . 296) (" " . 294) ((marker . 356) . -1) ((marker . 1) . -1) ((marker . 381) . -1) ((marker . 356) . -1) ((marker . 18) . -1) ((marker . 18) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) ((marker . 18) . -1) ("if " . 295) ((marker . 356) . -3) ((marker . 1) . -3) ((marker . 381) . -3) ((marker . 356) . -3) ((marker . 18) . -3) ((marker . 18) . -3) ((marker . 2633) . -3) ((marker . 2600) . -3) ((marker . 18) . -3) ("()" . 298) ((marker . 356) . -1) ((marker . 1) . -1) ((marker . 381) . -1) ((marker . 356) . -1) ((marker* . 357) . 1) ((marker . 18) . -1) ((marker . 18) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) ((marker . 18) . -1) ("str" . 299) ((marker . 356) . -2) ((marker . 381) . -2) ((marker . 356) . -3) ((marker . 2633) . -2) ((marker . 2600) . -2) ((marker . 18) . -2) nil (299 . 302) ("is" . 299) ((marker . 356) . -1) ((marker . 2600) . -1) ((marker . 18) . -1) nil (299 . 301) ("str" . 299) ((marker . 381) . -2) ((marker . 356) . -3) ((marker . 2633) . -3) ((marker . 2600) . -2) 301 nil (299 . 302) ("*" . 299) ((marker . 356) . -1) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) ((marker . 18) . -1) ("s <" . 300) ((marker . 356) . -2) ((marker . 356) . -2) ((marker . 2633) . -2) ((marker . 2600) . -3) ((marker . 18) . -2) (302 . 303) (">= '" . 302) ((marker . 356) . -3) ((marker . 356) . -3) ((marker . 2633) . -3) ((marker . 2600) . -3) ((marker . 18) . -3) (305 . 306) ("''" . 305) ((marker . 356) . -1) ((marker . 356) . -1) ((marker* . 357) . 1) ((marker . 2633) . -1) ((marker . 2600) . -1) ((marker . 18) . -1) ("a" . 306) ((marker . 356) . -1) ((marker . 2633) . -1) nil (306 . 307) (305 . 307) ("'" . -305) (302 . 306) ("<" . -302) ((marker . 2600) . -1) 303 (300 . 303) (299 . 300) ("str" . 299) ((marker . 381) . -2) ((marker . 356) . -3) ((marker . 2633) . -3) ((marker . 2600) . -2) 301 nil (299 . 302) (298 . 300) (295 . 298) (294 . 295) (" x" . -294) (294 . 296) ("else" . 294) ((marker . 18) . -4) ((marker . 2600) . -4) (290 . 294) 294 nil (" " . 249) ((marker . 356) . -1) ((marker . 2600) . -1) ((marker . 18) . -1) (t 26173 5383 6238 555000) nil (249 . 250) (t 26173 5365 248754 27000) nil (253 . 254) (252 . 253) (251 . 252) (250 . 251) nil ("*s, " . 238) ((marker . 356) . -3) ((marker . 18) . -3) ((marker . 381) . -3) ((marker . 2600) . -3) 241 (t 26173 5353 91527 576000) nil (343 . 344) (")" . -342) (342 . 343) (")" . -342) (342 . 343) (340 . 342) (339 . 341) (332 . 339) (327 . 332) 326 nil (320 . 321) (")" . -319) (319 . 320) (")" . -319) (319 . 320) (316 . 319) (315 . 316) (314 . 316) (312 . 314) (307 . 312) (294 . 307) 293 nil ("
            " . 294) ((marker . 356) . -1) ((marker . 2600) . -13) ((marker . 18) . -1) ("else" . 290) (294 . 298) (" x" . 294) (294 . 296) (295 . 307) nil ("            " . -295) ((marker . 2600) . -12) (" x" . -294) (294 . 296) ("else" . 294) ((marker . 356) . -4) ((marker . 2633) . -4) (290 . 294) 307 (294 . 307) 293 nil (" x" . -294) (294 . 296) ("else" . 294) ((marker . 356) . -4) ((marker . 2633) . -4) ((marker . 2600) . -4) (290 . 294) 294 (290 . 294) (281 . 290) (280 . 281) (")" . -279) (279 . 280) (")" . -279) (279 . 280) (278 . 279) (277 . 278) (276 . 278) (269 . 276) (256 . 269) nil (248 . 253) ("aeiou" . 248) 252 nil (nil rear-nonsticky nil 252 . 253) (nil fontified nil 248 . 253) (248 . 253) 247 nil ("A" . -248) ((marker . 2600) . -1) ("E" . -249) ((marker . 2600) . -1) 250 (247 . 250) (243 . 247) (242 . 244) ("\"" . -242) (241 . 243) (240 . 241) (239 . 240) (238 . 239) ("\"" . -238) ((marker . 2600) . -1) ("\"" . 239) (238 . 240) ("\"" . -238) (238 . 239) (237 . 239) (231 . 237) ("*" . -231) ((marker . 2600) . -1) 232 (231 . 232) (230 . 232) (228 . 230) (" " . -228) ((marker . 2600) . -1) 229 (227 . 229) (226 . 227) (" x" . -226) (226 . 228) ("else" . 226) ((marker . 356) . -4) ((marker . 2633) . -4) ((marker . 2600) . -4) (222 . 226) 226 (222 . 226) (213 . 222) 212 nil (212 . 213) (")" . -211) (211 . 212) (")" . -211) (211 . 212) (209 . 211) (206 . 209) (205 . 206) (204 . 205) (203 . 205) (196 . 203) ("p" . -196) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) ("u" . -197) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) ("t" . -198) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) 199 (196 . 199) (183 . 196) (")" . -182) (182 . 183) (")" . -182) (182 . 183) ("'" . -181) (181 . 182) ("'" . -181) (180 . 182) (179 . 181) ("'" . -179) (174 . 180) (" " . -174) ((marker . 2600) . -1) 175 (174 . 175) (173 . 174) (169 . 173) ("'" . -168) (168 . 169) ("'" . -168) (167 . 169) (166 . 168) ("'" . -166) (161 . 167) (160 . 161) (159 . 161) (156 . 159) ("i" . -156) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) ("f" . -157) ((marker . 2600) . -1) 158 (156 . 158) (148 . 156) (147 . 153) (146 . 148) (145 . 146) (")" . -144) (144 . 145) (")" . -144) (144 . 145) (140 . 144) (139 . 140) (138 . 139) (137 . 138) (136 . 137) (135 . 136) (128 . 135) (127 . 128) (122 . 127) (121 . 123) (117 . 121) (112 . 117) (111 . 112) (")" . -110) (110 . 111) (")" . -110) (110 . 111) (106 . 110) (105 . 106) ("\"" . -104) (104 . 105) ("\"" . -104) (104 . 105) (" " . -104) ((marker . 2600) . -1) 105 (104 . 105) ("]" . -103) (103 . 104) ("]" . -103) (100 . 104) (97 . 101) ("%" . -97) ((marker . 2600) . -1) 98 (97 . 98) (96 . 98) ("\"" . -96) (96 . 97) (95 . 97) (92 . 95) ("n" . -92) ((marker . 2600) . -1) ("a" . -93) ((marker . 2600) . -1) 94 (91 . 94) (89 . 91) (88 . 89) (" " . -88) ((marker . 2600) . -1) 89 (88 . 89) ("]" . -87) (87 . 88) ("]" . -87) (84 . 88) (75 . 85) ("s" . -75) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) ("t" . -76) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) 77 (75 . 77) (70 . 75) 58 nil ("    char ar[26];
" . 71) ((marker . 356) . -17) ((marker . 18) . -17) ((marker . 18) . -17) ((marker . 18) . -17) ((marker . 381) . -16) ((marker . 356) . -17) ((marker . 18) . -17) ((marker . 18) . -17) ((marker . 18) . -17) ((marker . 18) . -17) ((marker . 18) . -17) ((marker . 18) . -15) ((marker . 18) . -17) ((marker . 2633) . -17) nil ("    ar[0] = 'a';
    for (int i = 1; i < 25; i++) {
        if (strchr(\"aeiou\", 'a'+i)) {
            ar[i] = 'a' + i;
            ar[i-1] = 'a' + i + 1;
        } else {
            ar[i] = 'a' + i + 1;
        }
    }
    ar[25] = 'a';

    char str[100]; scanf(\" %[^\\n]\", str);
    for (char *s = str; *s; s++) {
        putchar()
    }
" . 88) ((marker . 356) . -338) ((marker . 18) . -338) ((marker . 18) . -4) ((marker . 381) . -339) ((marker . 356) . -331) ((marker* . 357) . 8) ((marker . 18) . -70) ((marker . 18) . -70) ((marker . 18) . -340) ((marker . 18) . -85) ((marker . 18) . -340) ((marker . 18) . -280) ((marker . 2633) . -331) ((marker . 2600) . -4) 92 nil (419 . 421) (412 . 419) (404 . 412) (403 . 409) (402 . 404) (401 . 402) (")" . -400) (400 . 401) (")" . -400) (400 . 401) (397 . 400) ("i" . -397) ((marker . 2600) . -1) 398 (396 . 398) (395 . 396) (394 . 395) (393 . 394) (392 . 393) (391 . 392) (" " . -391) ((marker . 2600) . -1) 392 (391 . 392) (" " . -391) ((marker . 2600) . -1) 392 (391 . 392) ("," . -391) ((marker . 2600) . -1) (" " . -392) ((marker . 2600) . -1) 393 (392 . 393) (391 . 392) (386 . 391) (" " . -386) ((marker . 2600) . -1) 387 (385 . 387) (";" . -385) ((marker . 2600) . -1) (" " . -386) ((marker . 2600) . -1) 387 (386 . 387) (385 . 386) (384 . 385) (383 . 384) (378 . 383) ("i" . -378) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) 379 (378 . 379) nil (365 . 366) ("t" . -365) ((marker . 2600) . -1) 366 (364 . 366) nil (337 . 339) nil (373 . 375) (369 . 373) (364 . 369) 327 nil ("
    " . 364) ((marker . 356) . -5) ((marker . 356) . -5) ((marker . 2633) . -5) ((marker . 2600) . -5) ((marker . 18) . -5) ("for " . 369) ((marker . 356) . -4) ((marker . 356) . -4) ((marker . 2633) . -4) ((marker . 2600) . -4) ((marker . 18) . -4) ("()" . 373) ((marker . 356) . -1) ((marker . 356) . -1) ((marker* . 357) . 1) ((marker . 2633) . -1) ((marker . 2600) . -1) ((marker . 18) . -1) ("int" . 374) ((marker . 356) . -2) ((marker . 2633) . -2) ((marker . 2600) . -3) (374 . 377) ("int" . 374) ((marker . 356) . -2) ((marker . 356) . -2) ((marker . 2633) . -2) ((marker . 2600) . -2) ((marker . 18) . -2) nil (374 . 377) ("i" . -374) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) ("n" . -375) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) ("t" . -376) ((marker . 2600) . -1) 377 (374 . 377) (373 . 375) (369 . 373) (364 . 369) 327 nil ("&" . 361) nil ("c" . 358) nil ("*" . 358) nil ("%" . 358) nil (367 . 368) (")" . -366) (366 . 367) (")" . -366) (366 . 367) (363 . 366) (362 . 363) ("\"" . -361) (361 . 362) ("\"" . -361) (360 . 362) (359 . 360) (358 . 359) ("]" . -357) (357 . 358) ("]" . -357) (354 . 358) (351 . 355) ("%" . -351) ((marker . 2600) . -1) 352 (351 . 352) (350 . 352) ("\"" . -350) (350 . 351) (349 . 351) (344 . 349) ("wca" . -344) ((marker . 2600) . -3) 347 (344 . 347) ("sacnf" . -344) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -5) 349 (343 . 349) ("
" . -343) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) 344 ("    " . -344) ((marker . 356) . -4) ((marker . 2633) . -4) ((marker . 2600) . -4) 348 ("s" . -348) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) 349 (348 . 349) (343 . 348) (342 . 343) ("]" . -341) (341 . 342) ("]" . -341) (338 . 342) (331 . 339) (327 . 331) ("    " . 326) ((marker . 2600) . -4) (330 . 331) (325 . 330) 308 nil ("    puts(ar);
" . 326) ((marker . 381) . -13) ((marker . 18) . -12) ((marker . 2600) . -12) 338 nil (84 . 85) ("7" . 84) nil (" ar[]" . 87) ((marker . 356) . -2) ((marker . 2633) . -2) ("26]" . 91) (93 . 94) ("]" . 93) (93 . 94) (" = 0" . 94) (";" . 98) (t 26173 4713 965601 286000) nil (98 . 99) (94 . 98) ("]" . -93) (93 . 94) ("]" . -93) (91 . 94) (87 . 92) nil (84 . 85) ("6" . 84) (t 26173 4699 544937 160000) nil (" " . 159) nil ("," . 174) nil (168 . 169) (167 . 168) nil (nil rear-nonsticky nil 166 . 167) (nil fontified nil 159 . 167) (159 . 167) nil 159 nil (" \"aeiou\"" . 165) ((marker . 381) . -7) (t 26173 4669 6864 867000) nil (341 . 342) 338 nil (338 . 339) (")" . -337) (337 . 338) (")" . -337) (337 . 338) (335 . 337) (334 . 336) (330 . 334) (325 . 330) 324 nil (282 . 290) ("+" . -282) ((marker . 2600) . -1) 283 (282 . 283) ("'" . -281) (281 . 282) ("'" . -281) (280 . 282) (279 . 281) ("'" . -279) (279 . 280) ("1" . 279) nil ("+" . 277) nil (281 . 282) (277 . 281) ("=" . -277) ((marker . 2600) . -1) 278 (276 . 278) ("+" . -276) ((marker . 2600) . -1) ("+" . -277) ((marker . 2600) . -1) 278 (276 . 278) ("]" . -275) (275 . 276) ("]" . -275) (274 . 276) (271 . 275) (259 . 271) (258 . 268) (257 . 259) (256 . 257) ("else" . 256) ((marker . 356) . -4) ((marker . 2633) . -4) ((marker . 2600) . -4) (252 . 256) 256 (251 . 256) nil (236 . 239) ("+" . 236) nil (232 . 235) ("+" . 232) ((marker) . -1) ((marker) . -1) ((marker) . -1) nil (201 . 204) ("+" . 201) ((marker) . -1) ((marker) . -1) ((marker) . -1) nil (" " . 202) nil (" " . 201) nil (205 . 206) (203 . 205) (201 . 203) ("'" . -200) (200 . 201) ("'" . -200) (199 . 201) ("'" . -199) ((marker . 2600) . -1) ("'" . 200) (199 . 201) ("'" . -199) (199 . 200) (198 . 200) ("'" . -198) (195 . 199) ("]" . -194) (194 . 195) ("]" . -194) (194 . 195) (193 . 194) (190 . 194) (177 . 190) 169 nil (207 . 208) (203 . 207) ("'" . -202) (202 . 203) ("'" . -202) (201 . 203) (200 . 202) ("'" . -200) (198 . 201) (" " . -198) ((marker . 2600) . -1) 199 (198 . 199) ("+" . -198) ((marker . 2600) . -1) 199 (198 . 199) (197 . 198) ("]" . -196) (196 . 197) ("]" . -196) (193 . 197) (190 . 194) (177 . 190) 176 nil ("            " . 177) ("
" . -177) 153 nil (101 . 102) ("b" . 101) nil (178 . 190) (177 . 187) (176 . 178) (175 . 176) (")" . -174) (174 . 175) (")" . -174) (174 . 175) nil (167 . 172) (166 . 168) ("\"" . -166) (165 . 167) (164 . 165) (162 . 164) ("'" . -161) (161 . 162) ("'" . -161) (160 . 162) (159 . 161) ("'" . -159) (159 . 160) ("i" . -159) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) 160 (159 . 160) ("a" . -159) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) ("r" . -160) ((marker . 2600) . -1) 161 ("[" . -161) ((marker . 2600) . -1) ("]" . 162) (159 . 163) nil (47 . 56) ("stri" . -47) ((marker . 35) . -4) ((marker . 356) . -4) ((marker . 2633) . -4) ((marker . 2600) . -4) 51 (46 . 51) ("," . -46) ((marker . 35) . -1) ((marker . 2600) . -1) 47 (46 . 47) ("\"<#" . -46) ((marker . 2600) . -3) 49 ("header" . -49) ((marker . 2600) . -6) 55 ("#>\"" . -55) ((marker . 35) . -3) ((marker . 2600) . -3) 58 (38 . 58) ("inc" . -38) ((marker . 35) . -3) ((marker . 356) . -3) ((marker . 2633) . -3) ((marker . 2600) . -3) 41 (38 . 41) (37 . 38) ("
" . -37) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) 38 ("void" . -38) ((marker . 356) . -3) ((marker . 2633) . -3) ((marker . 2600) . -4) 42 (38 . 42) (37 . 38) (nil face (rainbow-delimiters-depth-1-face font-lock-string-face) 36 . 37) (nil fontified t 36 . 37) (nil c-in-sws t 36 . 37) (36 . 37) 35 nil (138 . 140) (132 . 138) ("'" . -132) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) ("a" . -133) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) ("'" . -134) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) ("+" . -135) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) ("i" . -136) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) (" " . -137) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) ("=" . -138) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) ("=" . -139) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) (" " . -140) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) ("'" . -141) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) ("a" . -142) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) ("'" . -143) ((marker . 2600) . -1) 144 ("'" . -143) (143 . 144) ("'" . -143) (142 . 144) (141 . 143) ("'" . -141) (139 . 142) (" " . -139) ((marker . 2600) . -1) ("=" . -140) ((marker . 2600) . -1) 141 (135 . 141) ("'" . -134) (134 . 135) ("'" . -134) (133 . 135) (132 . 134) ("'" . -132) (132 . 133) (131 . 133) (128 . 131) (119 . 128) 100 nil (83 . 84) nil ("'" . 83) ((marker* . 357) . 1) nil (";" . 83) nil (83 . 84) (82 . 84) ("'" . -82) (81 . 83) ("a" . -81) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) ("'" . -82) ((marker . 2600) . -1) ("+" . -83) ((marker . 2600) . -1) ("1" . -84) ((marker . 2600) . -1) 85 ("'" . -85) ((marker . 2600) . -1) ("'" . 86) (85 . 87) ("'" . -85) (83 . 86) ("+" . -83) ((marker . 2600) . -1) 84 (83 . 84) ("'" . -82) (82 . 83) ("'" . -82) (81 . 83) (80 . 82) ("'" . -80) (77 . 81) ("]" . -76) (76 . 77) ("]" . -76) (75 . 77) (72 . 76) (67 . 72) 66 nil ("        " . 102) ((marker . 356) . -8) ((marker . 2633) . -8) ("
" . -102) 85 nil (85 . 86) ("0" . 85) nil ("i" . -111) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) ("f" . -112) ((marker . 2600) . -1) (" " . -113) ((marker . 2600) . -1) 114 (111 . 114) (102 . 111) 84 nil (125 . 126) ("'" . -124) (124 . 125) ("'" . -124) (123 . 125) (122 . 124) ("'" . -122) (120 . 123) ("+" . -120) ((marker . 2600) . -1) ("=" . -121) ((marker . 2600) . -1) (" " . -122) ((marker . 2600) . -1) 123 (122 . 123) (119 . 122) ("]" . -118) (118 . 119) ("]" . -118) (117 . 119) ("6" . -117) ((marker . 2600) . -1) 118 (116 . 118) (113 . 117) (108 . 113) 107 nil ("        " . 102) ("
" . -102) 75 nil (103 . 111) (102 . 108) (101 . 103) (100 . 101) (")" . -99) (99 . 100) (")" . -99) (99 . 100) (95 . 99) (94 . 95) (92 . 94) (87 . 92) (86 . 87) (77 . 86) (76 . 78) (72 . 76) ("f" . -72) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) ("o" . -73) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) ("r" . -74) ((marker . 2600) . -1) 75 (72 . 75) (67 . 72) (66 . 67) ("]" . -65) (65 . 66) ("]" . -65) (63 . 66) (55 . 64) ("হসট " . -55) ((marker . 2600) . -4) 59 (55 . 59) (51 . 55) (50 . 52) (49 . 51) (48 . 49) (")" . -47) (47 . 48) (")" . -47) (47 . 48) (46 . 48) (38 . 46) (36 . 38) (28 . 36) ("t" . -28) ((marker . 35) . -1) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) ("s" . -29) ((marker . 35) . -1) ((marker . 356) . -1) ((marker . 2633) . -1) ((marker . 2600) . -1) ("d" . -30) ((marker . 35) . -1) ((marker . 2600) . -1) 31 (19 . 31) (18 . 19) nil ("#include <stdio.h>
#include <string.h>

void strrev(char *str, int len) {
    if (len <= 1) return;
    char c = str[0];
    str[0] = str[len-1];
    str[len-1] = c;
    strrev(str+1, len-2);
}

void main() {
    char str1[100] = \"This journey is\";
    char str2[100] = \"beautiful\";
    int j;
    strncpy(str1, str2, 8);
    for (j = 3; str1[j] != '\\0'; j++) {
        str1[j] = str2[strlen(str1) - j];
    }

    strncat(str2, str1, 3);
    printf(\"String 1: %s\\n\", str1);
    str2[j - 2] = '\\0';
    printf(\"String 2: %s\\n\", str2);
    for (j = 5; j > 2; j--) {
        strrev(str1, strlen(str1));
    }
    printf(\"Final: %s\\n\", str1);
}
" . 18) ((marker . 35) . -18) ((marker . 356) . -362) ((marker . 18) . -209) ((marker* . 382) . 433) ((marker . 18) . -209) ((marker . 18) . -209) ((marker . 381) . -641) ((marker . 356) . -362) ((marker* . 357) . 232) ((marker . 18) . -640) ((marker . 18) . -209) ((marker . 18) . -209) ((marker . 18) . -209) ((marker . 18) . -209) ((marker . 18) . -209) ((marker . 18) . -209) ((marker . 18) . -209) ((marker . 18) . -209) ((marker . 18) . -209) ((marker . 18) . -209) ((marker . 18) . -209) ((marker . 18) . -209) ((marker . 18) . -209) ((marker . 18) . -209) ((marker . 18) . -209) ((marker . 18) . -209) ((marker . 18) . -209) ((marker . 18) . -209) ((marker . 18) . -209) ((marker . 18) . -209) ((marker . 18) . -209) ((marker . 18) . -209) ((marker . 18) . -362) ((marker . 18) . -362) ((marker . 18) . -292) ((marker . 18) . -209) ((marker . 18) . -209) ((marker . 18) . -209) ((marker . 18) . -209) ((marker . 18) . -209) ((marker . 18) . -209) ((marker . 18) . -209) ((marker . 18) . -209) ((marker . 18) . -403) ((marker . 18) . -403) ((marker . 18) . -321) ((marker . 18) . -321) ((marker . 18) . -409) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -409) ((marker . 18) . -498) ((marker . 18) . -498) ((marker . 18) . -461) ((marker . 18) . -439) ((marker . 18) . -439) ((marker . 18) . -439) ((marker . 18) . -439) ((marker . 18) . -461) ((marker . 18) . -461) ((marker . 18) . -410) ((marker . 18) . -410) ((marker . 18) . -410) ((marker . 18) . -410) ((marker . 18) . -410) ((marker . 18) . -410) ((marker . 18) . -438) ((marker . 18) . -438) ((marker . 18) . -411) ((marker . 18) . -411) ((marker . 18) . -362) ((marker . 2633) . -362) (t 26173 2424 232925 887000) nil ("
    " . 456) ((marker . 356) . -5) ((marker . 2600) . -5) ((marker . 18) . -5) ("puts" . 461) ((marker . 356) . -4) ((marker . 2600) . -4) ((marker . 18) . -4) ("()" . 465) ((marker . 356) . -1) ((marker . 2600) . -1) ((marker . 18) . -1) ("str2" . 466) ((marker . 356) . -4) ((marker . 2600) . -4) ((marker . 18) . -4) (")" . 470) (470 . 471) (")" . 470) (470 . 471)) (emacs-undo-equiv-table (-4 . -6) (-14 . -16) (-16 . -18) (-25 . -27) (-30 . -34) (-31 . -33) (-35 . -39) (-36 . -38) (-39 . -47) (-40 . -42) (-122 . -124) (-131 . -133) (-138 . -140) (-140 . -142) (-142 . -144) (-144 . -146) (-150 . -152) (-153 . -155) (42 . 44) (-51 . -53) (-43 . -45) (-194 . -196) (49 . 51) (-188 . -190) (-172 . -182) (-63 . -65) (-65 . -67) (-207 . -209) (-185 . -187) (-182 . -188) (101 . 105) (100 . 106) (99 . 107) (-133 . -135) (-135 . -137) (-174 . -180) (-108 . -110) (-183 . -185) (47 . 49) (94 . 96) (86 . 88) (-42 . -46) (82 . 84) (-67 . -69) (98 . t) (-128 . -130) (-50 . -54) (72 . 74) (23 . 25) (26 . 28) (-215 . -219) (107 . 109) (-176 . -178) (-216 . -218) (-74 . -76) (-173 . -181) (-72 . -74) (34 . 36) (102 . 104) (-175 . -179)))