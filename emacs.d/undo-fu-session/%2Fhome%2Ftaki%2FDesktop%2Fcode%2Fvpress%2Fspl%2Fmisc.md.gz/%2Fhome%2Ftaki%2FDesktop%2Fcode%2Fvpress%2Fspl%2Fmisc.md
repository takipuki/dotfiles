((buffer-size . 2646) (buffer-checksum . "328fdab9564eb93cd1a51d226ca1671bd8de9e53"))
((emacs-buffer-undo-list nil (2646 . 2647) nil ("
" . -2646) ((marker . 2647) . -1) ((marker . 2647) . -1) ((marker . 2647) . -1) ((marker . 2647) . -1) ((marker . 2647) . -1) ((marker . 2647) . -1) ((marker . 2647) . -1) ((marker . 2647) . -1) ((marker) . -1) 2643 nil (2642 . 2643) (" " . 2642) nil (2642 . 2643) ("
" . -2642) ((marker) . -1) 2641 nil ("{5-10}" . 63) ((marker . 2645) . -5) (t 26160 38750 751957 356000)) (emacs-pending-undo-list (2642 . 2643) (" " . 2642) nil (2642 . 2643) ("
" . -2642) ((marker) . -1) 2641 nil ("{5-10}" . 63) ((marker . 2645) . -5) (t 26160 38750 751957 356000)) (emacs-undo-equiv-table (-1 . -3) (1 . -1)))