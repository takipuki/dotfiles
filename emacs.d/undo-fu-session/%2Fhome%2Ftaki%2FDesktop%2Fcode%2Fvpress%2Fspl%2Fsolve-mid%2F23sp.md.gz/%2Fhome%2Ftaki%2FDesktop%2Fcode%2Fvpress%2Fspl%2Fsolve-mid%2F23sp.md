((buffer-size . 4188) (buffer-checksum . "21fb48742a0d695ef6a44aaee2505ad458285cc3"))
((emacs-buffer-undo-list nil (4044 . 4073) nil ("   |---|----|----|----|----|
" . 4015) ((marker . 4015) . -28) ((marker . 4015) . -3) ((marker . 4015) . -3) ((marker . 4015) . -3) ((marker . 4015) . -3) ((marker . 4015) . -3) ((marker . 4015) . -3) ((marker . 4015) . -3) ((marker . 4015) . -3) ((marker . 4015) . -3) ((marker . 4015) . -3) ((marker . 4015) . -3) ((marker . 4015) . -3) ((marker . 4015) . -3) ((marker . 4015) . -3) ((marker . 4015) . -3) ((marker . 4015) . -3) ((marker . 4015) . -3) ((marker . 4015) . -3) ((marker . 4015) . -3) ((marker . 4015) . -3) ((marker . 4015) . -3) ((marker . 4015) . -3) ((marker . 4048) . -3) ((marker . 4015) . -3) ((marker . 4015) . -3) ((marker . 4015) . -3) ((marker . 4015) . -3) ((marker . 4015) . -3) ((marker) . -3) (t 26161 43695 648659 526000) nil (4015 . 4044) 4019 nil ("   |---|----|----|----|----|
" . 4044) ((marker . 4015) . -28) ((marker) . -4) ((marker . 4048) . -4) ((marker . 4048) . -4) ((marker . 4048) . -4) ((marker . 4048) . -4) ((marker . 4048) . -4) ((marker . 4048) . -4) ((marker . 4048) . -4) ((marker . 4048) . -4) ((marker . 4048) . -4) ((marker . 4048) . -4) ((marker) . -29) 4048 (t 26161 43684 694924 423000) nil ("   | 5 |  8 | 13 | 21 | 34 |
" . 4160) ((marker* . 4078) . 29) (4131 . 4160) ("   | 3 |  5 |  8 | 13 | 21 |
" . 4131) ((marker* . 4078) . 29) (4102 . 4131) ("   | 2 |  3 |  5 |  8 | 13 |
" . 4102) ((marker* . 4078) . 29) (4073 . 4102) ("   |-
" . 4073) ((marker* . 4078) . 1) ((marker . 4048) . -5) ((marker) . -5) (4044 . 4073) ("   | 1 |  2 |  3 |  5 |  8 |
" . 4044) ((marker . 4044) . -28) ((marker . 4044) . -28) ((marker . 4044) . -28) ((marker . 4044) . -28) ((marker . 4044) . -28) ((marker . 4044) . -28) ((marker . 4044) . -28) ((marker . 4044) . -28) ((marker . 4044) . -28) ((marker) . -29) ((marker) . -29) (4015 . 4044) 4049 (4047 . 4049) (4043 . 4047) (t 26161 43675 241243 688000) 4017 nil ("
   " . 4043) ((marker* . 4078) . 3) ((marker . 4044) . -4) ((marker . 4044) . -4) ((marker . 4044) . -4) ((marker . 4044) . -4) ((marker . 4044) . -4) ((marker . 4044) . -4) ((marker . 4044) . -4) ((marker . 4044) . -4) ((marker . 4044) . -4) ("|" . 4047) ("   | 1 | 2  | 3  | 5  | 8  |
" . 4015) ((marker) . -29) ((marker . 4015) . -29) ((marker . 4015) . -29) ((marker . 4015) . -29) ((marker . 4015) . -29) ((marker . 4048) . -29) ((marker . 4015) . -29) ((marker . 4015) . -29) ((marker . 4015) . -29) ((marker . 4015) . -29) ((marker . 4015) . -29) ((marker) . -29) (4044 . 4073) ("   |   |    |    |    |    |
" . 4044) ((marker* . 4078) . 20) ((marker . 4015) . -8) ((marker . 4015) . -8) ((marker . 4015) . -8) ((marker . 4015) . -8) ((marker . 4048) . -8) ((marker . 4015) . -8) ((marker . 4015) . -8) ((marker . 4015) . -8) ((marker . 4015) . -8) ((marker . 4015) . -8) ((marker) . -8) (4073 . 4078) ("   | 2 | 3  | 5  | 8  | 13 |
" . 4073) (4102 . 4131) ("   | 3 | 5  | 8  | 13 | 21 |
" . 4102) (4131 . 4160) ("   | 5 | 8  | 13 | 21 | 34 |
" . 4131) (4160 . 4189) nil ("   | 5 |  8 | 13 | 21 | 34 |
" . 4160) (4131 . 4160) ("   | 3 |  5 |  8 | 13 | 21 |
" . 4131) (4102 . 4131) ("   | 2 |  3 |  5 |  8 | 13 |
" . 4102) (4073 . 4102) ("   |
" . 4073) ((marker . 4044) . -3) ((marker . 4044) . -3) ((marker . 4044) . -3) ((marker . 4044) . -3) ((marker . 4048) . -4) ((marker . 4044) . -3) ((marker . 4044) . -3) ((marker . 4044) . -3) ((marker . 4044) . -3) ((marker . 4044) . -3) ((marker) . -4) (4044 . 4073) ("   | 1 |  2 |  3 |  5 |  8 |
" . 4044) ((marker) . -29) ((marker) . -29) (4015 . 4044) 4048 (4047 . 4048) (4043 . 4047) (t 26161 43675 241243 688000) 4017 nil (3992 . 3995) ("   " . 3992) ((marker* . 3995) . 3) ("
" . -3992) ((marker . 3992) . -1) ((marker . 4019) . -1) ((marker . 4015) . -1) ((marker . 4015) . -1) ((marker . 3992) . -1) ((marker . 3992) . -1) ((marker . 3992) . -1) ((marker . 3992) . -1) nil ("   ```c:line-numbers
   ```
" . 3993) ((marker . 3992) . -21) ((marker . 4019) . -21) ((marker . 4015) . -27) ((marker . 3992) . -21) ((marker . 4048) . -21) 4014 nil ("   #include <stdio.h>

   int main() {
       int arr[10] = {0};
       int k = 15;
       for (int i = 1; i < 6; i += 2) {
           arr[i] = ++k - 2;
           k++;
       }

       printf(\"arr = {\")
           for (int i = 0; i < 9; i++)
               printf(\"%d, \", arr[i]);
       printf(\"%d}\\n\", arr[9]);
       printf(\"k   = %d\\n\", k);

       int c = 0;
       for (int i = 6; i < 10; i++) {
           for (int j = 10; j >= i; j--) {
               arr[j] = ++c;
           }
       }

       printf(\"arr = {\")
           for (int i = 0; i < 9; i++)
               printf(\"%d, \", arr[i]);
       printf(\"%d}\\n\", arr[9]);
       printf(\"c   = %d\\n\", c);

       for (int i = 0; i < 10; i++) {
           if (i % 2 == 0) {
               arr[i] = ++k;
           }
       }

       printf(\"arr = {\")
           for (int i = 0; i < 9; i++)
               printf(\"%d, \", arr[i]);
       printf(\"%d}\\n\", arr[9]);
       printf(\"k   = %d\\n\", k);
   }
" . 4014) (4971 . 4971) nil (4978 . 4981) ("
" . -4978) nil (5143 . 5144) nil ("
" . -5143) ((marker* . 3995) . 1) 5142 nil ("
" . -5143) ((marker . 4019) . -1) ((marker . 4015) . -1) ((marker . 4015) . -1) ((marker . 3992) . -1) ((marker . 3992) . -1) ((marker . 3992) . -1) 5115 nil ("
   ```c:line-numbers
   #include <stdio.h>

   int main() {
       int arr[100][100], i, j, t1 = 0, t2 = 1, t3, x, y, z;

       for (i = 0; i < 5; i++) {
           x = t1, y = t2, z = t1 + t2;
           for (j = 0; j < 5; j++) {
               t3 = t1 + t2;
               arr[j][i] = t3;
               t1 = t2;
               t2 = t3;
           }
           t1 = y;
           t2 = z;
       }

       for (int i = 0; i < 5; i++) {
           for (int j = 0; j < 5; j++)
               printf(\"%d \", arr[i][j]);
           putchar('\\n');
       }
   }
   ```
" . 5144) ((marker . 4019) . -559) ((marker . 4015) . -565) ((marker . 3992) . -559) (t 26161 43578 350978 862000) nil ("b)" . -1720) (1722 . 1724) nil (1092 . 1093) 1087 nil ("a)" . -1093) (1095 . 1097) nil (")" . 4980) (4981 . 4982) 4980 ("b" . 4979) (4980 . 4981) 4979 nil (3110 . 3111) ("~" . 3110) nil (3093 . 3094) ("~" . 3093) ((marker) . -1) nil (")" . 3074) (3075 . 3076) 3074 ("a" . 3073) (3074 . 3075) 3073 nil (3071 . 3072) 3066 nil (3061 . 3064) ("    " . 3061) ("
" . -3061) nil ("
" . -2271) ("    " . 2271) ("
" . -2271) nil (2283 . 2284) 2279 nil (")" . 2285) (2286 . 2287) 2285 ("a" . 2284) (2285 . 2286) 2284 nil (1050 . 1051) (1049 . 1050) (1048 . 1049) (1012 . 1013) (1011 . 1012) (1010 . 1011) (974 . 975) (973 . 974) (972 . 973) (936 . 937) (935 . 936) (934 . 935) (898 . 899) (897 . 898) (896 . 897) (860 . 861) (859 . 860) (858 . 859) (822 . 823) (821 . 822) (820 . 821) (782 . 785) nil ("    " . 782) ((marker . 4048) . -1) ("    " . 821) ("    " . 860) ("    " . 899) ("    " . 938) ("    " . 977) ("    " . 1016) ("    " . 1055) nil (1055 . 1059) (1016 . 1020) (977 . 981) (938 . 942) (899 . 903) (860 . 864) (821 . 825) (782 . 786) 1028 nil (")" . 767) (768 . 769) 767 ("b" . 766) (767 . 768) 766 nil ("
" . -781) ((marker* . 3995) . 1) ("   " . 781) ((marker . 4019) . -3) ((marker . 4015) . -3) ((marker . 4015) . -3) ((marker . 3992) . -3) ((marker . 3992) . -3) ((marker . 3992) . -3) ("
" . -784) ((marker . 4019) . -1) ((marker . 4015) . -1) ((marker . 4015) . -1) ((marker . 3992) . -1) ((marker . 3992) . -1) ((marker . 3992) . -1) 781 nil ("   ```c:line-numbers
   #include <stdio.h>
   int main() {
       int j = 8, result = 5, i = 0, x = 2, y = 2;
       printf(\"i j result x y j>3\\n\");
       for (; j > 3; j--) {
           printf(\"%d %d %d %d %d %d\\n\", i, j, result, x, y, j > 3);
           i =  (j * result) / x;
           result += y;
           x += (y-2);
           y++;
       } 
       printf(\"%d %d %d %d %d %d\\n\", i, j, result, x, y, j > 3);
   }
   ```
" . 785) ((marker . 4019) . -423) ((marker . 4015) . -429) ((marker . 3992) . -423) nil (311 . 312) 311 nil (317 . 318) 313 nil (")" . 319) (320 . 321) 319 ("a" . 318) (319 . 320) 318 nil (35 . 40) (t 26161 43237 987599 306000) nil ("/spl/solve-mid/" . 34) ((marker . 3997) . -14) ((marker . 4019) . -14) ((marker . 34) . -14) ((marker . 34) . -14) ((marker . 34) . -14) ((marker . 34) . -14) ((marker . 34) . -14) ((marker . 3992) . -14) (t 26161 43171 498132 741000) nil (34 . 49) (t 26161 43147 247091 736000) nil ("      [ 'link',
        { href: '', rel: 'stylesheet' }
      ]
" . 62) ((marker . 4019) . -63) ((marker . 4015) . -63) ((marker . 3992) . -9) ((marker . 3992) . -63) ((marker . 67) . -6) ((marker . 67) . -6) ((marker . 67) . -6) ((marker . 4048) . -63) 125 nil ("  - - meta
    - name: keywords
      content: super duper SEO
" . 62) ((marker . 4019) . -41) ((marker . 4015) . -62) ((marker . 3992) . -9) ((marker . 3992) . -41) ((marker . 4048) . -41) 103 nil (51 . 61) ("hello" . 51) ((marker . 4015) . -4) ((marker . 4048) . -3) 54 nil (46 . 49) ("content" . 46) ((marker . 4015) . -6) ((marker . 4048) . -3) 49 nil (46 . 53) ("href" . 46) ((marker . 3997) . -3) ((marker . 3992) . -3) nil (46 . 50) ("content" . 46) ((marker . 4015) . -6) ((marker . 4048) . -4) 50 nil ("/" . 34) nil (34 . 35) nil ("./" . 34) nil (34 . 36) nil (34 . 39) nil ("https://fonts.googleapis.com/css2?family=JetBrains+Mono:ital,wght@0,100..800;1,100..800&display=swap" . 34) ((marker . 4015) . -99) ((marker . 4048) . -99) (nil rear-nonsticky nil 133 . 134) nil (nil rear-nonsticky nil 133 . 134) (nil fontified nil 34 . 134) (34 . 134) 33 nil ("https://fonts.googleapis.com/css2?family=JetBrains+Mono:ital,wght@0,100..800;1,100..800&display=swap" . 152) ((marker . 4015) . -99) ((marker . 4048) . -1) 153 nil ("description" . 34) ((marker . 4015) . -10) nil (28 . 32) ("name" . 28) ((marker . 4015) . -3) ((marker . 4048) . -2) 30 nil (17 . 21) ("meta" . 17) ((marker . 4015) . -3) nil (nil rear-nonsticky nil 128 . 129) (nil fontified nil 5 . 129) (5 . 129) nil (4 . 5) 3 nil (nil rear-nonsticky nil 168 . 169) ("
" . -172) (168 . 173) 163 nil (1 . 4) nil (1 . 2) 7 nil ("<style>
  ol {
    list-style-type: lower-roman;
  }
</style>
" . 1) ((marker . 3997) . -60) ((marker . 4019) . -59) ((marker* . 4078) . 14) ((marker . 4015) . -61) ((marker . 3992) . -59) ((marker . 3992) . -6) ((marker . 1) . -15) ((marker . 1) . -15) ((marker . 1) . -60) ((marker . 1) . -60) ((marker . 3992) . -60) ((marker . 4048) . -6) 7 nil (nil rear-nonsticky nil 68 . 69) ("
" . -226) (62 . 227) 61 (t 26161 42926 280339 898000) nil (48 . 49) nil (37 . 48) ("u" . -37) ((marker . 4048) . -1) 38 (26 . 38) ("s" . -26) ((marker . 4048) . -1) 27 (20 . 27) (16 . 20) ("  " . 16) ((marker . 4048) . -2) 18 (16 . 18) (16 . 17) 17 nil (15 . 18) (13 . 16) ("d" . -13) ((marker . 4048) . -1) 14 (9 . 14) (8 . 9) ("
" . -8) ((marker . 4048) . -1) 9 ("    " . -9) ((marker . 4048) . -4) 13 ("o" . -13) ((marker . 4048) . -1) ("d" . -14) ((marker . 4048) . -1) ("l" . -15) ((marker . 4048) . -1) 16 (13 . 16) (9 . 13) (9 . 10) 16 nil (9 . 17) (8 . 9) (4 . 8) ("d" . -4) ((marker . 3997) . -1) ((marker . 3992) . -1) ((marker . 4048) . -1) ("y" . -5) ((marker . 4048) . -1) 6 (1 . 6) ("," . -1) ((marker . 4048) . -1) 2 (1 . 2) (1 . 2) (t 26161 42794 60307 898000) nil ("
   " . 152) ((marker . 3997) . -4) ((marker . 3992) . -4) ((marker . 4048) . -4) ("
   " . 156) ((marker . 3997) . -4) ((marker . 3992) . -4) ((marker . 4048) . -4) ("1. hello" . 160) ((marker . 3997) . -8) ((marker . 3992) . -8) ((marker . 4048) . -8) ("
   " . 168) ((marker . 3997) . -4) ((marker . 3992) . -4) ((marker . 4048) . -4) ("2. friedn" . 172) ((marker . 3997) . -5) ((marker . 3992) . -5) ((marker . 4048) . -8) (t 26161 42783 653087 433000) nil (172 . 181) (168 . 172) (160 . 168) (156 . 160) (152 . 156) (t 26161 42758 251717 658000) 138 nil ("    " . 46) ((marker . 4048) . -4) nil (46 . 50) (t 26161 42758 251717 658000) nil (46 . 47) ("1" . 46) nil (157 . 158) ("1" . 157) nil (")" . 158) (159 . 160) 158 ("c" . 157) (158 . 159) 157 nil (")" . 47) (48 . 49) 47 ("b" . 46) (47 . 48) 46 nil ("1" . 48) ((marker . 118) . -1) ((marker . 118) . -1) ((marker . 118) . -1) ((marker . 118) . -1) ((marker . 4048) . -1) ((marker . 118) . -1) ((marker . 118) . -1) ((marker . 118) . -1) ((marker . 118) . -1) ((marker . 118) . -1) ((marker) . -1) (47 . 48) ("." . 49) (48 . 49) nil (" " . 48) (49 . 50) 48 (")" . 47) (48 . 49) 47 nil (")" . 23) (24 . 25) 23 ("a" . 22) (t 26161 42744 470963 430000) (23 . 24) 22 (t 26161 42744 470963 430000) nil (22 . 23) ("1" . 22) nil (22 . 23) ("a" . 22) ((marker) . -1) (t 26161 42744 470963 430000) nil ("   
   ```c:line-numbers
   #include <stdio.h>
   int main() {
       int b = 2;

       if (b >= 10) {
           printf(\"SPL\\n\");
           b--;
       }

       if (b < 10) {
           printf(\"Spring\\n\");
           b--;
       }
       else if ((b >= 3) || (b < 10))
           printf(\"2023\\n\");
       else if (b >= 3 && b < 10)
           printf(\"Happy Coding!\");
       else
           printf(\"Huh!\");
       return 0;
   }
   ```


   : Spring
" . 241) ((marker . 4019) . -442) ((marker . 4015) . -453) ((marker . 311) . -441) ((marker . 3992) . -442) (t 26161 42732 266955 414000) nil (153 . 156) ("   " . 153) ((marker . 4048) . -2) ("
" . -156) ((marker* . 4078) . 1) ((marker* . 3995) . 1) (153 . 156) ("   " . 153) ("
" . -156) ((marker* . 4078) . 1) ((marker* . 3995) . 1) 153 nil ("   | 3 | 12.0 | 2 | 1.0 |
" . 158) ((marker . 4015) . -25) ((marker . 4048) . -2) 160 nil (153 . 156) ("
" . -153) ((marker . 4019) . -1) ((marker . 4015) . -1) ((marker . 4015) . -1) ((marker . 3992) . -1) ((marker . 3992) . -1) ((marker . 3992) . -1) nil ("   ```c:line-numbers
   int a = (float)15/4;
   float b = a++*a--;
   int c = (a > b || a == 1 + 2) * 2;
   float d = a/c;
   printf(\"%d, %.2f, %d, %.2f\\n\", a, b, c, d);
   ```
" . 154) ((marker . 4019) . -170) ((marker* . 4078) . 177) ((marker . 4015) . -176) ((marker . 3992) . -170) nil (apply 63 154 332 undo--wrap-and-run-primitive-undo 154 332 (("<!-- " . 157) (" -->" . 179) ("<!-- " . 187) (" -->" . 212) ("<!-- " . 220) (" -->" . 243) ("<!-- " . 251) (" -->" . 290) ("<!-- " . 298) (" -->" . 317) ("<!-- " . 325) (" -->" . 373) ("<!-- " . 381) (" -->" . 389) 395)) nil (apply -63 154 395 undo--wrap-and-run-primitive-undo 154 395 ((389 . 393) (381 . 386) (373 . 377) (325 . 330) (317 . 321) (298 . 303) (290 . 294) (251 . 256) (243 . 247) (220 . 225) (212 . 216) (187 . 192) (179 . 183) (157 . 162) 331)) nil ("//" . 154) ((marker . 4048) . -1) ("/" . 177) ("/" . 178) ("/" . 203) ("/" . 204) ("/" . 227) ("/" . 228) ("/" . 267) ("/" . 268) ("/" . 287) ("/" . 288) ("/" . 336) ("/" . 337) nil (337 . 338) (336 . 337) (288 . 289) (287 . 288) (268 . 269) (267 . 268) (228 . 229) (227 . 228) (204 . 205) (203 . 204) (178 . 179) (177 . 178) (154 . 156) (t 26161 42556 919795 55000) nil ("#" . 154) ("#" . 176) ("#" . 201) ("#" . 224) ("#" . 263) ("#" . 282) ("#" . 330) nil (330 . 331) (282 . 283) (263 . 264) (224 . 225) (201 . 202) (176 . 177) (154 . 155) (t 26161 42556 919795 55000) nil ("c:line-numbers" . 426) ((marker . 4015) . -13) nil (458 . 461) ("
" . -458) ((marker . 4015) . -1) ((marker . 4015) . -1) nil ("    " . 459) ((marker . 4048) . -2) ("
" . -463) 461 (t 26161 42545 742401 752000) nil (404 . 407) ("   " . 404) ((marker . 4048) . -2) ("
" . -407) (404 . 407) ("    " . 404) ("
" . -404) nil ("c:line-numbers" . 379) ((marker . 4015) . -13) nil (410 . 411) (410 . 413) (" " . 410) nil (410 . 411) ("   " . 410) ("
" . -410) 401 nil (20 . 21) (t 26161 42474 291165 802000) 15 nil (56 . 5011) ("\\\\
   `b = 3*4 = 12.0` \\\\
   `c = (3 > 12 || 3 == 3) * 2 = (0 || 1) * 2 = 2` \\\\
   `d = 3/2 = 1.0`

   ```c:line-numbers
   int a = (float)15/4;
   float b = a++*a--;
   int c = (a > b || a == 1 + 2) * 2;
   float d = a/c;
   printf(\"%d, %.2f, %d, %.2f\\n\", a, b, c, d);
   ```


   | 3 | 12.0 | 2 | 1.0 |

c) `b = 10`:
   ```c:line-numbers
   SPL
   Spring
   ```

   \\\\

   `b = 2`:
   ```c:line-numbers
   Spring
   ```

   \\\\

   ```c:line-numbers
   #include <stdio.h>
   int main() {
       int b = 2;

       if (b >= 10) {
           printf(\"SPL\\n\");
           b--;
       }

       if (b < 10) {
           printf(\"Spring\\n\");
           b--;
       }
       else if ((b >= 3) || (b < 10))
           printf(\"2023\\n\");
       else if (b >= 3 && b < 10)
           printf(\"Happy Coding!\");
       else
           printf(\"Huh!\");
       return 0;
   }
   ```


   : Spring

## 02
a) rewrite using switch

   ```c:line-numbers
   int n, a;
   scanf(“%d %d”, &n, &a);

   switch (n > a) {
   case 1:
       switch (n-a > 5) {
       case 1:
           printf(“Difference is greater than 5\\n”);
           break;
       default:
           printf(“Difference is less than or equal to 5\\n”);
           break;
       }
       break;
   default:
       printf(“Please give a larger value of n\\n”);
       break;
   }
   ```

   \\\\

b) Trace table
   
   ```c:line-numbers
   #include <stdio.h>
   int main() {
       int j = 8, result = 5, i = 0, x = 2, y = 2;
       printf(\"i j result x y j>3\\n\");
       for (; j > 3; j--) {
           printf(\"%d %d %d %d %d %d\\n\", i, j, result, x, y, j > 3);
           i =  (j * result) / x;
           result += y;
           x += (y-2);
           y++;
       } 
       printf(\"%d %d %d %d %d %d\\n\", i, j, result, x, y, j > 3);
   }
   ```


   | i  | j | result | x  | y | j>3 |
   |----|---|--------|----|---|-----|
   | 0  | 8 | 5      | 2  | 2 | 1   |
   | 20 | 7 | 7      | 2  | 3 | 1   |
   | 24 | 6 | 10     | 3  | 4 | 1   |
   | 20 | 5 | 14     | 5  | 5 | 1   |
   | 14 | 4 | 19     | 8  | 6 | 1   |
   | 9  | 3 | 25     | 12 | 7 | 0   |

## 03
a) rewrite with do-while

   ```c:line-numbers
   #include <stdio.h>

   int main() {
       int weeks = 2, days_in_week = 7;

       int i = 1;
       do {
           printf(\"Week: %d\\n\", i);

           int j = 1;
           do {
               if (i % 2 == 0) {
                   if (j % 2 == 0)
                       printf(\"Day: %d\\n\", j);
               }
               else{
                   if (j % 2 != 0)
                       printf(\"Day: %d\\n\", j);
               }
               j++;
           } while (j <= days_in_week);
           i++;
       } while (i <= weeks);

       return 0;
   }
   ```

   \\\\

b) WAP

   ```c:line-numbers
   #include <stdio.h>

   int main() {
       int n; scanf(\"%d\", &n);

       for (int i = 1; i <= n; i++) {
           for (int j = 0; j < (n-i)*2; j++)
               putchar(' ');

           int start = 2*i;
           for (int j = 0; j < i; j++) {
               printf(\"%d \", start);
               start += 2;
           }

           start -= 4;
           for (int j = 0; j < i-1; j++) {
               printf(\"%d \", start);
               start -= 2;
           }

           putchar('\\n');
       }
   }
   ```


   \\\\

## 04
a) WAP

   ```c:line-numbers
   #include <stdio.h>

   int main() {
       float sum_cg3 = 0;
       int count_cg3 = 0;

       float max = 0;
       float min = 5;
       int count_max = 0;

       float tmp;
       for (int i = 0; i < 100; i++) {
           scanf(\"%d\", &tmp);

           if (tmp > 3) {
               sum_cg3 += tmp;
               count_cg3++;
           }
        
           if (tmp > max) {
               max = tmp;
               count_max = 1;
           } else if (tmp == max)
               count_max++;

           if (tmp < min) min = tmp;
       }

       float avg_cg3 = sum_cg3 / count_cg3;

       printf(\"Average: %.2f\\n\", avg_cg3);
       printf(\"Higest: %.2f and count: %d\\n\", max, count_max);
       printf(\"Lowest: %.2f\\n\", min);
   }
   ```

   \\\\

## 05
a) Initializing `arr~ with zeros and ~k` with 15.

   In the first loop, the values at index 1, 3 and 5 are changed.

   `arr[1] = 16 - 2 = 14` \\\\
   `k      = 16 + 1 = 17`

   `arr[3] = 18 - 2 = 16` \\\\
   `k      = 18 + 1 = 19` \\\\

   `arr[5] = 20 - 2 = 18` \\\\
   `k      = 20 + 1 = 21`

   `arr = {0, 14, 0, 16, 0, 18, 0, 0, 0, 0}` \\\\
   `k   = 21`

   After initializing `i` with 0, the second loop modifies the elements
   at indices from 6 to 10.

   `arr[9] = 1` \\\\
   `arr[8] = 2` \\\\
   `arr[7] = 3` \\\\
   `arr[6] = 4` \\\\

   `arr[9] = 5` \\\\
   `arr[8] = 6` \\\\
   `arr[7] = 7` \\\\

   `arr[9] = 8` \\\\
   `arr[8] = 9` \\\\

   `arr[9] = 10` \\\\

   `arr = {0, 14, 0, 16, 0, 18, 4, 7, 9, 10}` \\\\
   `c   = 10`

   The third loop modifies the even indices e.g. 0, 2, 4.

   `arr[0] = 22` \\\\
   `arr[2] = 23` \\\\
   `arr[4] = 24` \\\\
   `arr[6] = 25` \\\\
   `arr[8] = 26` \\\\

   `arr = {22, 14, 23, 16, 24, 18, 25, 7, 26, 10}` \\\\" . 56) ((marker . 4019) . -283) ((marker* . 4078) . 3144) ((marker . 4015) . -1785) ((marker . 4015) . -2089) ((marker . 127) . -407) ((marker . 127) . -407) ((marker . 127) . -407) ((marker . 127) . -407) ((marker . 127) . -1789) ((marker . 127) . -1789) ((marker . 127) . -2722) ((marker . 127) . -2722) ((marker . 127) . -283) nil (1841 . 1844) (1876 . 1879) (1911 . 1914) (1946 . 1949) (1981 . 1984) (2016 . 2019) (2051 . 2054) (2086 . 2089) (t 26161 42436 993396 149000) nil ("   " . -2086) ("   " . -2051) ("   " . -2016) ("   " . -1981) ("   " . -1946) ("   " . -1911) ("   " . -1876) ("   " . -1841) 1845 (t 26161 42422 442964 527000) nil (1841 . 1844) nil ("   " . -1841) 1845 (t 26161 42422 442964 527000) nil ("   |  9 | 3 |     25 | 12 | 7 |   0 |
" . 2145) ((marker* . 4078) . 38) (2107 . 2145) ("   | 14 | 4 |     19 |  8 | 6 |   1 |
" . 2107) ((marker* . 4078) . 38) (2069 . 2107) ("   | 20 | 5 |     14 |  5 | 5 |   1 |
" . 2069) ((marker* . 4078) . 38) (2031 . 2069) ("   | 24 | 6 |     10 |  3 | 4 |   1 |
" . 2031) ((marker* . 4078) . 38) (1993 . 2031) ("   | 20 | 7 |      7 |  2 | 3 |   1 |
" . 1993) ((marker* . 4078) . 38) (1955 . 1993) ("   |  0 | 8 |      5 |  2 | 2 |   1 |
" . 1955) ((marker* . 4078) . 38) (1917 . 1955) ("   |-
" . 1917) ((marker* . 4078) . 1) ((marker . 4048) . -5) (1879 . 1917) ("   |  i | j | result |  x | y | j>3 |
" . 1879) (1841 . 1879) 1884 (1882 . 1884) (1878 . 1882) (t 26161 42388 395284 548000) 1844 nil ("
   " . 1878) ((marker . 4048) . -4) ("|    " . 1882) ((marker . 4048) . -4) nil (1882 . 1887) (1878 . 1882) (t 26161 42388 395284 548000) 1844 nil (337 . 338) nil (" " . 337) (t 26161 42388 395284 548000) nil (6 . 13) ("s" . -6) ((marker . 3997) . -1) ((marker . 3992) . -1) ((marker . 4048) . -1) ("p" . -7) ((marker . 4048) . -1) ("r" . -8) ((marker . 4048) . -1) ("i" . -9) ((marker . 4048) . -1) ("n" . -10) ((marker . 4048) . -1) ("g" . -11) ((marker . 4048) . -1) 12 (11 . 12) ("t" . -11) ((marker . 4048) . -1) 12 (4 . 12) (2 . 4) (2 . 3) (t 26161 42332 476942 169000) nil (36 . 6036) ("~a = 3~ \\\\
   ~b = 3*4 = 12.0~ \\\\
   ~c = (3 > 12 || 3 == 3) * 2 = (0 || 1) * 2 = 2~ \\\\
   ~d = 3/2 = 1.0~

   ```c:line-numbers
   int a = (float)15/4;
   float b = a++*a--;
   int c = (a > b || a == 1 + 2) * 2;
   float d = a/c;
   printf(\"%d, %.2f, %d, %.2f\\n\", a, b, c, d);
   ```


   | 3 | 12.0 | 2 | 1.0 |

c) ~b = 10~:
   ```c:line-numbers
   SPL
   Spring
   ```

   \\\\

   ~b = 2~:
   ```c:line-numbers
   Spring
   ```

   \\\\

   ```c:line-numbers
   #include <stdio.h>
   int main() {
       int b = 2;

       if (b >= 10) {
           printf(\"SPL\\n\");
           b--;
       }

       if (b < 10) {
           printf(\"Spring\\n\");
           b--;
       }
       else if ((b >= 3) || (b < 10))
           printf(\"2023\\n\");
       else if (b >= 3 && b < 10)
           printf(\"Happy Coding!\");
       else
           printf(\"Huh!\");
       return 0;
   }
   ```


   : Spring

## 02
a) rewrite using switch

   ```c:line-numbers
   int n, a;
   scanf(“%d %d”, &n, &a);

   switch (n > a) {
   case 1:
       switch (n-a > 5) {
       case 1:
           printf(“Difference is greater than 5\\n”);
           break;
       default:
           printf(“Difference is less than or equal to 5\\n”);
           break;
       }
       break;
   default:
       printf(“Please give a larger value of n\\n”);
       break;
   }
   ```

   \\\\

b) Trace table
   
   ```c:line-numbers
   #include <stdio.h>
   int main() {
       int j = 8, result = 5, i = 0, x = 2, y = 2;
       printf(\"i j result x y j>3\\n\");
       for (; j > 3; j--) {
           printf(\"%d %d %d %d %d %d\\n\", i, j, result, x, y, j > 3);
           i =  (j * result) / x;
           result += y;
           x += (y-2);
           y++;
       } 
       printf(\"%d %d %d %d %d %d\\n\", i, j, result, x, y, j > 3);
   }
   ```


   |  i | j | result |  x | y | j>3 |
   |  0 | 8 |      5 |  2 | 2 |   1 |
   | 20 | 7 |      7 |  2 | 3 |   1 |
   | 24 | 6 |     10 |  3 | 4 |   1 |
   | 20 | 5 |     14 |  5 | 5 |   1 |
   | 14 | 4 |     19 |  8 | 6 |   1 |
   |  9 | 3 |     25 | 12 | 7 |   0 |

## 03
a) rewrite with do-while

   ```c:line-numbers
   #include <stdio.h>

   int main() {
       int weeks = 2, days_in_week = 7;

       int i = 1;
       do {
           printf(\"Week: %d\\n\", i);

           int j = 1;
           do {
               if (i % 2 == 0) {
                   if (j % 2 == 0)
                       printf(\"Day: %d\\n\", j);
               }
               else{
                   if (j % 2 != 0)
                       printf(\"Day: %d\\n\", j);
               }
               j++;
           } while (j <= days_in_week);
           i++;
       } while (i <= weeks);

       return 0;
   }
   ```

   \\\\

b) WAP

   ```c:line-numbers
   #include <stdio.h>

   int main() {
       int n; scanf(\"%d\", &n);

       for (int i = 1; i <= n; i++) {
           for (int j = 0; j < (n-i)*2; j++)
               putchar(' ');

           int start = 2*i;
           for (int j = 0; j < i; j++) {
               printf(\"%d \", start);
               start += 2;
           }

           start -= 4;
           for (int j = 0; j < i-1; j++) {
               printf(\"%d \", start);
               start -= 2;
           }

           putchar('\\n');
       }
   }
   ```


   \\\\

## 04
a) WAP

   ```c:line-numbers
   #include <stdio.h>

   int main() {
       float sum_cg3 = 0;
       int count_cg3 = 0;

       float max = 0;
       float min = 5;
       int count_max = 0;

       float tmp;
       for (int i = 0; i < 100; i++) {
           scanf(\"%d\", &tmp);

           if (tmp > 3) {
               sum_cg3 += tmp;
               count_cg3++;
           }
        
           if (tmp > max) {
               max = tmp;
               count_max = 1;
           } else if (tmp == max)
               count_max++;

           if (tmp < min) min = tmp;
       }

       float avg_cg3 = sum_cg3 / count_cg3;

       printf(\"Average: %.2f\\n\", avg_cg3);
       printf(\"Higest: %.2f and count: %d\\n\", max, count_max);
       printf(\"Lowest: %.2f\\n\", min);
   }
   ```

   \\\\

## 05
a) Initializing ~arr~ with zeros and ~k~ with 15.

   In the first loop, the values at index 1, 3 and 5 are changed.

   ~arr[1] = 16 - 2 = 14~ \\\\
   ~k      = 16 + 1 = 17~

   ~arr[3] = 18 - 2 = 16~ \\\\
   ~k      = 18 + 1 = 19~ \\\\

   ~arr[5] = 20 - 2 = 18~ \\\\
   ~k      = 20 + 1 = 21~

   ~arr = {0, 14, 0, 16, 0, 18, 0, 0, 0, 0}~ \\\\
   ~k   = 21~

   After initializing ~i~ with 0, the second loop modifies the elements
   at indices from 6 to 10.

   ~arr[9] = 1~ \\\\
   ~arr[8] = 2~ \\\\
   ~arr[7] = 3~ \\\\
   ~arr[6] = 4~ \\\\

   ~arr[9] = 5~ \\\\
   ~arr[8] = 6~ \\\\
   ~arr[7] = 7~ \\\\

   ~arr[9] = 8~ \\\\
   ~arr[8] = 9~ \\\\

   ~arr[9] = 10~ \\\\

   ~arr = {0, 14, 0, 16, 0, 18, 4, 7, 9, 10}~ \\\\
   ~c   = 10~

   The third loop modifies the even indices e.g. 0, 2, 4.

   ~arr[0] = 22~ \\\\
   ~arr[2] = 23~ \\\\
   ~arr[4] = 24~ \\\\
   ~arr[6] = 25~ \\\\
   ~arr[8] = 26~ \\\\

   ~arr = {22, 14, 23, 16, 24, 18, 25, 7, 26, 10}~ \\\\
   ~k   = 26~

   ```c:line-numbers
   #include <stdio.h>

   int main() {
       int arr[10] = {0};
       int k = 15;
       for (int i = 1; i < 6; i += 2) {
           arr[i] = ++k - 2;
           k++;
       }

       printf(\"arr = {\")
           for (int i = 0; i < 9; i++)
               printf(\"%d, \", arr[i]);
       printf(\"%d}\\n\", arr[9]);
       printf(\"k   = %d\\n\", k);

       int c = 0;
       for (int i = 6; i < 10; i++) {
           for (int j = 10; j >= i; j--) {
               arr[j] = ++c;
           }
       }

       printf(\"arr = {\")
           for (int i = 0; i < 9; i++)
               printf(\"%d, \", arr[i]);
       printf(\"%d}\\n\", arr[9]);
       printf(\"c   = %d\\n\", c);

       for (int i = 0; i < 10; i++) {
           if (i % 2 == 0) {
               arr[i] = ++k;
           }
       }

       printf(\"arr = {\")
           for (int i = 0; i < 9; i++)
               printf(\"%d, \", arr[i]);
       printf(\"%d}\\n\", arr[9]);
       printf(\"k   = %d\\n\", k);
   }
   ```


b) 2d array ~arr~" . 36) ((marker . 3992) . -175) ((marker . 4048) . -175) (t 26161 42280 712042 207000) nil (1 . 6749) ("#+setupfile: \"../../setup.org\"
#+HTML_HEAD: <style type=\"text/css\">
#+HTML_HEAD:  ol { list-style-type: lower-alpha; }
#+HTML_HEAD:  li { margin: 1em 0; }
#+HTML_HEAD: </style>

#+title: 23sp
#+property: header-args :exports none

* 01
a) invalid: 1, 3, 4, 5

b) ~a = 3~ \\\\
   ~b = 3*4 = 12.0~ \\\\
   ~c = (3 > 12 || 3 == 3) * 2 = (0 || 1) * 2 = 2~ \\\\
   ~d = 3/2 = 1.0~

   #+name: 01.b
   #+begin_src C -n :includes <stdio.h>
   int a = (float)15/4;
   float b = a++*a--;
   int c = (a > b || a == 1 + 2) * 2;
   float d = a/c;
   printf(\"%d, %.2f, %d, %.2f\\n\", a, b, c, d);
   #+end_src

   #+RESULTS: 01.b
   | 3 | 12.0 | 2 | 1.0 |

c) ~b = 10~:
   #+begin_example
   SPL
   Spring
   #+end_example
   \\\\

   ~b = 2~:
   #+begin_example
   Spring
   #+end_example
   \\\\

   #+name: 01.c
   #+begin_src C -n :results output
   #include <stdio.h>
   int main() {
       int b = 2;

       if (b >= 10) {
           printf(\"SPL\\n\");
           b--;
       }

       if (b < 10) {
           printf(\"Spring\\n\");
           b--;
       }
       else if ((b >= 3) || (b < 10))
           printf(\"2023\\n\");
       else if (b >= 3 && b < 10)
           printf(\"Happy Coding!\");
       else
           printf(\"Huh!\");
       return 0;
   }
   #+end_src

   #+RESULTS: 01.c
   : Spring

* 02
a) rewrite using switch

   #+begin_src C -n :exports code
   int n, a;
   scanf(“%d %d”, &n, &a);

   switch (n > a) {
   case 1:
       switch (n-a > 5) {
       case 1:
           printf(“Difference is greater than 5\\n”);
           break;
       default:
           printf(“Difference is less than or equal to 5\\n”);
           break;
       }
       break;
   default:
       printf(“Please give a larger value of n\\n”);
       break;
   }
   #+end_src
   \\\\

b) Trace table
   
   #+name: 02.b
   #+begin_src C -n :results output table :exports results
   #include <stdio.h>
   int main() {
       int j = 8, result = 5, i = 0, x = 2, y = 2;
       printf(\"i j result x y j>3\\n\");
       for (; j > 3; j--) {
           printf(\"%d %d %d %d %d %d\\n\", i, j, result, x, y, j > 3);
           i =  (j * result) / x;
           result += y;
           x += (y-2);
           y++;
       } 
       printf(\"%d %d %d %d %d %d\\n\", i, j, result, x, y, j > 3);
   }
   #+end_src

   #+RESULTS: 02.b
   |  i | j | result |  x | y | j>3 |
   |  0 | 8 |      5 |  2 | 2 |   1 |
   | 20 | 7 |      7 |  2 | 3 |   1 |
   | 24 | 6 |     10 |  3 | 4 |   1 |
   | 20 | 5 |     14 |  5 | 5 |   1 |
   | 14 | 4 |     19 |  8 | 6 |   1 |
   |  9 | 3 |     25 | 12 | 7 |   0 |

* 03
a) rewrite with do-while

   #+name: 03.a
   #+begin_src C -n :exports code
   #include <stdio.h>

   int main() {
       int weeks = 2, days_in_week = 7;

       int i = 1;
       do {
           printf(\"Week: %d\\n\", i);

           int j = 1;
           do {
               if (i % 2 == 0) {
                   if (j % 2 == 0)
                       printf(\"Day: %d\\n\", j);
               }
               else{
                   if (j % 2 != 0)
                       printf(\"Day: %d\\n\", j);
               }
               j++;
           } while (j <= days_in_week);
           i++;
       } while (i <= weeks);

       return 0;
   }
   #+end_src
   \\\\

b) WAP

   #+name: 03.b
   #+begin_src C -n :exports code :results output
   #include <stdio.h>

   int main() {
       int n; scanf(\"%d\", &n);

       for (int i = 1; i <= n; i++) {
           for (int j = 0; j < (n-i)*2; j++)
               putchar(' ');

           int start = 2*i;
           for (int j = 0; j < i; j++) {
               printf(\"%d \", start);
               start += 2;
           }

           start -= 4;
           for (int j = 0; j < i-1; j++) {
               printf(\"%d \", start);
               start -= 2;
           }

           putchar('\\n');
       }
   }
   #+end_src

   \\\\

* 04
a) WAP

   #+name: 04.a
   #+begin_src C -n :exports code
   #include <stdio.h>

   int main() {
       float sum_cg3 = 0;
       int count_cg3 = 0;

       float max = 0;
       float min = 5;
       int count_max = 0;

       float tmp;
       for (int i = 0; i < 100; i++) {
           scanf(\"%d\", &tmp);

           if (tmp > 3) {
               sum_cg3 += tmp;
               count_cg3++;
           }
        
           if (tmp > max) {
               max = tmp;
               count_max = 1;
           } else if (tmp == max)
               count_max++;

           if (tmp < min) min = tmp;
       }

       float avg_cg3 = sum_cg3 / count_cg3;

       printf(\"Average: %.2f\\n\", avg_cg3);
       printf(\"Higest: %.2f and count: %d\\n\", max, count_max);
       printf(\"Lowest: %.2f\\n\", min);
   }
   #+end_src
   \\\\

* 05
a) Initializing ~arr~ with zeros and ~k~ with 15.

   In the first loop, the values at index 1, 3 and 5 are changed.

   ~arr[1] = 16 - 2 = 14~ \\\\
   ~k      = 16 + 1 = 17~

   ~arr[3] = 18 - 2 = 16~ \\\\
   ~k      = 18 + 1 = 19~ \\\\

   ~arr[5] = 20 - 2 = 18~ \\\\
   ~k      = 20 + 1 = 21~

   ~arr = {0, 14, 0, 16, 0, 18, 0, 0, 0, 0}~ \\\\
   ~k   = 21~

   After initializing ~i~ with 0, the second loop modifies the elements
   at indices from 6 to 10.

   ~arr[9] = 1~ \\\\
   ~arr[8] = 2~ \\\\
   ~arr[7] = 3~ \\\\
   ~arr[6] = 4~ \\\\

   ~arr[9] = 5~ \\\\
   ~arr[8] = 6~ \\\\
   ~arr[7] = 7~ \\\\

   ~arr[9] = 8~ \\\\
   ~arr[8] = 9~ \\\\

   ~arr[9] = 10~ \\\\

   ~arr = {0, 14, 0, 16, 0, 18, 4, 7, 9, 10}~ \\\\
   ~c   = 10~

   The third loop modifies the even indices e.g. 0, 2, 4.

   ~arr[0] = 22~ \\\\
   ~arr[2] = 23~ \\\\
   ~arr[4] = 24~ \\\\
   ~arr[6] = 25~ \\\\
   ~arr[8] = 26~ \\\\

   ~arr = {22, 14, 23, 16, 24, 18, 25, 7, 26, 10}~ \\\\
   ~k   = 26~

   #+name: 05.a
   #+begin_src C -n
   #include <stdio.h>

   int main() {
       int arr[10] = {0};
       int k = 15;
       for (int i = 1; i < 6; i += 2) {
           arr[i] = ++k - 2;
           k++;
       }

       printf(\"arr = {\")
           for (int i = 0; i < 9; i++)
               printf(\"%d, \", arr[i]);
       printf(\"%d}\\n\", arr[9]);
       printf(\"k   = %d\\n\", k);

       int c = 0;
       for (int i = 6; i < 10; i++) {
           for (int j = 10; j >= i; j--) {
               arr[j] = ++c;
           }
       }

       printf(\"arr = {\")
           for (int i = 0; i < 9; i++)
               printf(\"%d, \", arr[i]);
       printf(\"%d}\\n\", arr[9]);
       printf(\"c   = %d\\n\", c);

       for (int i = 0; i < 10; i++) {
           if (i % 2 == 0) {
               arr[i] = ++k;
           }
       }

       printf(\"arr = {\")
           for (int i = 0; i < 9; i++)
               printf(\"%d, \", arr[i]);
       printf(\"%d}\\n\", arr[9]);
       printf(\"k   = %d\\n\", k);
   }
   #+end_src

b) 2d array ~arr~

   | 1 |  2 |  3 |  5 |  8 |
   | 2 |  3 |  5 |  8 | 13 |
   | 3 |  5 |  8 | 13 | 21 |
   | 5 |  8 | 13 | 21 | 34 |
   | 8 | 13 | 21 | 34 | 55 |

   #+name: 05.b
   #+begin_src C -n :results output table
   #include <stdio.h>

   int main() {
       int arr[100][100], i, j, t1 = 0, t2 = 1, t3, x, y, z;

       for (i = 0; i < 5; i++) {
           x = t1, y = t2, z = t1 + t2;
           for (j = 0; j < 5; j++) {
               t3 = t1 + t2;
               arr[j][i] = t3;
               t1 = t2;
               t2 = t3;
           }
           t1 = y;
           t2 = z;
       }

       for (int i = 0; i < 5; i++) {
           for (int j = 0; j < 5; j++)
               printf(\"%d \", arr[i][j]);
           putchar('\\n');
       }
   }
   #+end_src" . 1) ((marker . 3992) . -178) ((marker . 4048) . -178) (t 26160 52102 643000 569000)) (emacs-pending-undo-list ("   | 5 |  8 | 13 | 21 | 34 |
" . 4160) ((marker* . 4078) . 29) (4131 . 4160) ("   | 3 |  5 |  8 | 13 | 21 |
" . 4131) ((marker* . 4078) . 29) (4102 . 4131) ("   | 2 |  3 |  5 |  8 | 13 |
" . 4102) ((marker* . 4078) . 29) (4073 . 4102) ("   |-
" . 4073) ((marker* . 4078) . 1) ((marker . 4048) . -5) ((marker) . -5) (4044 . 4073) ("   | 1 |  2 |  3 |  5 |  8 |
" . 4044) ((marker . 4044) . -28) ((marker . 4044) . -28) ((marker . 4044) . -28) ((marker . 4044) . -28) ((marker . 4044) . -28) ((marker . 4044) . -28) ((marker . 4044) . -28) ((marker . 4044) . -28) ((marker . 4044) . -28) ((marker) . -29) ((marker) . -29) (4015 . 4044) 4049 (4047 . 4049) (4043 . 4047) (t 26161 43675 241243 688000) 4017 nil ("
   " . 4043) ((marker* . 4078) . 3) ((marker . 4044) . -4) ((marker . 4044) . -4) ((marker . 4044) . -4) ((marker . 4044) . -4) ((marker . 4044) . -4) ((marker . 4044) . -4) ((marker . 4044) . -4) ((marker . 4044) . -4) ((marker . 4044) . -4) ("|" . 4047) ("   | 1 | 2  | 3  | 5  | 8  |
" . 4015) ((marker) . -29) ((marker . 4015) . -29) ((marker . 4015) . -29) ((marker . 4015) . -29) ((marker . 4015) . -29) ((marker . 4048) . -29) ((marker . 4015) . -29) ((marker . 4015) . -29) ((marker . 4015) . -29) ((marker . 4015) . -29) ((marker . 4015) . -29) ((marker) . -29) (4044 . 4073) ("   |   |    |    |    |    |
" . 4044) ((marker* . 4078) . 20) ((marker . 4015) . -8) ((marker . 4015) . -8) ((marker . 4015) . -8) ((marker . 4015) . -8) ((marker . 4048) . -8) ((marker . 4015) . -8) ((marker . 4015) . -8) ((marker . 4015) . -8) ((marker . 4015) . -8) ((marker . 4015) . -8) ((marker) . -8) (4073 . 4078) ("   | 2 | 3  | 5  | 8  | 13 |
" . 4073) (4102 . 4131) ("   | 3 | 5  | 8  | 13 | 21 |
" . 4102) (4131 . 4160) ("   | 5 | 8  | 13 | 21 | 34 |
" . 4131) (4160 . 4189) nil ("   | 5 |  8 | 13 | 21 | 34 |
" . 4160) (4131 . 4160) ("   | 3 |  5 |  8 | 13 | 21 |
" . 4131) (4102 . 4131) ("   | 2 |  3 |  5 |  8 | 13 |
" . 4102) (4073 . 4102) ("   |
" . 4073) ((marker . 4044) . -3) ((marker . 4044) . -3) ((marker . 4044) . -3) ((marker . 4044) . -3) ((marker . 4048) . -4) ((marker . 4044) . -3) ((marker . 4044) . -3) ((marker . 4044) . -3) ((marker . 4044) . -3) ((marker . 4044) . -3) ((marker) . -4) (4044 . 4073) ("   | 1 |  2 |  3 |  5 |  8 |
" . 4044) ((marker) . -29) ((marker) . -29) (4015 . 4044) 4048 (4047 . 4048) (4043 . 4047) (t 26161 43675 241243 688000) 4017 nil (3992 . 3995) ("   " . 3992) ((marker* . 3995) . 3) ("
" . -3992) ((marker . 3992) . -1) ((marker . 4019) . -1) ((marker . 4015) . -1) ((marker . 4015) . -1) ((marker . 3992) . -1) ((marker . 3992) . -1) ((marker . 3992) . -1) ((marker . 3992) . -1) nil ("   ```c:line-numbers
   ```
" . 3993) ((marker . 3992) . -21) ((marker . 4019) . -21) ((marker . 4015) . -27) ((marker . 3992) . -21) ((marker . 4048) . -21) 4014 nil ("   #include <stdio.h>

   int main() {
       int arr[10] = {0};
       int k = 15;
       for (int i = 1; i < 6; i += 2) {
           arr[i] = ++k - 2;
           k++;
       }

       printf(\"arr = {\")
           for (int i = 0; i < 9; i++)
               printf(\"%d, \", arr[i]);
       printf(\"%d}\\n\", arr[9]);
       printf(\"k   = %d\\n\", k);

       int c = 0;
       for (int i = 6; i < 10; i++) {
           for (int j = 10; j >= i; j--) {
               arr[j] = ++c;
           }
       }

       printf(\"arr = {\")
           for (int i = 0; i < 9; i++)
               printf(\"%d, \", arr[i]);
       printf(\"%d}\\n\", arr[9]);
       printf(\"c   = %d\\n\", c);

       for (int i = 0; i < 10; i++) {
           if (i % 2 == 0) {
               arr[i] = ++k;
           }
       }

       printf(\"arr = {\")
           for (int i = 0; i < 9; i++)
               printf(\"%d, \", arr[i]);
       printf(\"%d}\\n\", arr[9]);
       printf(\"k   = %d\\n\", k);
   }
" . 4014) (4971 . 4971) nil (4978 . 4981) ("
" . -4978) nil (5143 . 5144) nil ("
" . -5143) ((marker* . 3995) . 1) 5142 nil ("
" . -5143) ((marker . 4019) . -1) ((marker . 4015) . -1) ((marker . 4015) . -1) ((marker . 3992) . -1) ((marker . 3992) . -1) ((marker . 3992) . -1) 5115 nil ("
   ```c:line-numbers
   #include <stdio.h>

   int main() {
       int arr[100][100], i, j, t1 = 0, t2 = 1, t3, x, y, z;

       for (i = 0; i < 5; i++) {
           x = t1, y = t2, z = t1 + t2;
           for (j = 0; j < 5; j++) {
               t3 = t1 + t2;
               arr[j][i] = t3;
               t1 = t2;
               t2 = t3;
           }
           t1 = y;
           t2 = z;
       }

       for (int i = 0; i < 5; i++) {
           for (int j = 0; j < 5; j++)
               printf(\"%d \", arr[i][j]);
           putchar('\\n');
       }
   }
   ```
" . 5144) ((marker . 4019) . -559) ((marker . 4015) . -565) ((marker . 3992) . -559) (t 26161 43578 350978 862000) nil ("b)" . -1720) (1722 . 1724) nil (1092 . 1093) 1087 nil ("a)" . -1093) (1095 . 1097) nil (")" . 4980) (4981 . 4982) 4980 ("b" . 4979) (4980 . 4981) 4979 nil (3110 . 3111) ("~" . 3110) nil (3093 . 3094) ("~" . 3093) ((marker) . -1) nil (")" . 3074) (3075 . 3076) 3074 ("a" . 3073) (3074 . 3075) 3073 nil (3071 . 3072) 3066 nil (3061 . 3064) ("    " . 3061) ("
" . -3061) nil ("
" . -2271) ("    " . 2271) ("
" . -2271) nil (2283 . 2284) 2279 nil (")" . 2285) (2286 . 2287) 2285 ("a" . 2284) (2285 . 2286) 2284 nil (1050 . 1051) (1049 . 1050) (1048 . 1049) (1012 . 1013) (1011 . 1012) (1010 . 1011) (974 . 975) (973 . 974) (972 . 973) (936 . 937) (935 . 936) (934 . 935) (898 . 899) (897 . 898) (896 . 897) (860 . 861) (859 . 860) (858 . 859) (822 . 823) (821 . 822) (820 . 821) (782 . 785) nil ("    " . 782) ((marker . 4048) . -1) ("    " . 821) ("    " . 860) ("    " . 899) ("    " . 938) ("    " . 977) ("    " . 1016) ("    " . 1055) nil (1055 . 1059) (1016 . 1020) (977 . 981) (938 . 942) (899 . 903) (860 . 864) (821 . 825) (782 . 786) 1028 nil (")" . 767) (768 . 769) 767 ("b" . 766) (767 . 768) 766 nil ("
" . -781) ((marker* . 3995) . 1) ("   " . 781) ((marker . 4019) . -3) ((marker . 4015) . -3) ((marker . 4015) . -3) ((marker . 3992) . -3) ((marker . 3992) . -3) ((marker . 3992) . -3) ("
" . -784) ((marker . 4019) . -1) ((marker . 4015) . -1) ((marker . 4015) . -1) ((marker . 3992) . -1) ((marker . 3992) . -1) ((marker . 3992) . -1) 781 nil ("   ```c:line-numbers
   #include <stdio.h>
   int main() {
       int j = 8, result = 5, i = 0, x = 2, y = 2;
       printf(\"i j result x y j>3\\n\");
       for (; j > 3; j--) {
           printf(\"%d %d %d %d %d %d\\n\", i, j, result, x, y, j > 3);
           i =  (j * result) / x;
           result += y;
           x += (y-2);
           y++;
       } 
       printf(\"%d %d %d %d %d %d\\n\", i, j, result, x, y, j > 3);
   }
   ```
" . 785) ((marker . 4019) . -423) ((marker . 4015) . -429) ((marker . 3992) . -423) nil (311 . 312) 311 nil (317 . 318) 313 nil (")" . 319) (320 . 321) 319 ("a" . 318) (319 . 320) 318 nil (35 . 40) (t 26161 43237 987599 306000) nil ("/spl/solve-mid/" . 34) ((marker . 3997) . -14) ((marker . 4019) . -14) ((marker . 34) . -14) ((marker . 34) . -14) ((marker . 34) . -14) ((marker . 34) . -14) ((marker . 34) . -14) ((marker . 3992) . -14) (t 26161 43171 498132 741000) nil (34 . 49) (t 26161 43147 247091 736000) nil ("      [ 'link',
        { href: '', rel: 'stylesheet' }
      ]
" . 62) ((marker . 4019) . -63) ((marker . 4015) . -63) ((marker . 3992) . -9) ((marker . 3992) . -63) ((marker . 67) . -6) ((marker . 67) . -6) ((marker . 67) . -6) ((marker . 4048) . -63) 125 nil ("  - - meta
    - name: keywords
      content: super duper SEO
" . 62) ((marker . 4019) . -41) ((marker . 4015) . -62) ((marker . 3992) . -9) ((marker . 3992) . -41) ((marker . 4048) . -41) 103 nil (51 . 61) ("hello" . 51) ((marker . 4015) . -4) ((marker . 4048) . -3) 54 nil (46 . 49) ("content" . 46) ((marker . 4015) . -6) ((marker . 4048) . -3) 49 nil (46 . 53) ("href" . 46) ((marker . 3997) . -3) ((marker . 3992) . -3) nil (46 . 50) ("content" . 46) ((marker . 4015) . -6) ((marker . 4048) . -4) 50 nil ("/" . 34) nil (34 . 35) nil ("./" . 34) nil (34 . 36) nil (34 . 39) nil ("https://fonts.googleapis.com/css2?family=JetBrains+Mono:ital,wght@0,100..800;1,100..800&display=swap" . 34) ((marker . 4015) . -99) ((marker . 4048) . -99) (nil rear-nonsticky nil 133 . 134) nil (nil rear-nonsticky nil 133 . 134) (nil fontified nil 34 . 134) (34 . 134) 33 nil ("https://fonts.googleapis.com/css2?family=JetBrains+Mono:ital,wght@0,100..800;1,100..800&display=swap" . 152) ((marker . 4015) . -99) ((marker . 4048) . -1) 153 nil ("description" . 34) ((marker . 4015) . -10) nil (28 . 32) ("name" . 28) ((marker . 4015) . -3) ((marker . 4048) . -2) 30 nil (17 . 21) ("meta" . 17) ((marker . 4015) . -3) nil (nil rear-nonsticky nil 128 . 129) (nil fontified nil 5 . 129) (5 . 129) nil (4 . 5) 3 nil (nil rear-nonsticky nil 168 . 169) ("
" . -172) (168 . 173) 163 nil (1 . 4) nil (1 . 2) 7 nil ("<style>
  ol {
    list-style-type: lower-roman;
  }
</style>
" . 1) ((marker . 3997) . -60) ((marker . 4019) . -59) ((marker* . 4078) . 14) ((marker . 4015) . -61) ((marker . 3992) . -59) ((marker . 3992) . -6) ((marker . 1) . -15) ((marker . 1) . -15) ((marker . 1) . -60) ((marker . 1) . -60) ((marker . 3992) . -60) ((marker . 4048) . -6) 7 nil (nil rear-nonsticky nil 68 . 69) ("
" . -226) (62 . 227) 61 (t 26161 42926 280339 898000) nil (48 . 49) nil (37 . 48) ("u" . -37) ((marker . 4048) . -1) 38 (26 . 38) ("s" . -26) ((marker . 4048) . -1) 27 (20 . 27) (16 . 20) ("  " . 16) ((marker . 4048) . -2) 18 (16 . 18) (16 . 17) 17 nil (15 . 18) (13 . 16) ("d" . -13) ((marker . 4048) . -1) 14 (9 . 14) (8 . 9) ("
" . -8) ((marker . 4048) . -1) 9 ("    " . -9) ((marker . 4048) . -4) 13 ("o" . -13) ((marker . 4048) . -1) ("d" . -14) ((marker . 4048) . -1) ("l" . -15) ((marker . 4048) . -1) 16 (13 . 16) (9 . 13) (9 . 10) 16 nil (9 . 17) (8 . 9) (4 . 8) ("d" . -4) ((marker . 3997) . -1) ((marker . 3992) . -1) ((marker . 4048) . -1) ("y" . -5) ((marker . 4048) . -1) 6 (1 . 6) ("," . -1) ((marker . 4048) . -1) 2 (1 . 2) (1 . 2) (t 26161 42794 60307 898000) nil ("
   " . 152) ((marker . 3997) . -4) ((marker . 3992) . -4) ((marker . 4048) . -4) ("
   " . 156) ((marker . 3997) . -4) ((marker . 3992) . -4) ((marker . 4048) . -4) ("1. hello" . 160) ((marker . 3997) . -8) ((marker . 3992) . -8) ((marker . 4048) . -8) ("
   " . 168) ((marker . 3997) . -4) ((marker . 3992) . -4) ((marker . 4048) . -4) ("2. friedn" . 172) ((marker . 3997) . -5) ((marker . 3992) . -5) ((marker . 4048) . -8) (t 26161 42783 653087 433000) nil (172 . 181) (168 . 172) (160 . 168) (156 . 160) (152 . 156) (t 26161 42758 251717 658000) 138 nil ("    " . 46) ((marker . 4048) . -4) nil (46 . 50) (t 26161 42758 251717 658000) nil (46 . 47) ("1" . 46) nil (157 . 158) ("1" . 157) nil (")" . 158) (159 . 160) 158 ("c" . 157) (158 . 159) 157 nil (")" . 47) (48 . 49) 47 ("b" . 46) (47 . 48) 46 nil ("1" . 48) ((marker . 118) . -1) ((marker . 118) . -1) ((marker . 118) . -1) ((marker . 118) . -1) ((marker . 4048) . -1) ((marker . 118) . -1) ((marker . 118) . -1) ((marker . 118) . -1) ((marker . 118) . -1) ((marker . 118) . -1) ((marker) . -1) (47 . 48) ("." . 49) (48 . 49) nil (" " . 48) (49 . 50) 48 (")" . 47) (48 . 49) 47 nil (")" . 23) (24 . 25) 23 ("a" . 22) (t 26161 42744 470963 430000) (23 . 24) 22 (t 26161 42744 470963 430000) nil (22 . 23) ("1" . 22) nil (22 . 23) ("a" . 22) ((marker) . -1) (t 26161 42744 470963 430000) nil ("   
   ```c:line-numbers
   #include <stdio.h>
   int main() {
       int b = 2;

       if (b >= 10) {
           printf(\"SPL\\n\");
           b--;
       }

       if (b < 10) {
           printf(\"Spring\\n\");
           b--;
       }
       else if ((b >= 3) || (b < 10))
           printf(\"2023\\n\");
       else if (b >= 3 && b < 10)
           printf(\"Happy Coding!\");
       else
           printf(\"Huh!\");
       return 0;
   }
   ```


   : Spring
" . 241) ((marker . 4019) . -442) ((marker . 4015) . -453) ((marker . 311) . -441) ((marker . 3992) . -442) (t 26161 42732 266955 414000) nil (153 . 156) ("   " . 153) ((marker . 4048) . -2) ("
" . -156) ((marker* . 4078) . 1) ((marker* . 3995) . 1) (153 . 156) ("   " . 153) ("
" . -156) ((marker* . 4078) . 1) ((marker* . 3995) . 1) 153 nil ("   | 3 | 12.0 | 2 | 1.0 |
" . 158) ((marker . 4015) . -25) ((marker . 4048) . -2) 160 nil (153 . 156) ("
" . -153) ((marker . 4019) . -1) ((marker . 4015) . -1) ((marker . 4015) . -1) ((marker . 3992) . -1) ((marker . 3992) . -1) ((marker . 3992) . -1) nil ("   ```c:line-numbers
   int a = (float)15/4;
   float b = a++*a--;
   int c = (a > b || a == 1 + 2) * 2;
   float d = a/c;
   printf(\"%d, %.2f, %d, %.2f\\n\", a, b, c, d);
   ```
" . 154) ((marker . 4019) . -170) ((marker* . 4078) . 177) ((marker . 4015) . -176) ((marker . 3992) . -170) nil (apply 63 154 332 undo--wrap-and-run-primitive-undo 154 332 (("<!-- " . 157) (" -->" . 179) ("<!-- " . 187) (" -->" . 212) ("<!-- " . 220) (" -->" . 243) ("<!-- " . 251) (" -->" . 290) ("<!-- " . 298) (" -->" . 317) ("<!-- " . 325) (" -->" . 373) ("<!-- " . 381) (" -->" . 389) 395)) nil (apply -63 154 395 undo--wrap-and-run-primitive-undo 154 395 ((389 . 393) (381 . 386) (373 . 377) (325 . 330) (317 . 321) (298 . 303) (290 . 294) (251 . 256) (243 . 247) (220 . 225) (212 . 216) (187 . 192) (179 . 183) (157 . 162) 331)) nil ("//" . 154) ((marker . 4048) . -1) ("/" . 177) ("/" . 178) ("/" . 203) ("/" . 204) ("/" . 227) ("/" . 228) ("/" . 267) ("/" . 268) ("/" . 287) ("/" . 288) ("/" . 336) ("/" . 337) nil (337 . 338) (336 . 337) (288 . 289) (287 . 288) (268 . 269) (267 . 268) (228 . 229) (227 . 228) (204 . 205) (203 . 204) (178 . 179) (177 . 178) (154 . 156) (t 26161 42556 919795 55000) nil ("#" . 154) ("#" . 176) ("#" . 201) ("#" . 224) ("#" . 263) ("#" . 282) ("#" . 330) nil (330 . 331) (282 . 283) (263 . 264) (224 . 225) (201 . 202) (176 . 177) (154 . 155) (t 26161 42556 919795 55000) nil ("c:line-numbers" . 426) ((marker . 4015) . -13) nil (458 . 461) ("
" . -458) ((marker . 4015) . -1) ((marker . 4015) . -1) nil ("    " . 459) ((marker . 4048) . -2) ("
" . -463) 461 (t 26161 42545 742401 752000) nil (404 . 407) ("   " . 404) ((marker . 4048) . -2) ("
" . -407) (404 . 407) ("    " . 404) ("
" . -404) nil ("c:line-numbers" . 379) ((marker . 4015) . -13) nil (410 . 411) (410 . 413) (" " . 410) nil (410 . 411) ("   " . 410) ("
" . -410) 401 nil (20 . 21) (t 26161 42474 291165 802000) 15 nil (56 . 5011) ("\\\\
   `b = 3*4 = 12.0` \\\\
   `c = (3 > 12 || 3 == 3) * 2 = (0 || 1) * 2 = 2` \\\\
   `d = 3/2 = 1.0`

   ```c:line-numbers
   int a = (float)15/4;
   float b = a++*a--;
   int c = (a > b || a == 1 + 2) * 2;
   float d = a/c;
   printf(\"%d, %.2f, %d, %.2f\\n\", a, b, c, d);
   ```


   | 3 | 12.0 | 2 | 1.0 |

c) `b = 10`:
   ```c:line-numbers
   SPL
   Spring
   ```

   \\\\

   `b = 2`:
   ```c:line-numbers
   Spring
   ```

   \\\\

   ```c:line-numbers
   #include <stdio.h>
   int main() {
       int b = 2;

       if (b >= 10) {
           printf(\"SPL\\n\");
           b--;
       }

       if (b < 10) {
           printf(\"Spring\\n\");
           b--;
       }
       else if ((b >= 3) || (b < 10))
           printf(\"2023\\n\");
       else if (b >= 3 && b < 10)
           printf(\"Happy Coding!\");
       else
           printf(\"Huh!\");
       return 0;
   }
   ```


   : Spring

## 02
a) rewrite using switch

   ```c:line-numbers
   int n, a;
   scanf(“%d %d”, &n, &a);

   switch (n > a) {
   case 1:
       switch (n-a > 5) {
       case 1:
           printf(“Difference is greater than 5\\n”);
           break;
       default:
           printf(“Difference is less than or equal to 5\\n”);
           break;
       }
       break;
   default:
       printf(“Please give a larger value of n\\n”);
       break;
   }
   ```

   \\\\

b) Trace table
   
   ```c:line-numbers
   #include <stdio.h>
   int main() {
       int j = 8, result = 5, i = 0, x = 2, y = 2;
       printf(\"i j result x y j>3\\n\");
       for (; j > 3; j--) {
           printf(\"%d %d %d %d %d %d\\n\", i, j, result, x, y, j > 3);
           i =  (j * result) / x;
           result += y;
           x += (y-2);
           y++;
       } 
       printf(\"%d %d %d %d %d %d\\n\", i, j, result, x, y, j > 3);
   }
   ```


   | i  | j | result | x  | y | j>3 |
   |----|---|--------|----|---|-----|
   | 0  | 8 | 5      | 2  | 2 | 1   |
   | 20 | 7 | 7      | 2  | 3 | 1   |
   | 24 | 6 | 10     | 3  | 4 | 1   |
   | 20 | 5 | 14     | 5  | 5 | 1   |
   | 14 | 4 | 19     | 8  | 6 | 1   |
   | 9  | 3 | 25     | 12 | 7 | 0   |

## 03
a) rewrite with do-while

   ```c:line-numbers
   #include <stdio.h>

   int main() {
       int weeks = 2, days_in_week = 7;

       int i = 1;
       do {
           printf(\"Week: %d\\n\", i);

           int j = 1;
           do {
               if (i % 2 == 0) {
                   if (j % 2 == 0)
                       printf(\"Day: %d\\n\", j);
               }
               else{
                   if (j % 2 != 0)
                       printf(\"Day: %d\\n\", j);
               }
               j++;
           } while (j <= days_in_week);
           i++;
       } while (i <= weeks);

       return 0;
   }
   ```

   \\\\

b) WAP

   ```c:line-numbers
   #include <stdio.h>

   int main() {
       int n; scanf(\"%d\", &n);

       for (int i = 1; i <= n; i++) {
           for (int j = 0; j < (n-i)*2; j++)
               putchar(' ');

           int start = 2*i;
           for (int j = 0; j < i; j++) {
               printf(\"%d \", start);
               start += 2;
           }

           start -= 4;
           for (int j = 0; j < i-1; j++) {
               printf(\"%d \", start);
               start -= 2;
           }

           putchar('\\n');
       }
   }
   ```


   \\\\

## 04
a) WAP

   ```c:line-numbers
   #include <stdio.h>

   int main() {
       float sum_cg3 = 0;
       int count_cg3 = 0;

       float max = 0;
       float min = 5;
       int count_max = 0;

       float tmp;
       for (int i = 0; i < 100; i++) {
           scanf(\"%d\", &tmp);

           if (tmp > 3) {
               sum_cg3 += tmp;
               count_cg3++;
           }
        
           if (tmp > max) {
               max = tmp;
               count_max = 1;
           } else if (tmp == max)
               count_max++;

           if (tmp < min) min = tmp;
       }

       float avg_cg3 = sum_cg3 / count_cg3;

       printf(\"Average: %.2f\\n\", avg_cg3);
       printf(\"Higest: %.2f and count: %d\\n\", max, count_max);
       printf(\"Lowest: %.2f\\n\", min);
   }
   ```

   \\\\

## 05
a) Initializing `arr~ with zeros and ~k` with 15.

   In the first loop, the values at index 1, 3 and 5 are changed.

   `arr[1] = 16 - 2 = 14` \\\\
   `k      = 16 + 1 = 17`

   `arr[3] = 18 - 2 = 16` \\\\
   `k      = 18 + 1 = 19` \\\\

   `arr[5] = 20 - 2 = 18` \\\\
   `k      = 20 + 1 = 21`

   `arr = {0, 14, 0, 16, 0, 18, 0, 0, 0, 0}` \\\\
   `k   = 21`

   After initializing `i` with 0, the second loop modifies the elements
   at indices from 6 to 10.

   `arr[9] = 1` \\\\
   `arr[8] = 2` \\\\
   `arr[7] = 3` \\\\
   `arr[6] = 4` \\\\

   `arr[9] = 5` \\\\
   `arr[8] = 6` \\\\
   `arr[7] = 7` \\\\

   `arr[9] = 8` \\\\
   `arr[8] = 9` \\\\

   `arr[9] = 10` \\\\

   `arr = {0, 14, 0, 16, 0, 18, 4, 7, 9, 10}` \\\\
   `c   = 10`

   The third loop modifies the even indices e.g. 0, 2, 4.

   `arr[0] = 22` \\\\
   `arr[2] = 23` \\\\
   `arr[4] = 24` \\\\
   `arr[6] = 25` \\\\
   `arr[8] = 26` \\\\

   `arr = {22, 14, 23, 16, 24, 18, 25, 7, 26, 10}` \\\\" . 56) ((marker . 4019) . -283) ((marker* . 4078) . 3144) ((marker . 4015) . -1785) ((marker . 4015) . -2089) ((marker . 127) . -407) ((marker . 127) . -407) ((marker . 127) . -407) ((marker . 127) . -407) ((marker . 127) . -1789) ((marker . 127) . -1789) ((marker . 127) . -2722) ((marker . 127) . -2722) ((marker . 127) . -283) nil (1841 . 1844) (1876 . 1879) (1911 . 1914) (1946 . 1949) (1981 . 1984) (2016 . 2019) (2051 . 2054) (2086 . 2089) (t 26161 42436 993396 149000) nil ("   " . -2086) ("   " . -2051) ("   " . -2016) ("   " . -1981) ("   " . -1946) ("   " . -1911) ("   " . -1876) ("   " . -1841) 1845 (t 26161 42422 442964 527000) nil (1841 . 1844) nil ("   " . -1841) 1845 (t 26161 42422 442964 527000) nil ("   |  9 | 3 |     25 | 12 | 7 |   0 |
" . 2145) ((marker* . 4078) . 38) (2107 . 2145) ("   | 14 | 4 |     19 |  8 | 6 |   1 |
" . 2107) ((marker* . 4078) . 38) (2069 . 2107) ("   | 20 | 5 |     14 |  5 | 5 |   1 |
" . 2069) ((marker* . 4078) . 38) (2031 . 2069) ("   | 24 | 6 |     10 |  3 | 4 |   1 |
" . 2031) ((marker* . 4078) . 38) (1993 . 2031) ("   | 20 | 7 |      7 |  2 | 3 |   1 |
" . 1993) ((marker* . 4078) . 38) (1955 . 1993) ("   |  0 | 8 |      5 |  2 | 2 |   1 |
" . 1955) ((marker* . 4078) . 38) (1917 . 1955) ("   |-
" . 1917) ((marker* . 4078) . 1) ((marker . 4048) . -5) (1879 . 1917) ("   |  i | j | result |  x | y | j>3 |
" . 1879) (1841 . 1879) 1884 (1882 . 1884) (1878 . 1882) (t 26161 42388 395284 548000) 1844 nil ("
   " . 1878) ((marker . 4048) . -4) ("|    " . 1882) ((marker . 4048) . -4) nil (1882 . 1887) (1878 . 1882) (t 26161 42388 395284 548000) 1844 nil (337 . 338) nil (" " . 337) (t 26161 42388 395284 548000) nil (6 . 13) ("s" . -6) ((marker . 3997) . -1) ((marker . 3992) . -1) ((marker . 4048) . -1) ("p" . -7) ((marker . 4048) . -1) ("r" . -8) ((marker . 4048) . -1) ("i" . -9) ((marker . 4048) . -1) ("n" . -10) ((marker . 4048) . -1) ("g" . -11) ((marker . 4048) . -1) 12 (11 . 12) ("t" . -11) ((marker . 4048) . -1) 12 (4 . 12) (2 . 4) (2 . 3) (t 26161 42332 476942 169000) nil (36 . 6036) ("~a = 3~ \\\\
   ~b = 3*4 = 12.0~ \\\\
   ~c = (3 > 12 || 3 == 3) * 2 = (0 || 1) * 2 = 2~ \\\\
   ~d = 3/2 = 1.0~

   ```c:line-numbers
   int a = (float)15/4;
   float b = a++*a--;
   int c = (a > b || a == 1 + 2) * 2;
   float d = a/c;
   printf(\"%d, %.2f, %d, %.2f\\n\", a, b, c, d);
   ```


   | 3 | 12.0 | 2 | 1.0 |

c) ~b = 10~:
   ```c:line-numbers
   SPL
   Spring
   ```

   \\\\

   ~b = 2~:
   ```c:line-numbers
   Spring
   ```

   \\\\

   ```c:line-numbers
   #include <stdio.h>
   int main() {
       int b = 2;

       if (b >= 10) {
           printf(\"SPL\\n\");
           b--;
       }

       if (b < 10) {
           printf(\"Spring\\n\");
           b--;
       }
       else if ((b >= 3) || (b < 10))
           printf(\"2023\\n\");
       else if (b >= 3 && b < 10)
           printf(\"Happy Coding!\");
       else
           printf(\"Huh!\");
       return 0;
   }
   ```


   : Spring

## 02
a) rewrite using switch

   ```c:line-numbers
   int n, a;
   scanf(“%d %d”, &n, &a);

   switch (n > a) {
   case 1:
       switch (n-a > 5) {
       case 1:
           printf(“Difference is greater than 5\\n”);
           break;
       default:
           printf(“Difference is less than or equal to 5\\n”);
           break;
       }
       break;
   default:
       printf(“Please give a larger value of n\\n”);
       break;
   }
   ```

   \\\\

b) Trace table
   
   ```c:line-numbers
   #include <stdio.h>
   int main() {
       int j = 8, result = 5, i = 0, x = 2, y = 2;
       printf(\"i j result x y j>3\\n\");
       for (; j > 3; j--) {
           printf(\"%d %d %d %d %d %d\\n\", i, j, result, x, y, j > 3);
           i =  (j * result) / x;
           result += y;
           x += (y-2);
           y++;
       } 
       printf(\"%d %d %d %d %d %d\\n\", i, j, result, x, y, j > 3);
   }
   ```


   |  i | j | result |  x | y | j>3 |
   |  0 | 8 |      5 |  2 | 2 |   1 |
   | 20 | 7 |      7 |  2 | 3 |   1 |
   | 24 | 6 |     10 |  3 | 4 |   1 |
   | 20 | 5 |     14 |  5 | 5 |   1 |
   | 14 | 4 |     19 |  8 | 6 |   1 |
   |  9 | 3 |     25 | 12 | 7 |   0 |

## 03
a) rewrite with do-while

   ```c:line-numbers
   #include <stdio.h>

   int main() {
       int weeks = 2, days_in_week = 7;

       int i = 1;
       do {
           printf(\"Week: %d\\n\", i);

           int j = 1;
           do {
               if (i % 2 == 0) {
                   if (j % 2 == 0)
                       printf(\"Day: %d\\n\", j);
               }
               else{
                   if (j % 2 != 0)
                       printf(\"Day: %d\\n\", j);
               }
               j++;
           } while (j <= days_in_week);
           i++;
       } while (i <= weeks);

       return 0;
   }
   ```

   \\\\

b) WAP

   ```c:line-numbers
   #include <stdio.h>

   int main() {
       int n; scanf(\"%d\", &n);

       for (int i = 1; i <= n; i++) {
           for (int j = 0; j < (n-i)*2; j++)
               putchar(' ');

           int start = 2*i;
           for (int j = 0; j < i; j++) {
               printf(\"%d \", start);
               start += 2;
           }

           start -= 4;
           for (int j = 0; j < i-1; j++) {
               printf(\"%d \", start);
               start -= 2;
           }

           putchar('\\n');
       }
   }
   ```


   \\\\

## 04
a) WAP

   ```c:line-numbers
   #include <stdio.h>

   int main() {
       float sum_cg3 = 0;
       int count_cg3 = 0;

       float max = 0;
       float min = 5;
       int count_max = 0;

       float tmp;
       for (int i = 0; i < 100; i++) {
           scanf(\"%d\", &tmp);

           if (tmp > 3) {
               sum_cg3 += tmp;
               count_cg3++;
           }
        
           if (tmp > max) {
               max = tmp;
               count_max = 1;
           } else if (tmp == max)
               count_max++;

           if (tmp < min) min = tmp;
       }

       float avg_cg3 = sum_cg3 / count_cg3;

       printf(\"Average: %.2f\\n\", avg_cg3);
       printf(\"Higest: %.2f and count: %d\\n\", max, count_max);
       printf(\"Lowest: %.2f\\n\", min);
   }
   ```

   \\\\

## 05
a) Initializing ~arr~ with zeros and ~k~ with 15.

   In the first loop, the values at index 1, 3 and 5 are changed.

   ~arr[1] = 16 - 2 = 14~ \\\\
   ~k      = 16 + 1 = 17~

   ~arr[3] = 18 - 2 = 16~ \\\\
   ~k      = 18 + 1 = 19~ \\\\

   ~arr[5] = 20 - 2 = 18~ \\\\
   ~k      = 20 + 1 = 21~

   ~arr = {0, 14, 0, 16, 0, 18, 0, 0, 0, 0}~ \\\\
   ~k   = 21~

   After initializing ~i~ with 0, the second loop modifies the elements
   at indices from 6 to 10.

   ~arr[9] = 1~ \\\\
   ~arr[8] = 2~ \\\\
   ~arr[7] = 3~ \\\\
   ~arr[6] = 4~ \\\\

   ~arr[9] = 5~ \\\\
   ~arr[8] = 6~ \\\\
   ~arr[7] = 7~ \\\\

   ~arr[9] = 8~ \\\\
   ~arr[8] = 9~ \\\\

   ~arr[9] = 10~ \\\\

   ~arr = {0, 14, 0, 16, 0, 18, 4, 7, 9, 10}~ \\\\
   ~c   = 10~

   The third loop modifies the even indices e.g. 0, 2, 4.

   ~arr[0] = 22~ \\\\
   ~arr[2] = 23~ \\\\
   ~arr[4] = 24~ \\\\
   ~arr[6] = 25~ \\\\
   ~arr[8] = 26~ \\\\

   ~arr = {22, 14, 23, 16, 24, 18, 25, 7, 26, 10}~ \\\\
   ~k   = 26~

   ```c:line-numbers
   #include <stdio.h>

   int main() {
       int arr[10] = {0};
       int k = 15;
       for (int i = 1; i < 6; i += 2) {
           arr[i] = ++k - 2;
           k++;
       }

       printf(\"arr = {\")
           for (int i = 0; i < 9; i++)
               printf(\"%d, \", arr[i]);
       printf(\"%d}\\n\", arr[9]);
       printf(\"k   = %d\\n\", k);

       int c = 0;
       for (int i = 6; i < 10; i++) {
           for (int j = 10; j >= i; j--) {
               arr[j] = ++c;
           }
       }

       printf(\"arr = {\")
           for (int i = 0; i < 9; i++)
               printf(\"%d, \", arr[i]);
       printf(\"%d}\\n\", arr[9]);
       printf(\"c   = %d\\n\", c);

       for (int i = 0; i < 10; i++) {
           if (i % 2 == 0) {
               arr[i] = ++k;
           }
       }

       printf(\"arr = {\")
           for (int i = 0; i < 9; i++)
               printf(\"%d, \", arr[i]);
       printf(\"%d}\\n\", arr[9]);
       printf(\"k   = %d\\n\", k);
   }
   ```


b) 2d array ~arr~" . 36) ((marker . 3992) . -175) ((marker . 4048) . -175) (t 26161 42280 712042 207000) nil (1 . 6749) ("#+setupfile: \"../../setup.org\"
#+HTML_HEAD: <style type=\"text/css\">
#+HTML_HEAD:  ol { list-style-type: lower-alpha; }
#+HTML_HEAD:  li { margin: 1em 0; }
#+HTML_HEAD: </style>

#+title: 23sp
#+property: header-args :exports none

* 01
a) invalid: 1, 3, 4, 5

b) ~a = 3~ \\\\
   ~b = 3*4 = 12.0~ \\\\
   ~c = (3 > 12 || 3 == 3) * 2 = (0 || 1) * 2 = 2~ \\\\
   ~d = 3/2 = 1.0~

   #+name: 01.b
   #+begin_src C -n :includes <stdio.h>
   int a = (float)15/4;
   float b = a++*a--;
   int c = (a > b || a == 1 + 2) * 2;
   float d = a/c;
   printf(\"%d, %.2f, %d, %.2f\\n\", a, b, c, d);
   #+end_src

   #+RESULTS: 01.b
   | 3 | 12.0 | 2 | 1.0 |

c) ~b = 10~:
   #+begin_example
   SPL
   Spring
   #+end_example
   \\\\

   ~b = 2~:
   #+begin_example
   Spring
   #+end_example
   \\\\

   #+name: 01.c
   #+begin_src C -n :results output
   #include <stdio.h>
   int main() {
       int b = 2;

       if (b >= 10) {
           printf(\"SPL\\n\");
           b--;
       }

       if (b < 10) {
           printf(\"Spring\\n\");
           b--;
       }
       else if ((b >= 3) || (b < 10))
           printf(\"2023\\n\");
       else if (b >= 3 && b < 10)
           printf(\"Happy Coding!\");
       else
           printf(\"Huh!\");
       return 0;
   }
   #+end_src

   #+RESULTS: 01.c
   : Spring

* 02
a) rewrite using switch

   #+begin_src C -n :exports code
   int n, a;
   scanf(“%d %d”, &n, &a);

   switch (n > a) {
   case 1:
       switch (n-a > 5) {
       case 1:
           printf(“Difference is greater than 5\\n”);
           break;
       default:
           printf(“Difference is less than or equal to 5\\n”);
           break;
       }
       break;
   default:
       printf(“Please give a larger value of n\\n”);
       break;
   }
   #+end_src
   \\\\

b) Trace table
   
   #+name: 02.b
   #+begin_src C -n :results output table :exports results
   #include <stdio.h>
   int main() {
       int j = 8, result = 5, i = 0, x = 2, y = 2;
       printf(\"i j result x y j>3\\n\");
       for (; j > 3; j--) {
           printf(\"%d %d %d %d %d %d\\n\", i, j, result, x, y, j > 3);
           i =  (j * result) / x;
           result += y;
           x += (y-2);
           y++;
       } 
       printf(\"%d %d %d %d %d %d\\n\", i, j, result, x, y, j > 3);
   }
   #+end_src

   #+RESULTS: 02.b
   |  i | j | result |  x | y | j>3 |
   |  0 | 8 |      5 |  2 | 2 |   1 |
   | 20 | 7 |      7 |  2 | 3 |   1 |
   | 24 | 6 |     10 |  3 | 4 |   1 |
   | 20 | 5 |     14 |  5 | 5 |   1 |
   | 14 | 4 |     19 |  8 | 6 |   1 |
   |  9 | 3 |     25 | 12 | 7 |   0 |

* 03
a) rewrite with do-while

   #+name: 03.a
   #+begin_src C -n :exports code
   #include <stdio.h>

   int main() {
       int weeks = 2, days_in_week = 7;

       int i = 1;
       do {
           printf(\"Week: %d\\n\", i);

           int j = 1;
           do {
               if (i % 2 == 0) {
                   if (j % 2 == 0)
                       printf(\"Day: %d\\n\", j);
               }
               else{
                   if (j % 2 != 0)
                       printf(\"Day: %d\\n\", j);
               }
               j++;
           } while (j <= days_in_week);
           i++;
       } while (i <= weeks);

       return 0;
   }
   #+end_src
   \\\\

b) WAP

   #+name: 03.b
   #+begin_src C -n :exports code :results output
   #include <stdio.h>

   int main() {
       int n; scanf(\"%d\", &n);

       for (int i = 1; i <= n; i++) {
           for (int j = 0; j < (n-i)*2; j++)
               putchar(' ');

           int start = 2*i;
           for (int j = 0; j < i; j++) {
               printf(\"%d \", start);
               start += 2;
           }

           start -= 4;
           for (int j = 0; j < i-1; j++) {
               printf(\"%d \", start);
               start -= 2;
           }

           putchar('\\n');
       }
   }
   #+end_src

   \\\\

* 04
a) WAP

   #+name: 04.a
   #+begin_src C -n :exports code
   #include <stdio.h>

   int main() {
       float sum_cg3 = 0;
       int count_cg3 = 0;

       float max = 0;
       float min = 5;
       int count_max = 0;

       float tmp;
       for (int i = 0; i < 100; i++) {
           scanf(\"%d\", &tmp);

           if (tmp > 3) {
               sum_cg3 += tmp;
               count_cg3++;
           }
        
           if (tmp > max) {
               max = tmp;
               count_max = 1;
           } else if (tmp == max)
               count_max++;

           if (tmp < min) min = tmp;
       }

       float avg_cg3 = sum_cg3 / count_cg3;

       printf(\"Average: %.2f\\n\", avg_cg3);
       printf(\"Higest: %.2f and count: %d\\n\", max, count_max);
       printf(\"Lowest: %.2f\\n\", min);
   }
   #+end_src
   \\\\

* 05
a) Initializing ~arr~ with zeros and ~k~ with 15.

   In the first loop, the values at index 1, 3 and 5 are changed.

   ~arr[1] = 16 - 2 = 14~ \\\\
   ~k      = 16 + 1 = 17~

   ~arr[3] = 18 - 2 = 16~ \\\\
   ~k      = 18 + 1 = 19~ \\\\

   ~arr[5] = 20 - 2 = 18~ \\\\
   ~k      = 20 + 1 = 21~

   ~arr = {0, 14, 0, 16, 0, 18, 0, 0, 0, 0}~ \\\\
   ~k   = 21~

   After initializing ~i~ with 0, the second loop modifies the elements
   at indices from 6 to 10.

   ~arr[9] = 1~ \\\\
   ~arr[8] = 2~ \\\\
   ~arr[7] = 3~ \\\\
   ~arr[6] = 4~ \\\\

   ~arr[9] = 5~ \\\\
   ~arr[8] = 6~ \\\\
   ~arr[7] = 7~ \\\\

   ~arr[9] = 8~ \\\\
   ~arr[8] = 9~ \\\\

   ~arr[9] = 10~ \\\\

   ~arr = {0, 14, 0, 16, 0, 18, 4, 7, 9, 10}~ \\\\
   ~c   = 10~

   The third loop modifies the even indices e.g. 0, 2, 4.

   ~arr[0] = 22~ \\\\
   ~arr[2] = 23~ \\\\
   ~arr[4] = 24~ \\\\
   ~arr[6] = 25~ \\\\
   ~arr[8] = 26~ \\\\

   ~arr = {22, 14, 23, 16, 24, 18, 25, 7, 26, 10}~ \\\\
   ~k   = 26~

   #+name: 05.a
   #+begin_src C -n
   #include <stdio.h>

   int main() {
       int arr[10] = {0};
       int k = 15;
       for (int i = 1; i < 6; i += 2) {
           arr[i] = ++k - 2;
           k++;
       }

       printf(\"arr = {\")
           for (int i = 0; i < 9; i++)
               printf(\"%d, \", arr[i]);
       printf(\"%d}\\n\", arr[9]);
       printf(\"k   = %d\\n\", k);

       int c = 0;
       for (int i = 6; i < 10; i++) {
           for (int j = 10; j >= i; j--) {
               arr[j] = ++c;
           }
       }

       printf(\"arr = {\")
           for (int i = 0; i < 9; i++)
               printf(\"%d, \", arr[i]);
       printf(\"%d}\\n\", arr[9]);
       printf(\"c   = %d\\n\", c);

       for (int i = 0; i < 10; i++) {
           if (i % 2 == 0) {
               arr[i] = ++k;
           }
       }

       printf(\"arr = {\")
           for (int i = 0; i < 9; i++)
               printf(\"%d, \", arr[i]);
       printf(\"%d}\\n\", arr[9]);
       printf(\"k   = %d\\n\", k);
   }
   #+end_src

b) 2d array ~arr~

   | 1 |  2 |  3 |  5 |  8 |
   | 2 |  3 |  5 |  8 | 13 |
   | 3 |  5 |  8 | 13 | 21 |
   | 5 |  8 | 13 | 21 | 34 |
   | 8 | 13 | 21 | 34 | 55 |

   #+name: 05.b
   #+begin_src C -n :results output table
   #include <stdio.h>

   int main() {
       int arr[100][100], i, j, t1 = 0, t2 = 1, t3, x, y, z;

       for (i = 0; i < 5; i++) {
           x = t1, y = t2, z = t1 + t2;
           for (j = 0; j < 5; j++) {
               t3 = t1 + t2;
               arr[j][i] = t3;
               t1 = t2;
               t2 = t3;
           }
           t1 = y;
           t2 = z;
       }

       for (int i = 0; i < 5; i++) {
           for (int j = 0; j < 5; j++)
               printf(\"%d \", arr[i][j]);
           putchar('\\n');
       }
   }
   #+end_src" . 1) ((marker . 3992) . -178) ((marker . 4048) . -178) (t 26160 52102 643000 569000)) (emacs-undo-equiv-table (1 . -1) (-25 . -27) (-34 . -36) (-2 . -4) (-40 . -42) (-42 . -44) (-47 . -49) (-8 . -10) (-44 . -46) (2 . 4) (-64 . -66) (-66 . -68) (-72 . -74) (-75 . -77) (-82 . -84) (-84 . -86) (-99 . -101) (-97 . -99) (-93 . -95) (-104 . -106) (-86 . -88) (-102 . -104)))