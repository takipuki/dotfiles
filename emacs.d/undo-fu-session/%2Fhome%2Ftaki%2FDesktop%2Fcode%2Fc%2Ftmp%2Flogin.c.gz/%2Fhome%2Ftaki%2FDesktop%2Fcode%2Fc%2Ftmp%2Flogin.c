((buffer-size . 12231) (buffer-checksum . "ca93790db7e5f1f730b02df423ff0bcb5c674f44"))
((emacs-buffer-undo-list nil ("
" . -119) ((marker* . 119) . 1) ((marker . 119) . -1) ((marker . 119) . -1) ((marker . 119) . -1) ((marker . 119) . -1) ((marker) . -1) nil ("typedef struct
{
    char username[10000];
    char password[10000];
    char OpenMode; // Changed from array to single char
} User;
" . 119) ((marker . 119) . -125) ((marker . 119) . -125) ((marker . 119) . -132) ((marker . 119) . -15) ((marker . 119) . -15) ((marker . 119) . -15) ((marker . 119) . -125) ((marker . 119) . -125) ((marker . 119) . -125) ((marker . 119) . -125) ((marker . 119) . -125) ((marker . 119) . -125) ((marker . 119) . -125) ((marker . 119) . -125) ((marker . 119) . -125) ((marker) . -133) nil (133 . 134) (" " . 133) nil (133 . 134) ("
" . -133) ((marker . 119) . -1) ((marker . 119) . -1) ((marker . 119) . -1) ((marker . 119) . -1) ((marker . 119) . -1) 119 nil ("
" . -135) ((marker) . -1) 134 (t 26158 19322 43697 376000) nil (15 . 18) (11 . 15) (10 . 12) ("\"" . -10) (10 . 11) ("\"" . -10) ((marker . 119) . -1) ("<" . -11) ((marker . 119) . -1) ("#" . -12) ((marker . 119) . -1) ("h" . -13) ((marker . 119) . -1) ("e" . -14) ((marker . 119) . -1) ("a" . -15) ((marker . 119) . -1) ("d" . -16) ((marker . 119) . -1) ("e" . -17) ((marker . 119) . -1) ("r" . -18) ((marker . 119) . -1) ("#" . -19) ((marker . 119) . -1) (">" . -20) ((marker . 119) . -1) ("\"" . -21) ((marker . 59) . -1) ((marker . 119) . -1) 22 (2 . 22) ("inc" . -2) ((marker . 59) . -3) ((marker . 11) . -3) ((marker . 11) . -3) ((marker . 119) . -3) 5 (2 . 5) (1 . 2) (1 . 2) (t 26158 19168 164184 290000) nil ("// #include \"login.h\"
" . 1) ((marker . 119) . -22) ((marker . 119) . -22) ((marker . 119) . -22) ((marker . 119) . -22) ((marker . 119) . -21) nil ("#include \"../../../../msys64/ucrt64/include/ncursesw/curses.h\"
#include \"../../../../msys64/ucrt64/include/ncursesw/ncurses.h\"
" . 23) ((marker . 59) . -62) ((marker . 119) . -63) ((marker . 119) . -63) ((marker . 119) . -126) (t 26158 19060 895127 229000)) (emacs-pending-undo-list ("
" . -135) ((marker) . -1) 134 (t 26158 19322 43697 376000) nil (15 . 18) (11 . 15) (10 . 12) ("\"" . -10) (10 . 11) ("\"" . -10) ((marker . 119) . -1) ("<" . -11) ((marker . 119) . -1) ("#" . -12) ((marker . 119) . -1) ("h" . -13) ((marker . 119) . -1) ("e" . -14) ((marker . 119) . -1) ("a" . -15) ((marker . 119) . -1) ("d" . -16) ((marker . 119) . -1) ("e" . -17) ((marker . 119) . -1) ("r" . -18) ((marker . 119) . -1) ("#" . -19) ((marker . 119) . -1) (">" . -20) ((marker . 119) . -1) ("\"" . -21) ((marker . 59) . -1) ((marker . 119) . -1) 22 (2 . 22) ("inc" . -2) ((marker . 59) . -3) ((marker . 11) . -3) ((marker . 11) . -3) ((marker . 119) . -3) 5 (2 . 5) (1 . 2) (1 . 2) (t 26158 19168 164184 290000) nil ("// #include \"login.h\"
" . 1) ((marker . 119) . -22) ((marker . 119) . -22) ((marker . 119) . -22) ((marker . 119) . -22) ((marker . 119) . -21) nil ("#include \"../../../../msys64/ucrt64/include/ncursesw/curses.h\"
#include \"../../../../msys64/ucrt64/include/ncursesw/ncurses.h\"
" . 23) ((marker . 59) . -62) ((marker . 119) . -63) ((marker . 119) . -63) ((marker . 119) . -126) (t 26158 19060 895127 229000)) (emacs-undo-equiv-table (3 . -1)))