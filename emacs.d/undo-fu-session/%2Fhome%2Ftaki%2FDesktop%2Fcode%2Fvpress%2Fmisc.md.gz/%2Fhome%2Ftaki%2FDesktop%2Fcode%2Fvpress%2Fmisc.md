((buffer-size . 2652) (buffer-checksum . "10d58ce1ed12027dad39dfbc30de6f167d3e7b87"))
((emacs-buffer-undo-list nil (65 . 66) ("," . 65) ((marker) . -1) nil (64 . 68) ("28" . 64) ((marker . 65) . -1) ((marker . 65) . -1) 65 (t 26160 38721 400531 179000) nil ("}" . -66) (66 . 67) ("}" . -66) (64 . 67) (63 . 65) (t 26160 38652 960520 370000) nil (3 . 4) nil (2 . 3) nil 2 nil ("=============
" . 16) ((marker . 65) . -13) ((marker . 18) . -14) ((marker . 18) . -14) ((marker . 18) . -14) ((marker . 18) . -14) (t 26160 38637 309751 680000) nil (16 . 30) nil ("#" . 2) ((marker . 65) . -1) nil (" " . 3) (t 26160 38632 316172 761000) nil (3 . 4) nil (2 . 3) nil 2 nil ("=============
" . 16) ((marker . 65) . -13) ((marker . 18) . -14) ((marker . 18) . -14) ((marker . 18) . -14) ((marker . 18) . -14) (t 26160 38621 832323 298000) nil (2001 . 2002) nil 2001 nil (1199 . 1200) nil 1199 nil (1050 . 1051) nil 1050 nil (744 . 745) nil 744 nil (31 . 32) (t 26160 38537 748156 187000) nil 31 nil (64 . 74) ("i" . -64) ((marker . 65) . -1) 65 (61 . 65) (t 26160 38392 100801 958000) nil (1124 . 1125) ("+" . 1124) (t 26160 38245 510455 645000) nil (1035 . 1036) ("*" . 1035) nil (1030 . 1033) (1030 . 1031) ("#+end_src
" . 1030) ((marker . 65) . -9) ((marker . 65) . -1) 1031 nil ("*" . 1190) (1191 . 1192) 1190 ("*" . 1189) (1190 . 1191) 1189 nil (1202 . 1206) (1202 . 1203) ("#+begin_src C -n
" . 1202) ((marker . 65) . -16) ((marker . 65) . -2) 1204 nil (1997 . 2000) (1997 . 1998) ("#+end_src
" . 1997) ((marker . 65) . -9) ((marker . 65) . -1) 1998 nil ("*" . 2009) (2010 . 2011) 2009 ("*" . 2008) (2009 . 2010) 2008 nil ("#+begin_src C -n
" . 2021) ((marker . 65) . -16) ((marker . 65) . -3) 2024 nil (2041 . 2042) nil (2038 . 2042) 2040 nil (2673 . 2676) nil (2673 . 2674) ("#+end_src
" . 2673) ((marker . 65) . -9) nil ("
" . -57) nil ("
" . 749) ((marker . 65) . -1) nil (749 . 750) 731 nil (731 . 732) ("*" . 731) nil ("#+begin_src C -n
" . 755) ((marker . 65) . -16) ((marker . 65) . -3) 758 nil (753 . 754) nil (nil rear-nonsticky nil 749 . 750) ("
" . -753) (749 . 754) 731 nil ("#+end_src
" . 730) ((marker . 65) . -9) ((marker . 65) . -2) 732 nil ("c" . 729) nil (nil rear-nonsticky nil 725 . 726) ("
" . -730) (725 . 731) 724 nil (56 . 57) 34 nil (60 . 61) (57 . 60) ("#+begin_src C -n" . 57) ((marker . 65) . -15) nil (31 . 32) ("*" . 31) (t 26160 38075 89506 503000) nil ("
" . 29) ("-------------" . 30) nil (30 . 43) (29 . 30) (t 26160 38075 89506 503000) 16 nil ("
" . 29) ((marker . 65) . -1) ("---------------" . 30) ((marker . 65) . -12) (43 . 45) nil ("-" . -43) ((marker . 65) . -1) ("-" . -44) ((marker . 65) . -1) 45 (30 . 45) (29 . 30) (t 26160 38075 89506 503000) 16 nil ("
" . 29) ((marker . 65) . -1) nil (29 . 30) (t 26160 38075 89506 503000) 16 nil ("
" . 29) ((marker) . -1) (" ---------" . 30) ((marker) . -9) nil (30 . 40) (29 . 30) 16 nil ("
" . 29) ((marker) . -1) (" " . 30) nil (30 . 31) (29 . 30) 16 nil ("
" . 29) ((marker) . -1) ("==" . 30) ((marker) . -1) nil (30 . 32) (29 . 30) 16 nil ("
" . 29) ((marker) . -1) (" ===" . 30) ((marker) . -3) nil (30 . 34) (29 . 30) 16 nil (16 . 29) (15 . 16) 2 nil (" " . 2) ((marker* . 4) . 1) nil ("#+TITLE:" . 2) ((marker . 1995) . -7) ((marker . 2) . -7) ((marker . 65) . -7) ((marker) . -7) 9 nil ("#+SETUPFILE: setup.org
#+OPTIONS: toc:t
#+HTML_HEAD: <style>
#+HTML_HEAD: #text-table-of-contents li {
#+HTML_HEAD:     display: list-item;
#+HTML_HEAD:     margin-right: 1em;
#+HTML_HEAD: }
#+HTML_HEAD: #text-table-of-contents li li {
#+HTML_HEAD:     display: list-item;
#+HTML_HEAD:     margin-right: 1em;
#+HTML_HEAD: }
#+HTML_HEAD: </style>
" . 1) ((marker . 1995) . -324) ((marker . 2) . -324) ((marker) . -324) ((marker . 65) . -345) 325 (t 26160 37876 570641 79000)) (emacs-pending-undo-list) (emacs-undo-equiv-table (59 . 61) (57 . 59) (53 . 55) (39 . 41) (61 . 63) (55 . 57) (8 . 15) (51 . 53) (10 . 12) (63 . 65) (9 . 14)))