((buffer-size . 1018) (buffer-checksum . "93084c835ceb0092432be25f90af109bcb6a8f9c"))
((emacs-buffer-undo-list nil (632 . 633) (626 . 632) ("len" . -626) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 29) . -3) 629 (622 . 629) ("a" . -622) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 29) . -1) ("r" . -623) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 29) . -1) ("r" . -624) ((marker . 29) . -1) ("." . -625) ((marker . 29) . -1) 626 (622 . 626) nil (138 . 146) nil 145 nil (112 . 120) nil 120 nil (604 . 606) ("+" . -604) ((marker . 29) . -1) ("=" . -605) ((marker . 29) . -1) (" " . -606) ((marker . 29) . -1) 607 (603 . 607) (597 . 603) ("leng" . -597) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 29) . -4) 601 (597 . 601) ("p" . -597) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 29) . -1) ("r" . -598) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 29) . -1) ("i" . -599) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 29) . -1) 600 (597 . 600) (580 . 597) 579 nil ("                " . 580) ("
" . -580) 553 nil ("            " . -612) ((marker . 29) . -12) 624 (611 . 624) 610 nil (581 . 597) (580 . 594) (579 . 581) (578 . 579) (")" . -577) (577 . 578) (")" . -577) (577 . 578) (576 . 578) (" " . -576) ((marker . 29) . -1) ("(" . -577) ((marker . 29) . -1) (")" . -578) ((marker . 29) . -1) 579 (")" . -578) (578 . 579) (")" . -578) (578 . 579) (577 . 579) (576 . 577) nil ("public " . 565) ((marker . 1) . -7) ((marker . 595) . -6) ((marker . 1) . -7) nil (572 . 583) ("SetIt" . -572) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 29) . -5) 577 (565 . 577) (553 . 565) ("            " . 552) ((marker . 29) . -12) (564 . 565) (551 . 564) 550 nil (550 . 551) (" " . -550) ((marker . 29) . -1) ("=" . -551) ((marker . 29) . -1) (" " . -552) ((marker . 29) . -1) 553 (550 . 553) (548 . 550) ("t" . -548) ((marker . 29) . -1) ("h" . -549) ((marker . 29) . -1) (" " . -550) ((marker . 29) . -1) 551 (542 . 551) ("t" . -542) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 29) . -1) 543 (540 . 543) (527 . 540) 509 nil ("
            " . 527) ((marker . 1) . -13) ((marker . 1) . -13) ((marker . 29) . -13) ("int" . 540) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 29) . -2) nil (540 . 543) (527 . 540) 509 nil ("                " . 566) ((marker . 1) . -16) ((marker . 1) . -16) ("
" . -566) 543 nil ("i" . -583) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 29) . -1) ("f" . -584) ((marker . 29) . -1) 585 (583 . 585) (567 . 583) (566 . 580) (565 . 567) (564 . 565) nil (547 . 555) nil (")" . -555) (555 . 556) (")" . -555) (555 . 556) (554 . 556) (550 . 554) ("n" . -550) ((marker . 29) . -1) ("e" . -551) ((marker . 29) . -1) ("x" . -552) ((marker . 29) . -1) ("t" . -553) ((marker . 29) . -1) 554 (540 . 554) ("i" . -540) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 29) . -1) 541 (540 . 541) (527 . 540) 493 nil ("s" . -488) ((marker . 29) . -1) 489 (488 . 489) nil (615 . 616) (")" . -614) (614 . 615) (")" . -614) (614 . 615) (613 . 615) ("<" . -613) ((marker . 29) . -1) ("T" . -614) ((marker . 29) . -1) (">" . -615) ((marker . 29) . -1) 616 (613 . 616) (602 . 613) ("Set" . -602) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 29) . -3) 605 (602 . 605) (591 . 602) (579 . 591) (578 . 588) (577 . 579) (576 . 577) (")" . -575) (575 . 576) (")" . -575) (575 . 576) (574 . 576) nil (554 . 565) ("Set" . -554) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 29) . -3) 557 (554 . 557) ("Iterator" . 554) ((marker . 595) . -7) ((marker . 29) . -5) 559 nil (559 . 562) ("i" . 559) nil (559 . 560) ("tor" . 559) ((marker . 595) . -2) nil ("            " . 527) ("
" . -527) 525 nil (525 . 526) (517 . 525) ("Ite" . -517) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 29) . -3) 520 (516 . 520) (506 . 516) ("imp" . -506) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 29) . -3) 509 (506 . 509) nil (508 . 520) (507 . 517) (506 . 508) (498 . 506) (480 . 498) (472 . 480) ("        " . 471) ((marker . 29) . -8) (479 . 480) (470 . 479) 469 nil (487 . 496) nil (480 . 495) (472 . 480) ("        " . 471) ((marker . 29) . -8) (479 . 480) (470 . 479) 469 nil (54 . 55) (45 . 54) (41 . 45) ("uti" . -41) ((marker . 29) . -3) 44 (29 . 44) (28 . 29) 25 nil ("impe" . 75) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 29) . -4) (78 . 79) ("le" . 78) ((marker . 29) . -2) (75 . 80) ("implements" . 75) ((marker . 29) . -10) (" " . 85) ((marker . 29) . -1) ("Iter" . 86) ((marker . 29) . -3) nil (86 . 90) (85 . 86) (75 . 85) ("imple" . -75) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 29) . -5) 80 (78 . 80) ("e" . -78) ((marker . 29) . -1) 79 (75 . 79) nil ("    " . -50) ((marker . 29) . -4) 54 (49 . 54) (t 26073 52648 416637 13000) 30) (emacs-pending-undo-list (304 . 305) ("<" . 304) (t 26074 6920 75838 378000) nil (400 . 401) ("+" . 400) nil (367 . 368) ("+" . 367) (t 26074 6917 619065 953000) nil (299 . 300) ("+" . 299) (t 26074 6894 274727 652000) nil (706 . 707) (705 . 706) (700 . 705) 699 nil (449 . 450) (448 . 449) (443 . 448) 443 nil ("
" . 44) ((marker . 20) . -1) ((marker . 20) . -1) ("/" . 45) ((marker . 20) . -1) ((marker . 20) . -1) ("*" . 46) nil ("
" . 780) ((marker . 817) . -1) ((marker . 817) . -1) ("*" . 781) ((marker . 817) . -1) ((marker . 817) . -1) ("/" . 782) nil ("
" . 43) ((marker . 20) . -1) ((marker . 20) . -1) ((marker . 177) . -1) ((marker . 421) . -1) ((marker . 20) . -1) ((marker . 20) . -1) ((marker . 20) . -1) ((marker . 29) . -1) ("
" . 44) ((marker . 20) . -1) ((marker . 20) . -1) ((marker . 177) . -1) ((marker . 421) . -1) ((marker . 20) . -1) ((marker . 20) . -1) ((marker . 20) . -1) ((marker . 29) . -1) ("#include <stdio.h>


int main() {

    int a_n; scanf(\"%d\", &a_n);

    int a[a_n];

    for (int i = 0; i < a_n; i++) scanf(\"%d\", a+i);


    int b_n; scanf(\"%d\", &b_n);

    int b[b_n];

    for (int i = 0; i < b_n; i++) scanf(\"%d\", b+i);


    int intrsctn[(a_n < b_n) ? a_n : b_n];

    int intrsctn_n = 0;


    for (int i = 0; i < a_n; i++)

        for (int j = 0; j < b_n; j++)

            if (a[i] == b[j])

                intrsctn[intrsctn_n++] = b[j];


    if (!intrsctn_n)

        printf(\"Empty set\");

    else

        for (int i = 0; i < intrsctn_n; i++) printf(\"%d \", intrsctn[i]);

    putchar('\\n');

}" . 45) ((marker . 20) . -18) ((marker . 421) . -18) ((marker . 20) . -84) ((marker . 20) . -84) (nil rear-nonsticky t 668 . 669) nil (45 . 64) nil (45 . 46) nil ("
" . 1389) (t 26074 6800 970710 82000) nil (1389 . 1390) 312 nil ("
" . 45) nil ("#include <stdio.h>
" . 45) ((marker . 20) . -18) ((marker . 421) . -18) nil (nil rear-nonsticky nil 668 . 669) (nil fontified nil 67 . 669) (nil fontified nil 64 . 67) (nil fontified nil 46 . 64) (nil fontified nil 45 . 46) (45 . 669) (44 . 45) (43 . 44) 41 nil ("
" . 43) ((marker . 20) . -1) ((marker . 20) . -1) ((marker . 177) . -1) ((marker . 421) . -1) ((marker . 20) . -1) ((marker . 20) . -1) ((marker . 20) . -1) ((marker . 20) . -1) ((marker . 20) . -1) ((marker . 1) . -1) ((marker . 29) . -1) ("
" . 44) ((marker . 20) . -1) ((marker . 20) . -1) ((marker . 177) . -1) ((marker . 421) . -1) ((marker . 20) . -1) ((marker . 20) . -1) ((marker . 20) . -1) ((marker . 20) . -1) ((marker . 20) . -1) ((marker . 1) . -1) ((marker . 29) . -1) ("#include <stdio.h>


int main() {

    int a[50];

    int a_n; scanf(\"%d\", &a_n);

    for (int i = 0; i < a_n; i++) scanf(\"%d\", a+i);   


    int b[50];

    int b_n; scanf(\"%d\", &b_n);

    for (int i = 0; i < b_n; i++) scanf(\"%d\", b+i);   


    int max = (a_n > b_n) ? a_n : b_n;

    for (int i = 0; i < max; i++) {

        int tmp = a[i];

        a[i] = b[i];

        b[i] = tmp;

    }


    printf(\"Array A: \");

    for (int i = 0; i < b_n; i++)

        printf(\"%d \", a[i]);

    putchar('\\n');


    printf(\"Array B: \");

    for (int i = 0; i < a_n; i++)

        printf(\"%d \", b[i]);

    putchar('\\n');

}" . 45) ((marker . 20) . -18) ((marker . 421) . -18) ((marker . 20) . -392) ((marker . 20) . -623) ((marker . 20) . -623) ((marker . 20) . -392) (nil rear-nonsticky t 668 . 669) nil (45 . 64) nil (45 . 46) nil (44 . 45) nil ("
" . 1388) (t 26074 6739 438059 717000) nil (1388 . 1389) 44 nil ("
" . -44) ((marker . 20) . -1) ((marker . 20) . -1) ((marker . 177) . -1) ((marker . 421) . -1) ((marker . 20) . -1) ((marker . 1) . -1) nil ("
" . -45) nil ("#include <stdio.h>
" . 45) ((marker . 20) . -18) ((marker . 421) . -18) nil (nil rear-nonsticky nil 668 . 669) (nil fontified nil 67 . 669) (nil fontified nil 64 . 67) (nil fontified nil 46 . 64) (nil fontified nil 45 . 46) (45 . 669) (44 . 45) (43 . 44) 41 nil (782 . 783) (781 . 782) (780 . 781) 780 nil (46 . 47) (45 . 46) (44 . 45) 44 nil ("
" . 1) ((marker* . 518) . 1) ("/" . 1) ("*" . 2) nil (2 . 3) (1 . 2) (1 . 2) nil (38 . 39) ("0" . 38) nil (36 . 37) ("0" . 36) nil (28 . 29) ("2" . 28) nil (26 . 27) ("1" . 26) nil (37 . 39) ("0" . -37) ((marker . 29) . -1) 38 (36 . 38) (35 . 36) (" " . -35) ((marker . 29) . -1) 36 (26 . 36) ("1" . -26) ((marker . 29) . -1) (" " . -27) ((marker . 29) . -1) 28 (26 . 28) ("1" . -26) ((marker . 29) . -1) (" " . -27) ((marker . 29) . -1) ("2" . -28) ((marker . 29) . -1) (" " . -29) ((marker . 29) . -1) 30 (26 . 30) (25 . 26) (24 . 25) (" " . -24) ((marker . 29) . -1) (" " . -25) ((marker . 29) . -1) 26 (23 . 26) 22 nil (26 . 27) (24 . 25) ("  " . 24) ((marker . 29) . -2) (26 . 27) (23 . 26) (22 . 23) (21 . 22) (20 . 21) (nil face (rainbow-delimiters-depth-1-face font-lock-string-face) 19 . 20) (nil c-in-sws t 19 . 20) (nil fontified t 19 . 20) (19 . 20) (t 26074 6488 123892 584000) 16 nil (", sorted = 0" . 49) ((marker . 421) . -11) nil (733 . 734) nil ("    " . -682) ((marker . 29) . -4) 686 (681 . 686) 676 nil ("    " . -431) ((marker . 29) . -4) 435 (430 . 435) 425 nil ("    " . -188) ((marker . 29) . -4) 192 (187 . 192) 160 nil ("    " . -159) ((marker . 29) . -4) 163 (158 . 163) 131 nil ("    " . -98) ((marker . 29) . -4) 102 (97 . 102) 84 nil (nil face (rainbow-delimiters-depth-1-face font-lock-string-face) 19 . 20) (nil fontified t 19 . 20) (nil c-in-sws t 19 . 20) (19 . 20) (t 26074 6431 141433 573000) 1 nil (9 . 738) ("<stdio.h>
int main(){
    int n,x,y,sorted=0;
    scanf(\"%d\",&n);
   int a[n];
   for(int i=0;i<n;i++)
   scanf(\"%d\",&a[i]);
   scanf(\"%d %d\",&x,&y);
   for(int i=0;i<=x;i++){
      for(int j=1;j<=x-i;j++){
        if(a[j+1]<a[j]){
         int temp=a[j];
         a[j+1]=a[j];
         a[j+1]=temp;
        }
      }
   }  
   for(int j=y;j<n;j++){
       for(int i=y+1;i<n-(j-y);i++){
          if(a[i+1]>a[i]){
           int temp=a[i];
           a[i+1]=a[i];
           a[i+1]=temp;
         }
       }
   }
   for(int i=0;i<n;i++)
   printf(\"%d\",a[i]);
" . 9) ((marker . 20) . -9) (t 26074 6427 144594 383000) nil (587 . 588) 1 nil (nil rear-nonsticky nil 586 . 587) (nil fontified nil 20 . 587) (nil fontified nil 19 . 20) (nil fontified nil 2 . 19) (nil fontified nil 1 . 2) (1 . 587) nil ("#include <stdio.h>

int main() {
    int n; scanf(\"%d\", &n);

    int arr[n];
    for (int i = 0; i < n; i++)
        scanf(\"%d\", arr+i);

    int a, b; scanf(\"%d%d\", &a, &b);

    // sorting indices 0 -> a
    for (int i = 0; i <= a; i++) {
        for (int j = 1; j <= a-i; j++) {
            if (arr[j-1] > arr[j]) {
                int tmp = arr[j-1];
                arr[j-1] = arr[j];
                arr[j] = tmp;
            }
        }
    }

    // sorting indices b -> (n-1)
    int count_sorted = 0;
    for (int i = b; i < n; i++) {
        for (int j = b+1; j < n - count_sorted; j++) {
            if (arr[j-1] < arr[j]) {
                int tmp = arr[j-1];
                arr[j-1] = arr[j];
                arr[j] = tmp;
            }
        }
        count_sorted++;
    }

    for (int i = 0; i < n; i++)
        printf(\"%d \", arr[i]);
    putchar('\\n');
}
" . 1) ((marker . 20) . -18) ((marker . 421) . -877) ((marker . 20) . -320) ((marker . 1) . -876) ((marker . 1) . -878) ((marker . 1) . -878) ((marker* . 518) . 286) ((marker . 1) . -878) ((marker . 1) . -876) ((marker . 1) . -878) ((marker . 1) . -876) ((marker . 427) . -349) ((marker* . 453) . 528) ((marker . 452) . -349) ((marker . 427) . -349) ((marker . 1) . -878) ((marker . 1) . -876) ((marker . 1) . -507) ((marker . 1) . -507) ((marker . 1) . -507) ((marker . 1) . -507) ((marker . 1) . -507) ((marker . 1) . -507) ((marker . 1) . -507) ((marker . 1) . -507) ((marker . 1) . -507) ((marker . 1) . -507) ((marker . 1) . -507) ((marker . 1) . -507) ((marker . 1) . -507) ((marker . 1) . -507) ((marker . 1) . -507) ((marker . 1) . -507) ((marker . 1) . -507) ((marker . 1) . -507) ((marker . 1) . -507) ((marker . 1) . -507) ((marker . 1) . -507) ((marker . 1) . -507) ((marker . 1) . -507) ((marker . 1) . -507) ((marker . 1) . -507) ((marker . 1) . -507) ((marker . 1) . -507) ((marker . 1) . -507) ((marker . 1) . -507) ((marker . 1) . -507) ((marker . 1) . -507) ((marker . 1) . -507) ((marker . 1) . -507) ((marker . 1) . -507) ((marker . 1) . -507) ((marker . 1) . -507) ((marker . 1) . -507) ((marker . 1) . -507) ((marker . 1) . -507) ((marker . 1) . -507) ((marker . 1) . -507) ((marker . 1) . -507) ((marker . 1) . -507) ((marker . 1) . -507) ((marker . 1) . -507) ((marker . 1) . -507) ((marker . 1) . -507) ((marker . 1) . -507) ((marker . 1) . -20) ((marker . 20) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -580) ((marker . 1) . -600) ((marker . 1) . -600) ((marker . 1) . -600) ((marker . 1) . -600) ((marker . 1) . -600) ((marker . 1) . -600) ((marker . 1) . -600) ((marker . 1) . -600) ((marker . 1) . -600) ((marker . 1) . -600) ((marker . 1) . -600) ((marker . 1) . -600) ((marker . 1) . -600) ((marker . 1) . -600) ((marker . 1) . -600) ((marker . 1) . -600) ((marker . 1) . -600) ((marker . 1) . -600) ((marker . 1) . -600) ((marker . 1) . -600) ((marker . 1) . -600) ((marker . 1) . -600) ((marker . 1) . -600) ((marker . 1) . -600) ((marker . 1) . -600) ((marker . 1) . -600) ((marker . 1) . -600) ((marker . 1) . -600) ((marker . 1) . -600) ((marker . 1) . -600) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -637) ((marker . 1) . -349) ((marker . 1) . -320) ((marker . 1) . -580) nil ("            " . -772) ((marker . 29) . -12) (764 . 772) 776 nil (nil rear-nonsticky nil 775 . 776) ("
" . -791) (763 . 792) 762 nil ("            count_sorted++;
" . 754) ((marker . 421) . -27) ((marker . 29) . -16) 770 (t 26074 6080 216257 289000) nil ("              // of the array" . 709) ((marker . 421) . -28) nil ("             // elements at the end" . 674) ((marker . 421) . -34) ((marker) . -35) ((marker) . -35) nil ("            " . 638) ((marker . 421) . -11) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -12) ((marker . 1) . -11) ((marker . 1) . -11) ((marker . 1) . -11) ((marker . 1) . -11) ((marker . 1) . -11) ((marker . 1) . -11) ((marker . 1) . -11) ((marker . 1) . -11) ((marker . 1) . -11) ((marker . 1) . -11) ((marker . 1) . -11) ((marker . 1) . -11) ((marker . 1) . -11) ((marker . 1) . -11) ((marker . 1) . -11) ((marker . 1) . -11) ((marker . 1) . -11) ((marker . 1) . -11) ((marker . 1) . -11) ((marker . 1) . -11) ((marker . 1) . -11) ((marker . 1) . -10) ((marker . 1) . -10) ((marker . 1) . -10) ((marker . 1) . -10) ((marker . 1) . -10) ((marker . 1) . -10) ((marker . 1) . -10) ((marker . 1) . -10) ((marker . 1) . -10) ((marker . 1) . -10) ((marker . 1) . -9) ((marker . 1) . -9) ((marker . 1) . -9) ((marker . 1) . -9) ((marker . 1) . -9) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -8) ((marker . 1) . -7) ((marker . 1) . -7) ((marker . 1) . -7) ((marker . 1) . -7) ((marker . 1) . -7) ((marker . 1) . -6) ((marker . 1) . -6) ((marker . 1) . -6) ((marker . 1) . -6) ((marker . 1) . -6) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker) . -12) ((marker) . -12) nil ("// of already sorted" . 650) ((marker . 421) . -19) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -5) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker) . -20) ((marker) . -20) nil (" // (i-b) is the number" . 601) ((marker . 421) . -22) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker) . -23) ((marker) . -23) nil (581 . 593) ("coun" . -581) ((marker . 20) . -4) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 29) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker) . -4) 585 (581 . 585) ("(i-b)" . 581) ((marker . 421) . -4) ((marker . 20) . -4) ((marker . 452) . -4) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker) . -5) ((marker) . -5) nil (581 . 586) nil ("(i-b)" . 581) ((marker . 421) . -4) ((marker . 20) . -4) ((marker . 427) . -4) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -2) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -3) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 29) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker . 1) . -4) ((marker) . -4) ((marker) . -5) ((marker) . -5) 585 nil (892 . 893) (890 . 892) (" " . -890) ((marker . 29) . -1) ("=" . -891) ((marker . 29) . -1) (" " . -892) ((marker . 29) . -1) 893 (890 . 893) (878 . 890) ("count_sor" . -878) ((marker . 20) . -9) ((marker . 1) . -9) ((marker . 29) . -9) 887 (878 . 887) (865 . 878) 864 nil ("
            " . 865) ((marker . 29) . -13) (866 . 878) nil ("            " . -866) ((marker . 29) . -12) 878 (865 . 878) 864 nil (511 . 512) (508 . 511) (" " . -508) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 29) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker) . -1) ("=" . -509) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 29) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker) . -1) 510 (495 . 510) ("sorted" . -495) ((marker . 29) . -6) 501 (491 . 501) (486 . 491) 462 nil ("

" . -938) (940 . 941) ("

" . -855) (857 . 858) ("

" . -451) (453 . 454) (nil fontified t 445 . 446) ("

" . -445) (447 . 448) (nil fontified t 435 . 436) ("

" . -435) (437 . 438) (nil fontified t 421 . 422) ("

" . -421) (423 . 424) (nil fontified t 391 . 392) ("

" . -391) (393 . 394) (nil fontified t 356 . 357) ("

" . -356) (358 . 359) (nil fontified t 320 . 321) ("

" . -320) (322 . 323) (nil fontified t 283 . 284) ("

" . -283) (285 . 286) (nil fontified t 242 . 243) ("

" . -242) (244 . 245) (nil fontified t 207 . 208) (nil c-in-sws t 207 . 208) ("

" . -207) (209 . 210) ("

" . -176) (178 . 179) ("

" . -138) (140 . 141) (nil fontified t 110 . 111) ("

" . -110) (112 . 113) (nil fontified t 78 . 79) ("

" . -78) (80 . 81) ("

" . -61) (63 . 64) ("

" . -19) (21 . 22) nil ("
" . 22) ((marker . 1) . -1) (19 . 22) (nil c-is-sws nil 19 . 20) ("
" . 63) (60 . 63) ("
" . 78) (76 . 78) ("
" . 110) (108 . 110) ("
" . 139) (136 . 139) ("
" . 176) (173 . 176) ("
" . 205) (203 . 205) ("
" . 240) (238 . 240) ("
" . 281) (279 . 281) ("
" . 318) (316 . 318) ("
" . 354) (352 . 354) ("
" . 389) (387 . 389) ("
" . 419) (417 . 419) ("
" . 433) (431 . 433) ("
" . 443) (441 . 443) ("
" . 450) (447 . 450) ("
" . 853) (850 . 853) ("
" . 934) ((marker . 20) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 1) . -1) (932 . 934) nil ("

" . -932) (934 . 935) ("


" . -850) (853 . 854) (nil fontified t 447 . 448) ("


" . -447) (450 . 451) (nil fontified t 441 . 442) ("

" . -441) (443 . 444) (nil fontified t 431 . 432) ("

" . -431) (433 . 434) (nil fontified t 417 . 418) ("

" . -417) (419 . 420) (nil fontified t 387 . 388) ("

" . -387) (389 . 390) (nil fontified t 352 . 353) ("

" . -352) (354 . 355) (nil fontified t 316 . 317) ("

" . -316) (318 . 319) (nil fontified t 279 . 280) ("

" . -279) (281 . 282) (nil fontified t 238 . 239) ("

" . -238) (240 . 241) (nil fontified t 203 . 204) (nil c-in-sws t 203 . 204) ("

" . -203) (205 . 206) (nil fontified t 173 . 174) ("


" . -173) (176 . 177) (nil fontified t 136 . 137) ("


" . -136) (139 . 140) (nil fontified t 108 . 109) ("

" . -108) (110 . 111) (nil fontified t 76 . 77) ("

" . -76) (78 . 79) (nil fontified t 60 . 61) ("


" . -60) (63 . 64) (nil fontified t 19 . 20) (nil c-is-sws t 19 . 20) ("


" . -19) (22 . 23) nil ("
" . 22) ((marker . 1) . -1) (19 . 22) (nil c-is-sws nil 19 . 20) ("
" . 63) (60 . 63) ("
" . 78) (76 . 78) ("
" . 110) (108 . 110) ("
" . 139) (136 . 139) ("
" . 176) (173 . 176) ("
" . 205) (203 . 205) ("
" . 240) (238 . 240) ("
" . 281) (279 . 281) ("
" . 318) (316 . 318) ("
" . 354) (352 . 354) ("
" . 389) (387 . 389) ("
" . 419) (417 . 419) ("
" . 433) (431 . 433) ("
" . 443) (441 . 443) ("
" . 450) (447 . 450) ("
" . 853) (850 . 853) ("
" . 934) ((marker . 20) . -1) ((marker . 1) . -1) ((marker . 1) . -1) (932 . 934) nil (nil fontified t 932 . 933) ("

" . -932) (934 . 935) (nil fontified t 850 . 851) ("


" . -850) (853 . 854) (nil fontified t 447 . 448) ("


" . -447) (450 . 451) (nil fontified t 441 . 442) ("

" . -441) (443 . 444) (nil fontified t 431 . 432) ("

" . -431) (433 . 434) (nil fontified t 417 . 418) ("

" . -417) (419 . 420) (nil fontified t 387 . 388) ("

" . -387) (389 . 390) (nil fontified t 352 . 353) ("

" . -352) (354 . 355) (nil fontified t 316 . 317) ("

" . -316) (318 . 319) (nil fontified t 279 . 280) ("

" . -279) (281 . 282) (nil fontified t 238 . 239) ("

" . -238) (240 . 241) (nil fontified t 203 . 204) (nil c-in-sws t 203 . 204) ("

" . -203) (205 . 206) (nil fontified t 173 . 174) ("


" . -173) (176 . 177) (nil fontified t 136 . 137) ("


" . -136) (139 . 140) (nil fontified t 108 . 109) ("

" . -108) (110 . 111) (nil fontified t 76 . 77) ("

" . -76) (78 . 79) (nil fontified t 60 . 61) ("


" . -60) (63 . 64) (nil fontified t 19 . 20) (nil c-is-sws t 19 . 20) ("


" . -19) (22 . 23) nil ("
" . 22) ((marker* . 518) . 1) (19 . 22) (nil fontified nil 19 . 20) (nil c-is-sws nil 19 . 20) ("
" . 33) (32 . 33) ("
" . 63) (60 . 63) ("
" . 78) (76 . 78) ("
" . 110) (108 . 110) ("
" . 139) (136 . 139) ("
" . 176) (173 . 176) (nil fontified nil 173 . 174) ("
" . 205) (203 . 205) (nil fontified nil 203 . 204) ("
" . 240) (238 . 240) ("
" . 281) (279 . 281) ("
" . 318) (316 . 318) ("
" . 354) (352 . 354) ("
" . 389) (387 . 389) ("
" . 419) (417 . 419) ("
" . 433) (431 . 433) ("
" . 443) (441 . 443) ("
" . 450) (447 . 450) (nil fontified nil 447 . 448) ("
" . 482) (481 . 482) ("
" . 516) (515 . 516) ("
" . 587) (586 . 587) ("
" . 656) (655 . 656) ("
" . 727) (726 . 727) ("
" . 791) (790 . 791) ("
" . 821) (820 . 821) ("
" . 835) (834 . 835) ("
" . 845) (844 . 845) ("
" . 853) (850 . 853) (nil fontified nil 850 . 851) ("
" . 883) (882 . 883) ("
" . 914) (913 . 914) ("
" . 934) ((marker . 1) . -1) (932 . 934) (nil fontified nil 932 . 933) ("
" . 935) ((marker . 20) . -1) ((marker . 1) . -1) ((marker . 1) . -1) (934 . 935) (nil fontified t 934 . 935) nil ("
" . 19) (nil fontified nil 19 . 20) (nil face nil 19 . 20) nil (nil face (rainbow-delimiters-depth-1-face font-lock-string-face) 19 . 20) (nil c-in-sws t 19 . 20) (nil fontified t 19 . 20) (19 . 20) 1 nil (nil fontified nil 934 . 935) ("
" . -934) (935 . 936) (nil fontified t 932 . 933) ("

" . -932) (934 . 935) (nil fontified nil 913 . 914) ("
" . -913) (914 . 915) (nil fontified nil 882 . 883) ("
" . -882) (883 . 884) (nil fontified t 850 . 851) ("


" . -850) (853 . 854) (nil fontified nil 844 . 845) ("
" . -844) (845 . 846) (nil fontified nil 834 . 835) ("
" . -834) (835 . 836) (nil fontified nil 820 . 821) ("
" . -820) (821 . 822) (nil c-in-sws t 790 . 791) (nil fontified nil 790 . 791) (nil face font-lock-comment-face 790 . 791) ("
" . -790) (791 . 792) (nil c-in-sws t 726 . 727) (nil fontified nil 726 . 727) (nil face font-lock-comment-face 726 . 727) ("
" . -726) (727 . 728) (nil c-in-sws t 655 . 656) (nil fontified nil 655 . 656) (nil face font-lock-comment-face 655 . 656) ("
" . -655) (656 . 657) (nil c-in-sws t 586 . 587) (nil fontified nil 586 . 587) (nil face font-lock-comment-face 586 . 587) ("
" . -586) (587 . 588) (nil fontified nil 515 . 516) ("
" . -515) (516 . 517) (nil c-in-sws t 481 . 482) (nil fontified nil 481 . 482) (nil face font-lock-comment-face 481 . 482) ("
" . -481) (482 . 483) (nil fontified t 447 . 448) ("


" . -447) (450 . 451) ("

" . -441) (443 . 444) ("

" . -431) (433 . 434) ("

" . -417) (419 . 420) ("

" . -387) (389 . 390) ("

" . -352) (354 . 355) ("

" . -316) (318 . 319) ("

" . -279) (281 . 282) ("

" . -238) (240 . 241) (nil c-in-sws t 203 . 204) (nil fontified t 203 . 204) ("

" . -203) (205 . 206) (nil fontified t 173 . 174) ("


" . -173) (176 . 177) ("


" . -136) (139 . 140) ("

" . -108) (110 . 111) ("

" . -76) (78 . 79) ("


" . -60) (63 . 64) (nil fontified nil 32 . 33) ("
" . -32) (33 . 34) (nil c-is-sws t 19 . 20) (nil fontified t 19 . 20) ("


" . -19) (22 . 23) nil ("
" . -34) 33 nil ("
" . -937) 936 nil ("
" . -906) 883 nil ("
" . -866) 865 nil ("
" . -856) 855 nil ("
" . -842) 841 nil ("
" . -812) 811 nil ("
" . -748) 745 nil ("
" . -677) 676 nil ("
" . -608) 570 nil ("
" . -503) 502 nil ("
" . -538) 515 (t 26074 5677 758967 113000) nil (970 . 971) 1 nil (nil rear-nonsticky nil 969 . 970) (nil fontified nil 23 . 970) (nil fontified nil 20 . 23) (nil fontified nil 2 . 20) (nil fontified nil 1 . 2) (1 . 970) nil ("#include <stdio.h>

int main() {
    int result; scanf(\"%d\", &result);

    for (int i = 1; ; i++) {
        char op; scanf(\" %c\", &op);
        if (op == 'e') break;
        int number; scanf(\"%d\", &number);

        switch (op) {
        case '+':
            result += number;
            break;
        case '-':
            result -= number;
            break;
        case '*':
            result *= number;
            break;
        case '/':
            result /= number;
            break;
        case '%':
            result %= number;
            break;
        }
        printf(\"Result-%02d = %d\\n\", i, result);
    }

    printf(\"End Result = %d\\n\", result);
}
" . 1) ((marker . 1) . -633) ((marker* . 817) . 3) ((marker . 1) . -633) ((marker . 1) . -633) ((marker . 1) . -633) ((marker . 1) . -665) ((marker . 1) . -665) ((marker . 1) . -633) ((marker . 1) . -633) ((marker . 1) . -633) ((marker . 1) . -633) ((marker . 1) . -633) ((marker . 1) . -633) ((marker . 1) . -633) ((marker . 1) . -447) ((marker . 1) . -447) ((marker . 1) . -447) ((marker . 1) . -447) ((marker . 1) . -447) ((marker . 1) . -447) ((marker . 1) . -447) ((marker . 1) . -447) ((marker . 1) . -447) ((marker . 1) . -447) ((marker . 1) . -447) ((marker . 1) . -447) ((marker . 1) . -447) ((marker . 1) . -447) ((marker . 1) . -665) ((marker . 1) . -665) ((marker . 1) . -633) ((marker . 1) . -633) ((marker . 1) . -633) ((marker . 1) . -665) ((marker . 1) . -665) ((marker . 1) . -633) ((marker . 1) . -633) ((marker . 1) . -633) ((marker . 1) . -633) ((marker . 1) . -633) ((marker . 1) . -633) ((marker . 1) . -633) ((marker . 1) . -616) ((marker . 1) . -92) ((marker . 1) . -665) ((marker . 1) . -71) ((marker . 1) . -71) ((marker . 1) . -71) ((marker . 1) . -71) ((marker . 1) . -71) ((marker . 1) . -71) ((marker . 1) . -71) ((marker . 1) . -71) ((marker . 1) . -71) ((marker . 1) . -71) ((marker . 1) . -71) ((marker . 1) . -71) ((marker . 1) . -71) ((marker . 1) . -71) ((marker . 1) . -665) ((marker . 1) . -633) ((marker . 1) . -665) ((marker . 1) . -665) ((marker . 1) . -633) ((marker . 1) . -633) ((marker . 1) . -633) ((marker . 1) . -633) ((marker . 1) . -633) ((marker . 1) . -633) ((marker . 1) . -633) ((marker . 1) . -665) ((marker . 1) . -665) ((marker . 1) . -633) ((marker . 1) . -633) ((marker . 1) . -616) ((marker . 1) . -92) ((marker . 1) . -71) ((marker . 1) . -71) ((marker . 1) . -71) ((marker . 1) . -71) ((marker . 1) . -71) ((marker . 1) . -71) ((marker . 1) . -71) ((marker . 1) . -633) ((marker . 1) . -92) ((marker* . 817) . 3) ((marker . 1) . -633) ((marker . 1) . -616) ((marker . 1) . -92) ((marker* . 817) . 3) ((marker . 1) . -71) ((marker . 1) . -71) ((marker . 1) . -71) ((marker . 1) . -71) ((marker . 1) . -633) ((marker . 1) . -92) ((marker* . 817) . 3) ((marker . 1) . -633) ((marker . 1) . -633) ((marker . 1) . -665) ((marker . 1) . -665) ((marker . 1) . -633) ((marker . 1) . -633) ((marker . 1) . -665) ((marker . 1) . -665) ((marker . 1) . -633) ((marker . 1) . -633) ((marker . 1) . -633) ((marker . 1) . -665) ((marker . 1) . -665) ((marker . 1) . -633) ((marker . 1) . -665) ((marker . 1) . -665) ((marker . 1) . -633) ((marker . 1) . -665) ((marker . 1) . -665) ((marker . 1) . -633) ((marker . 1) . -665) ((marker . 1) . -665) ((marker . 1) . -633) ((marker . 1) . -633) ((marker . 1) . -633) ((marker . 1) . -633) ((marker . 1) . -633) ((marker . 1) . -633) ((marker . 1) . -633) ((marker . 1) . -633) ((marker . 1) . -633) ((marker . 1) . -633) ((marker . 1) . -633) ((marker . 1) . -633) ((marker . 1) . -633) ((marker . 1) . -633) ((marker . 1) . -633) ((marker . 20) . -18) ((marker . 1) . -19) ((marker . 421) . -675) (t 26073 46717 711246 528000) nil (673 . 674) (")" . -672) (672 . 673) (")" . -672) (672 . 673) (666 . 672) ("res" . -666) 669 (665 . 669) (664 . 665) ("\"" . -663) (663 . 664) ("\"" . -663) (661 . 664) ("e" . -661) ("f" . -662) ("i" . -663) ("n" . -664) ("e" . -665) 666 (660 . 666) ("d" . -660) 661 (656 . 661) (650 . 656) ("Res" . -650) 653 (646 . 653) (645 . 647) ("\"" . -645) (645 . 646) (644 . 646) (638 . 644) (634 . 638) ("    " . 633) (637 . 638) (632 . 637) (t 26073 46666 645827 450000) 631 nil ("1" . 93) nil (158 . 159) (157 . 159) ("'" . -157) (153 . 158) (t 26073 46655 852052 782000) nil (93 . 94) (t 26073 46640 951443 242000) nil (610 . 611) (609 . 610) (608 . 609) nil (90 . 91) ("0" . 90) nil (100 . 101) (99 . 100) nil (")" . -98) (98 . 99) (")" . -98) (98 . 99) (94 . 98) (93 . 94) (92 . 93) (91 . 92) (89 . 91) ("0" . -89) (" " . -90) 91 (82 . 91) (81 . 83) (77 . 81) (73 . 77) (73 . 74) ("    while (1) {
" . 73) 84 (t 26073 46610 336856 481000) nil (146 . 147) (140 . 146) (")" . -139) (139 . 140) (")" . -139) (139 . 140) (" " . -139) 140 (137 . 140) (136 . 138) (133 . 136) (124 . 133) 104 nil ("   " . 104) nil (104 . 107) nil ("        " . -167) 175 (166 . 175) 149 nil (534 . 542) ("    " . 534) (524 . 532) ("    " . 524) (505 . 517) ("        " . 505) (475 . 487) ("        " . 475) (457 . 465) ("    " . 457) (438 . 450) ("        " . 438) (408 . 420) ("        " . 408) (390 . 398) ("    " . 390) (371 . 383) ("        " . 371) (341 . 353) ("        " . 341) (323 . 331) ("    " . 323) (304 . 316) ("        " . 304) (274 . 286) ("        " . 274) (256 . 264) ("    " . 256) (237 . 249) ("        " . 237) (207 . 219) ("        " . 207) (189 . 197) ("    " . 189) (167 . 175) ("    " . 167) (125 . 133) ("    " . 125) (89 . 97) ("    " . 89) 504 nil (504 . 505) ("}" . -504) (504 . 505) (499 . 504) 472 nil ("}" . 473) (nil rear-nonsticky t 473 . 474) nil (nil rear-nonsticky nil 473 . 474) (nil fontified nil 473 . 474) (473 . 474) 472 nil ("}" . 88) nil (87 . 89) (86 . 87) (")" . -85) (85 . 86) (")" . -85) (85 . 86) (84 . 85) (83 . 85) (82 . 83) (" x" . -82) (82 . 84) ("while" . 82) (77 . 82) 82 (81 . 82) ("t" . -81) ("e" . -82) 83 (77 . 83) (72 . 77) 72 nil (482 . 483) (")" . -481) (481 . 482) (")" . -481) (481 . 482) (475 . 481) ("res" . -475) 478 (475 . 478) (474 . 475) (473 . 474) ("\"" . -472) (472 . 473) ("\"" . -472) (462 . 473) ("2" . -462) ("d" . -463) 464 (462 . 464) ("2" . -462) ("d" . -463) 464 (463 . 464) (460 . 463) (454 . 460) ("Res" . -454) 457 (454 . 457) ("%" . -454) 455 (454 . 455) (453 . 455) ("\"" . -453) (453 . 454) (452 . 454) (446 . 452) (441 . 446) 440 nil (410 . 411) ("+" . 410) nil (391 . 392) ("+" . 391) nil (391 . 392) ("5" . 391) nil (391 . 392) ("+" . 391) nil (355 . 356) ("+" . 355) nil (336 . 337) ("+" . 336) nil (300 . 301) ("+" . 300) nil (281 . 282) ("+" . 281) nil (245 . 246) ("+" . 245) nil (226 . 227) ("+" . 226) nil (nil rear-nonsticky nil 219 . 220) ("
" . -435) (215 . 436) 213 nil (214 . 215) (209 . 214) (200 . 209) (199 . 200) (189 . 199) (183 . 189) ("resu" . -183) 187 (183 . 187) (174 . 183) (161 . 165) ("        " . 161) (177 . 178) ("'" . -176) (176 . 177) ("'" . -176) (175 . 177) (174 . 176) ("'" . -174) (169 . 175) (161 . 169) (160 . 166) (159 . 161) (158 . 159) (")" . -157) (157 . 158) (")" . -157) (157 . 158) (155 . 157) (154 . 156) (153 . 154) ("(" . -153) (")" . 154) (153 . 155) (147 . 153) (142 . 147) 141 nil (141 . 142) (")" . -140) (140 . 141) (")" . -140) (140 . 141) (132 . 140) (131 . 132) ("\"" . -130) (130 . 131) ("\"" . -130) (128 . 131) (127 . 129) ("\"" . -127) (127 . 128) ("%" . -127) 128 (127 . 128) (126 . 128) (120 . 126) (119 . 120) (109 . 119) (104 . 109) (103 . 104) (")" . -102) (102 . 103) (")" . -102) (102 . 103) (100 . 102) (98 . 100) (97 . 98) nil (93 . 94) nil (93 . 95) (92 . 94) ("\"" . -92) (92 . 93) (91 . 93) (86 . 91) ("c" . -86) ("a" . -87) 88 (85 . 88) (84 . 85) (77 . 84) ("i" . -77) ("n" . -78) ("t" . -79) 80 (77 . 80) (73 . 77) (73 . 74) nil ("    " . 73) (77 . 78) ("}" . -77) (77 . 78) (73 . 77) ("    " . 72) (76 . 77) (72 . 76) (72 . 73) ("
    int sum = 0;
    int current_number = 0;
    for (int i = 1; i <= n; i++) {
        current_number = current_number*10 + 2*i;
        printf(\"%d \", current_number);
        sum += current_number;
    }

    printf(\"= %d\\n\", sum);
}
" . 72) nil (63 . 69) ("n" . 63) nil (42 . 48) ("n" . 42) (t 26073 46303 697533 785000) nil (nil rear-nonsticky nil 200 . 201) ("
" . -231) (192 . 232) 191 nil (191 . 192) (190 . 191) (189 . 190) (188 . 189) ("i" . -188) 189 (183 . 189) (182 . 183) (168 . 182) ("curr" . -168) 172 (166 . 172) (" " . -166) ("=" . -167) (" " . -168) 169 (166 . 169) ("+" . -166) ("=" . -167) (" " . -168) 169 nil (165 . 169) (151 . 165) ("curr" . -151) 155 (151 . 155) (142 . 151) 116 nil ("        " . -84) (80 . 84) 88 nil (80 . 112) 88 nil ("        int current_number = 0;
" . 115) 123 nil ("        printf(\"%d \", current_number);
" . 147) 155 nil ("        // from 2 to even    vvv
        for (int j = 2; j <= 2*i; j += 2) {
            current_number = current_number*10 + j; // 0*10 + 2 = 2
                                                    // 2*10 + 4 = 24
                                                    // 24*10 + 6 = 246
        }
" . 147) 155 (t 26073 46017 872149 818000) nil (430 . 431) nil (424 . 425) ("4" . 424) nil (417 . 418) nil (nil rear-nonsticky nil 412 . 413) ("
" . -429) (360 . 430) 359 nil (349 . 360) (348 . 349) (346 . 348) (344 . 346) (325 . 344) (304 . 325) (291 . 304) 289 nil (" -> 2*10 + 4" . 291) nil (291 . 292) nil (288 . 291) nil (293 . 299) (292 . 293) (287 . 292) (" " . -287) 288 (287 . 288) nil (286 . 287) ("j" . -286) 287 (281 . 287) (280 . 281) (278 . 280) (276 . 278) (275 . 276) (t 26073 45929 891698 271000) nil (388 . 389) (")" . -387) (387 . 388) (")" . -387) (387 . 388) (383 . 387) (382 . 383) ("\"" . -381) (381 . 382) ("\"" . -381) (378 . 382) nil (" " . 305) nil ("+" . 305) nil (377 . 379) nil (325 . 326) (")" . -324) (324 . 325) (")" . -324) (324 . 325) (310 . 324) ("cur" . -310) 313 (309 . 313) (308 . 309) ("\"" . -307) (307 . 308) ("\"" . -307) (302 . 308) (301 . 303) ("\"" . -301) (301 . 302) (300 . 302) (294 . 300) (285 . 294) 284 nil (336 . 337) (335 . 337) ("\"" . -335) (335 . 336) (334 . 336) (328 . 334) (324 . 328) ("    " . 323) (327 . 328) (322 . 327) 317 nil (315 . 316) (301 . 315) ("curr" . -301) 305 (294 . 305) (285 . 294) 284 nil ("
            " . 275) (276 . 288) nil ("            " . -276) 288 (275 . 288) 274 nil (274 . 275) (268 . 274) (267 . 268) (253 . 267) ("curr" . -253) 257 (251 . 257) ("+" . -251) ("=" . -252) (" " . -253) ("c" . -254) ("u" . -255) ("r" . -256) ("r" . -257) ("e" . -258) ("n" . -259) ("t" . -260) ("_" . -261) ("n" . -262) ("u" . -263) ("m" . -264) ("b" . -265) ("e" . -266) ("r" . -267) 268) (emacs-undo-equiv-table (-7 . -29) (-8 . -28) (-9 . -17) (-10 . -16) (-11 . -15) (-12 . -14) (30 . 32) (-69 . -73) (-58 . -60) (22 . 24) (-67 . -69) (-70 . -72) (-18 . -26) (-65 . -67) (-20 . -24) (-17 . -27) (-29 . -31) (-61 . -63) (-21 . -23) (13 . 15) (-19 . -25)))