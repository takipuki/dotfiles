((buffer-size . 58) (buffer-checksum . "59ce68067ec1134246319055026303be3c04341f"))
((emacs-buffer-undo-list nil (46 . 53) ("T" . -46) ((marker . 34) . -1) ((marker . 34) . -1) ((marker . 34) . -1) (" " . -47) ((marker . 34) . -1) 48 (46 . 48) ("Hello world!\\n" . 46) ((marker . 58) . -13) ((marker . 34) . -3) ((marker . 34) . -3) ((marker . 46) . -3) ((marker . 34) . -3) ((marker . 34) . -3) 49 nil (62 . 63) nil (58 . 60) ("|" . -58) ((marker . 34) . -1) ((marker . 34) . -1) ((marker . 34) . -1) ("n" . -59) ((marker . 34) . -1) ((marker . 34) . -1) ((marker . 34) . -1) 60 (57 . 60) ("\\" . -57) ((marker . 34) . -1) 58 (46 . 58) (45 . 47) ("\"" . -45) (45 . 46) (44 . 46) (38 . 44) (33 . 38) (t 26058 23780 375319 610000) 21 nil ("
    " . 33) ((marker . 34) . -5) ((marker . 34) . -5) ((marker . 34) . -4) ("p" . 38) ((marker . 34) . -1) ((marker . 34) . -1) (38 . 39) nil ("p" . -38) ((marker . 34) . -1) ((marker . 34) . -1) ((marker . 34) . -1) 39 (38 . 39) (33 . 38) (t 26058 23780 375319 610000) 21 nil ("    char app[6] = \"Apple\";
    char a[100];
    scanf(\"%s\", a);
    for (int i = 0; i < 5; i++) {
        if (a[i] != app[i]) {
            printf(\"Gravity\\n\");
            return 0;
        }
    }
    printf(\"Space\\n\");

" . 34) ((marker . 58) . -222) ((marker* . 53) . 102) ((marker . 34) . -44) ((marker . 34) . -20) ((marker . 57) . -44) ((marker . 34) . -20) ((marker . 34) . -64) 98 (t 26058 20360 400325 711000) nil (93 . 94) ("&" . 93) (t 26058 20345 173067 324000) nil (153 . 155) nil (146 . 147) ("5" . 146) nil (72 . 75) ("5" . 72) nil (47 . 48) ("5" . 47) nil (59 . 60) ("\"" . -58) (58 . 59) ("\"" . -58) (53 . 59) (52 . 54) ("\"" . -52) (49 . 53) ("]" . -48) (48 . 49) ("]" . -48) (47 . 49) (38 . 48) (33 . 38) 32 nil ("    return 0;
" . 226) ((marker . 58) . -13) ((marker . 34) . -1) 227 nil (202 . 206) (196 . 200) (186 . 194) ("    " . 186) (164 . 176) ("        " . 164) (131 . 143) ("        " . 131) (103 . 111) ("    " . 103) (69 . 73) ("   " . 69) (49 . 53) ("     " . 49) (34 . 38) ("     " . 34) 1 nil ("    // Write C code here
" . 34) ((marker . 58) . -24) nil ("#include <stdio.h>

int main() {

}
" . 1) ((marker . 19) . -18) ((marker . 58) . -35) ((marker . 34) . -36) ((marker . 34) . -33) ((marker . 34) . -34) 35 nil (nil rear-nonsticky nil 278 . 279) (nil fontified nil 58 . 279) (nil fontified nil 56 . 58) (nil fontified nil 38 . 56) (nil fontified nil 37 . 38) (37 . 279) nil (36 . 37) 35) (emacs-pending-undo-list ("    char app[6] = \"Apple\";
    char a[100];
    scanf(\"%s\", a);
    for (int i = 0; i < 5; i++) {
        if (a[i] != app[i]) {
            printf(\"Gravity\\n\");
            return 0;
        }
    }
    printf(\"Space\\n\");

" . 34) ((marker . 58) . -222) ((marker* . 53) . 102) ((marker . 34) . -44) ((marker . 34) . -20) ((marker . 57) . -44) ((marker . 34) . -20) ((marker . 34) . -64) 98 (t 26058 20360 400325 711000) nil (93 . 94) ("&" . 93) (t 26058 20345 173067 324000) nil (153 . 155) nil (146 . 147) ("5" . 146) nil (72 . 75) ("5" . 72) nil (47 . 48) ("5" . 47) nil (59 . 60) ("\"" . -58) (58 . 59) ("\"" . -58) (53 . 59) (52 . 54) ("\"" . -52) (49 . 53) ("]" . -48) (48 . 49) ("]" . -48) (47 . 49) (38 . 48) (33 . 38) 32 nil ("    return 0;
" . 226) ((marker . 58) . -13) ((marker . 34) . -1) 227 nil (202 . 206) (196 . 200) (186 . 194) ("    " . 186) (164 . 176) ("        " . 164) (131 . 143) ("        " . 131) (103 . 111) ("    " . 103) (69 . 73) ("   " . 69) (49 . 53) ("     " . 49) (34 . 38) ("     " . 34) 1 nil ("    // Write C code here
" . 34) ((marker . 58) . -24) nil ("#include <stdio.h>

int main() {

}
" . 1) ((marker . 19) . -18) ((marker . 58) . -35) ((marker . 34) . -36) ((marker . 34) . -33) ((marker . 34) . -34) 35 nil (nil rear-nonsticky nil 278 . 279) (nil fontified nil 58 . 279) (nil fontified nil 56 . 58) (nil fontified nil 38 . 56) (nil fontified nil 37 . 38) (37 . 279) nil (36 . 37) 35) (emacs-undo-equiv-table (4 . -1)))