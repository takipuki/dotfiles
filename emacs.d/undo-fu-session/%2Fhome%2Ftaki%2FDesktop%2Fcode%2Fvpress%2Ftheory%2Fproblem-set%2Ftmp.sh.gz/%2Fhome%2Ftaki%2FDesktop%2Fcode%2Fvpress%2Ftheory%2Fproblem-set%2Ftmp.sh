((buffer-size . 283) (buffer-checksum . "37da6e6453eca1385c4c17f5633da7889ea2b13b"))
((emacs-buffer-undo-list nil (269 . 270) ("|" . 269) ((marker) . -1) nil (275 . 276) ("|" . 275) ((marker) . -1) nil (278 . 281) nil (276 . 277) nil (265 . 268) nil (267 . 273) (266 . 267) ("s" . -266) ((marker . 280) . -1) ((marker . 280) . -1) ((marker . 256) . -1) ("|" . -267) ((marker . 256) . -1) 268 (266 . 268) (265 . 267) ("'" . -265) (258 . 266) (256 . 258) (nil face font-lock-variable-name-face 255 . 256) (nil fontified t 255 . 256) (255 . 256) (t 26160 52688 419464 704000) 230 nil (257 . 258) 225 nil (243 . 244) nil ("  sed -i -E 's|#+TITLE: (.*)|# \\1|' $@
" . 89) ((marker . 269) . -38) ((marker . 256) . -28) 117 nil ("  sed -i -E 's|#+TITLE: (.*)|# \\1' $@
" . 89) ((marker . 269) . -37) ((marker . 256) . -3) 92 nil (nil rear-nonsticky t 330 . 331) (nil fontified t 330 . 331) ("structure.md" . -329) (341 . 343) ("structure.md" . -299) (311 . 313) ("structure.md" . -264) (276 . 278) ("structure.md" . -232) (244 . 246) ("structure.md" . -203) (215 . 217) ("structure.md" . -163) (175 . 177) ("structure.md" . -124) (136 . 138) ("structure.md" . -86) (98 . 100) ("structure.md" . -53) (65 . 67) nil ("  sed -i -E 's/#
" . 9) ((marker . 280) . -17) ((marker . 269) . -16) ((marker . 9) . -17) ((marker . 9) . -17) ((marker . 9) . -17) nil ("  sed -i -E 's|#\\+beg.*|```c:line-numbers|'
" . 26) ((marker* . 281) . 44) ((marker . 280) . -3) ((marker . 269) . -43) ((marker* . 9) . 41) ((marker . 9) . -2) ((marker . 256) . -2) 28 nil ("  sed -i -E 's|#\\+beg.*|```c:line-numbers|
" . 26) ((marker* . 281) . 41) ((marker . 269) . -42) ((marker . 9) . -2) ((marker . 9) . -2) ((marker . 256) . -2) 28 nil (" " . 71) ((marker . 9) . -1) nil (" " . 28) ((marker . 9) . -1) ((marker . 9) . -1) nil (" " . -73) ((marker . 9) . -1) 74 (" " . -29) ((marker . 9) . -1) ((marker . 9) . -1) ((marker . 256) . -1) 30 nil (26 . 30) nil (486 . 488) (441 . 443) (399 . 401) (360 . 362) (310 . 312) (261 . 263) (213 . 215) (170 . 172) (113 . 115) (67 . 71) (9 . 11) nil (" " . 9) nil (" " . 9) nil (" 1085  " . 466) ((marker . 280) . -6) ((marker . 269) . -6) ((marker . 9) . -6) ((marker . 256) . -6) (" 1084  " . 423) (" 1083  " . 383) (" 1082  " . 346) (" 1081  " . 298) (" 1080  " . 251) (" 1079  " . 205) (" 1078  " . 164) (" 1077  " . 109) (" 1076  " . 67) (" 1075  " . 26) ("   1074" . 9) ((marker . 9) . -2) 549 nil (nil rear-nonsticky nil 586 . 587) (nil fontified nil 11 . 587) (11 . 587) 10 nil (9 . 11) ("  " . 9) (9 . 11) (8 . 10) (6 . 9) (")" . -5) (5 . 6) (")" . -5) (5 . 6) (4 . 6) (3 . 4) (" " . -3) ((marker . 256) . -1) 4 (3 . 4) ("o" . -3) ((marker . 280) . -1) ((marker . 280) . -1) ((marker . 256) . -1) ("n" . -4) ((marker . 280) . -1) ((marker . 280) . -1) ((marker . 256) . -1) ("v" . -5) ((marker . 280) . -1) ((marker . 280) . -1) ((marker . 256) . -1) 6 (2 . 6) (1 . 2) (t . -1) 1) (emacs-pending-undo-list ("
" . -5949) 5946 (t 26160 52433 534671 500000) nil (73 . 5950) ("c:line-numbers
#include <stdio.h>

typedef struct {
    char name[20];
    char id[20];
    float cgpa;
} std;

int main() {
    std s;
    scanf(\"%[^\\n]%*c\", s.name);
    scanf(\"%[^\\n]%*c\", s.id);
    scanf(\"%f\", &s.cgpa);

    printf(\"Name: %s\\n\", s.name);
    printf(\"Student ID: %s\\n\", s.id);
    printf(\"CGPA: %.2f\\n\", s.cgpa);
}
```
## 02 
```c:line-numbers
#include <stdio.h>

typedef struct {
    char name[20];
    char id[20];
    float cgpa;
} std;

int main() {
    int n; scanf(\"%d%*c\", &n);
    std s[n];
    for (int i = 0; i < n; i++) {
        scanf(\"%[^\\n]%*c\", s[i].name);
        scanf(\"%[^\\n]%*c\", s[i].id);
        scanf(\"%f%*c\", &s[i].cgpa);
    }

    for (int i = 0; i < n; i++) {
        printf(\"Student %d: %s\\n\", i+1, s[i].name);
        printf(\"Student ID: %s\\n\", s[i].id);
        printf(\"CGPA: %.2f\\n\", s[i].cgpa);
    }
}
```
## 03 
```c:line-numbers
#include <stdio.h>
#include <math.h>

typedef struct {
    int x, y;
} point;

int main() {
    point a, b;
    scanf(\"%d%d\", &a.x, &a.y);
    scanf(\"%d%d\", &b.x, &b.y);
    float dis = sqrt( (a.x-b.x)*(a.x-b.x) + (a.y-b.y)*(a.y-b.y) );
    printf(\"The distance is %.2f unit\\n\", dis);
}
```
## 04 
```c:line-numbers
#include <stdio.h>
#include <math.h>

typedef struct {
    int x, y;
} point;

float dis(point a, point b) {
    return sqrt( (a.x - b.x)*(a.x - b.x) + (a.y - b.y)*(a.y - b.y) );
}

int main() {
    point a, b, c;
    scanf(\"%d%d\", &a.x, &a.y);
    scanf(\"%d%d\", &b.x, &b.y);
    scanf(\"%d%d\", &c.x, &c.y);
    float A = dis(b, c);
    float B = dis(c, a);
    float C = dis(a, b);
    if (A+B <= C || B+C <= A || C+A <= B) {
        puts(\"They are in the same line\");
        return 0;
    }
    float s = (A+B+C) / 2;
    float area = sqrt( s*(s-A)*(s-B)*(s-C) );
    printf(\"The area is %.2f unit\\n\", area);
}
```
## 05 
```c:line-numbers
#include <stdio.h>

typedef struct {
    float real, img;
} complex;

int main() {
    complex c;
    scanf(\"%f%f\", &c.real, &c.img);
    printf(\"%.2f%+.2fi\\n\", c.real, c.img);
}
```
## 06 
```c:line-numbers
#include <stdio.h>
#include <math.h>

typedef struct {
    float real, img;
} complex;

int main() {
    complex c;
    scanf(\"%f%f\", &c.real, &c.img);

    float mod = sqrt( c.real*c.real + c.img*c.img );
    printf(\"Modulus = %.4f\\n\", mod);
    if (c.img*c.real < 0)
        printf(\"Argument = %.4f\\n\", 3.1416+atan(c.img/c.real));
    else
        printf(\"Argument = %.4f\\n\", atan(c.img/c.real));
}
```
## 07 
```c:line-numbers
#include <stdio.h>

typedef struct {
    int real, img;
} complex;

int main() {
    complex a, b;
    scanf(\"%d%d\", &a.real, &a.img);
    scanf(\"%d%d\", &b.real, &b.img);

    printf(\"(%d%+di)+(%d%+di)=%d%+di\\n\",
           a.real, a.img, b.real, b.img,
           a.real+b.real, a.img+b.img);
    
    printf(\"(%d%+di)-(%d%+di)=%d%+di\\n\",
           a.real, a.img, b.real, b.img,
           a.real-b.real, a.img-b.img);
}
```
## 08 
```c:line-numbers
#include <stdio.h>

typedef struct {
    int real, img;
} complex;

int main() {
    complex a, b;
    scanf(\"%d%d\", &a.real, &a.img);
    scanf(\"%d%d\", &b.real, &b.img);

    printf(\"(%d%+di)*(%d%+di)=%d%+di\\n\",
           a.real, a.img, b.real, b.img,
           (a.real*b.real)-(a.img*b.img),
           (a.real*b.img)+(a.img*b.real));
}
```
## 09 
```c:line-numbers
#include <stdio.h>

typedef struct {
    float real, img;
} complex;

complex mul(complex a, complex b) {
    return (complex) {
        (a.real*b.real)-(a.img*b.img),
        (a.real*b.img)+(a.img*b.real)
    };
}

complex conjugate(complex a) {
    return (complex) { a.real, -a.img };
}

complex div(complex a, complex b) {
    complex num = mul(a, conjugate(b));
    complex denom = mul(b, conjugate(b));
    return (complex) {
        num.real/denom.real, num.img/denom.real
    };
}

void print_complex(complex a) {
    printf(\"(%.2f%+.2fi)\", a.real, a.img);
}

int main() {
    complex a, b;
    scanf(\"%f%f\", &a.real, &a.img);
    scanf(\"%f%f\", &b.real, &b.img);

    print_complex(a);
    putchar('/');
    print_complex(b);
    putchar('=');
    print_complex(div(a, b));
    putchar(\\n);
}
```
## 10 
```c:line-numbers
#include <stdio.h>

typedef struct {
    int m, cm;
} length;

int main() {
    length l;
    scanf(\"%d%d\", &l.m, &l.cm);
    printf(\"Length in meter: %.2f\\n\", l.m + (float)l.cm/100);
    printf(\"Length in centimeter: %d\\n\", l.m*100+l.cm);
}
```
## 11 
```c:line-numbers
#include <stdio.h>

typedef struct {
    int m, cm;
} length;

length add(length a, length b) {
    return (length) {
        (a.cm + b.cm >= 100) ? a.m + b.m + 1 : a.m + b.m,
        (a.cm + b.cm >= 100) ? (a.cm+b.cm)%100 : a.cm + b.cm
    };
}

int main() {
    length a, b;
    scanf(\"%d%d\", &a.m, &a.cm);
    scanf(\"%d%d\", &b.m, &b.cm);

    length c = add(a, b);
    printf(\"The sum is %d meter %d centimeter\\n\", c.m, c.cm);
}
```
## 12 
```c:line-numbers
#include <stdio.h>

typedef struct {
    int h, m, s;
} time;

float h(time t) {
    return t.h + (float)t.m/60 + (float)t.s/3600;
}

float m(time t) {
    return t.h*60 + t.m + (float)t.s/60;
}

int s(time t) {
    return t.h*3600 + t.m*60 + t.s;
}

int main() {
    time t;
    scanf(\"%d%d%d\", &t.h, &t.m, &t.s);

    printf(\"Time interval in hour: %.2f\\n\", h(t));
    printf(\"Time interval in minute: %.2f\\n\", m(t));
    printf(\"Time interval in second: %d\\n\", s(t));
}
```
## 13 
```c:line-numbers
#include <stdio.h>

typedef struct {
    int h, m, s;
} time;

time sub(time a, time b) {
    time t = {
        a.h - b.h,
        a.m - b.m,
        a.s - b.s
    };
    if (t.s < 0) {
        t.s += 60;
        t.m -= 1;
    }
    if (t.m < 0) {
        t.m += 60;
        t.h -= 1;
    }
    return t;
}

int main() {
    time a, b;
    scanf(\"%d%d%d\", &a.h, &a.m, &a.s);
    scanf(\"%d%d%d\", &b.h, &b.m, &b.s);

    time c = sub(a, b);
    printf(\"%d %d %d\\n\", c.h, c.m, c.s);
}
```" . 73) ((marker . 1) . -1924) ((marker . 280) . -2068) ((marker . 256) . -2068) (t 26160 52416 303890 289000) nil (63 . 5415) ("* 01 
```c:line-numbers
#include <stdio.h>

typedef struct {
    char name[20];
    char id[20];
    float cgpa;
} std;

int main() {
    std s;
    scanf(\"%[^\\n]%*c\", s.name);
    scanf(\"%[^\\n]%*c\", s.id);
    scanf(\"%f\", &s.cgpa);

    printf(\"Name: %s\\n\", s.name);
    printf(\"Student ID: %s\\n\", s.id);
    printf(\"CGPA: %.2f\\n\", s.cgpa);
}
```
* 02 
```c:line-numbers
#include <stdio.h>

typedef struct {
    char name[20];
    char id[20];
    float cgpa;
} std;

int main() {
    int n; scanf(\"%d%*c\", &n);
    std s[n];
    for (int i = 0; i < n; i++) {
        scanf(\"%[^\\n]%*c\", s[i].name);
        scanf(\"%[^\\n]%*c\", s[i].id);
        scanf(\"%f%*c\", &s[i].cgpa);
    }

    for (int i = 0; i < n; i++) {
        printf(\"Student %d: %s\\n\", i+1, s[i].name);
        printf(\"Student ID: %s\\n\", s[i].id);
        printf(\"CGPA: %.2f\\n\", s[i].cgpa);
    }
}
```
* 03 
```c:line-numbers
#include <stdio.h>
#include <math.h>

typedef struct {
    int x, y;
} point;

int main() {
    point a, b;
    scanf(\"%d%d\", &a.x, &a.y);
    scanf(\"%d%d\", &b.x, &b.y);
    float dis = sqrt( (a.x-b.x)*(a.x-b.x) + (a.y-b.y)*(a.y-b.y) );
    printf(\"The distance is %.2f unit\\n\", dis);
}
```
* 04 
```c:line-numbers
#include <stdio.h>
#include <math.h>

typedef struct {
    int x, y;
} point;

float dis(point a, point b) {
    return sqrt( (a.x - b.x)*(a.x - b.x) + (a.y - b.y)*(a.y - b.y) );
}

int main() {
    point a, b, c;
    scanf(\"%d%d\", &a.x, &a.y);
    scanf(\"%d%d\", &b.x, &b.y);
    scanf(\"%d%d\", &c.x, &c.y);
    float A = dis(b, c);
    float B = dis(c, a);
    float C = dis(a, b);
    if (A+B <= C || B+C <= A || C+A <= B) {
        puts(\"They are in the same line\");
        return 0;
    }
    float s = (A+B+C) / 2;
    float area = sqrt( s*(s-A)*(s-B)*(s-C) );
    printf(\"The area is %.2f unit\\n\", area);
}
```
* 05 
```c:line-numbers
#include <stdio.h>

typedef struct {
    float real, img;
} complex;

int main() {
    complex c;
    scanf(\"%f%f\", &c.real, &c.img);
    printf(\"%.2f%+.2fi\\n\", c.real, c.img);
}
```
* 06 
```c:line-numbers
#include <stdio.h>
#include <math.h>

typedef struct {
    float real, img;
} complex;

int main() {
    complex c;
    scanf(\"%f%f\", &c.real, &c.img);

    float mod = sqrt( c.real*c.real + c.img*c.img );
    printf(\"Modulus = %.4f\\n\", mod);
    if (c.img*c.real < 0)
        printf(\"Argument = %.4f\\n\", 3.1416+atan(c.img/c.real));
    else
        printf(\"Argument = %.4f\\n\", atan(c.img/c.real));
}
```
* 07 
```c:line-numbers
#include <stdio.h>

typedef struct {
    int real, img;
} complex;

int main() {
    complex a, b;
    scanf(\"%d%d\", &a.real, &a.img);
    scanf(\"%d%d\", &b.real, &b.img);

    printf(\"(%d%+di)+(%d%+di)=%d%+di\\n\",
           a.real, a.img, b.real, b.img,
           a.real+b.real, a.img+b.img);
    
    printf(\"(%d%+di)-(%d%+di)=%d%+di\\n\",
           a.real, a.img, b.real, b.img,
           a.real-b.real, a.img-b.img);
}
```
* 08 
```c:line-numbers
#include <stdio.h>

typedef struct {
    int real, img;
} complex;

int main() {
    complex a, b;
    scanf(\"%d%d\", &a.real, &a.img);
    scanf(\"%d%d\", &b.real, &b.img);

    printf(\"(%d%+di)*(%d%+di)=%d%+di\\n\",
           a.real, a.img, b.real, b.img,
           (a.real*b.real)-(a.img*b.img),
           (a.real*b.img)+(a.img*b.real));
}
```
* 09 
```c:line-numbers
#include <stdio.h>

typedef struct {
    float real, img;
} complex;

complex mul(complex a, complex b) {
    return (complex) {
        (a.real*b.real)-(a.img*b.img),
        (a.real*b.img)+(a.img*b.real)
    };
}

complex conjugate(complex a) {
    return (complex) { a.real, -a.img };
}

complex div(complex a, complex b) {
    complex num = mul(a, conjugate(b));
    complex denom = mul(b, conjugate(b));
    return (complex) {
        num.real/denom.real, num.img/denom.real
    };
}

void print_complex(complex a) {
    printf(\"(%.2f%+.2fi)\", a.real, a.img);
}

int main() {
    complex a, b;
    scanf(\"%f%f\", &a.real, &a.img);
    scanf(\"%f%f\", &b.real, &b.img);

    print_complex(a);
    putchar('/');
    print_complex(b);
    putchar('=');
    print_complex(div(a, b));
    putchar(\\n);
}
```
* 10 
```c:line-numbers
#include <stdio.h>

typedef struct {
    int m, cm;
} length;

int main() {
    length l;
    scanf(\"%d%d\", &l.m, &l.cm);
    printf(\"Length in meter: %.2f\\n\", l.m + (float)l.cm/100);
    printf(\"Length in centimeter: %d\\n\", l.m*100+l.cm);
}
```
* 11 
```c:line-numbers
#include <stdio.h>

typedef struct {
    int m, cm;
} length;

length add(length a, length b) {
    return (length) {
        (a.cm + b.cm >= 100) ? a.m + b.m + 1 : a.m + b.m,
        (a.cm + b.cm >= 100) ? (a.cm+b.cm)%100 : a.cm + b.cm
    };
}

int main() {
    length a, b;
    scanf(\"%d%d\", &a.m, &a.cm);
    scanf(\"%d%d\", &b.m, &b.cm);

    length c = add(a, b);
    printf(\"The sum is %d meter %d centimeter\\n\", c.m, c.cm);
}
```
* 12 
```c:line-numbers
#include <stdio.h>

typedef struct {
    int h, m, s;
} time;

float h(time t) {
    return t.h + (float)t.m/60 + (float)t.s/3600;
}

float m(time t) {
    return t.h*60 + t.m + (float)t.s/60;
}

int s(time t) {
    return t.h*3600 + t.m*60 + t.s;
}

int main() {
    time t;
    scanf(\"%d%d%d\", &t.h, &t.m, &t.s);

    printf(\"Time interval in hour: %.2f\\n\", h(t));
    printf(\"Time interval in minute: %.2f\\n\", m(t));
    printf(\"Time interval in second: %d\\n\", s(t));
}
```
*" . 63) (t 26160 52331 720055 287000) nil ("+TITLE:" . 51) (t 26160 52327 286520 931000) nil (414 . 5918) ("#+end_src
* 02 
```c:line-numbers
#include <stdio.h>

typedef struct {
    char name[20];
    char id[20];
    float cgpa;
} std;

int main() {
    int n; scanf(\"%d%*c\", &n);
    std s[n];
    for (int i = 0; i < n; i++) {
        scanf(\"%[^\\n]%*c\", s[i].name);
        scanf(\"%[^\\n]%*c\", s[i].id);
        scanf(\"%f%*c\", &s[i].cgpa);
    }

    for (int i = 0; i < n; i++) {
        printf(\"Student %d: %s\\n\", i+1, s[i].name);
        printf(\"Student ID: %s\\n\", s[i].id);
        printf(\"CGPA: %.2f\\n\", s[i].cgpa);
    }
}
#+end_src
* 03 
```c:line-numbers
#include <stdio.h>
#include <math.h>

typedef struct {
    int x, y;
} point;

int main() {
    point a, b;
    scanf(\"%d%d\", &a.x, &a.y);
    scanf(\"%d%d\", &b.x, &b.y);
    float dis = sqrt( (a.x-b.x)*(a.x-b.x) + (a.y-b.y)*(a.y-b.y) );
    printf(\"The distance is %.2f unit\\n\", dis);
}
#+end_src
* 04 
```c:line-numbers
#include <stdio.h>
#include <math.h>

typedef struct {
    int x, y;
} point;

float dis(point a, point b) {
    return sqrt( (a.x - b.x)*(a.x - b.x) + (a.y - b.y)*(a.y - b.y) );
}

int main() {
    point a, b, c;
    scanf(\"%d%d\", &a.x, &a.y);
    scanf(\"%d%d\", &b.x, &b.y);
    scanf(\"%d%d\", &c.x, &c.y);
    float A = dis(b, c);
    float B = dis(c, a);
    float C = dis(a, b);
    if (A+B <= C || B+C <= A || C+A <= B) {
        puts(\"They are in the same line\");
        return 0;
    }
    float s = (A+B+C) / 2;
    float area = sqrt( s*(s-A)*(s-B)*(s-C) );
    printf(\"The area is %.2f unit\\n\", area);
}
#+end_src
* 05 
```c:line-numbers
#include <stdio.h>

typedef struct {
    float real, img;
} complex;

int main() {
    complex c;
    scanf(\"%f%f\", &c.real, &c.img);
    printf(\"%.2f%+.2fi\\n\", c.real, c.img);
}
#+end_src
* 06 
```c:line-numbers
#include <stdio.h>
#include <math.h>

typedef struct {
    float real, img;
} complex;

int main() {
    complex c;
    scanf(\"%f%f\", &c.real, &c.img);

    float mod = sqrt( c.real*c.real + c.img*c.img );
    printf(\"Modulus = %.4f\\n\", mod);
    if (c.img*c.real < 0)
        printf(\"Argument = %.4f\\n\", 3.1416+atan(c.img/c.real));
    else
        printf(\"Argument = %.4f\\n\", atan(c.img/c.real));
}
#+end_src
* 07 
```c:line-numbers
#include <stdio.h>

typedef struct {
    int real, img;
} complex;

int main() {
    complex a, b;
    scanf(\"%d%d\", &a.real, &a.img);
    scanf(\"%d%d\", &b.real, &b.img);

    printf(\"(%d%+di)+(%d%+di)=%d%+di\\n\",
           a.real, a.img, b.real, b.img,
           a.real+b.real, a.img+b.img);
    
    printf(\"(%d%+di)-(%d%+di)=%d%+di\\n\",
           a.real, a.img, b.real, b.img,
           a.real-b.real, a.img-b.img);
}
#+end_src
* 08 
```c:line-numbers
#include <stdio.h>

typedef struct {
    int real, img;
} complex;

int main() {
    complex a, b;
    scanf(\"%d%d\", &a.real, &a.img);
    scanf(\"%d%d\", &b.real, &b.img);

    printf(\"(%d%+di)*(%d%+di)=%d%+di\\n\",
           a.real, a.img, b.real, b.img,
           (a.real*b.real)-(a.img*b.img),
           (a.real*b.img)+(a.img*b.real));
}
#+end_src
* 09 
```c:line-numbers
#include <stdio.h>

typedef struct {
    float real, img;
} complex;

complex mul(complex a, complex b) {
    return (complex) {
        (a.real*b.real)-(a.img*b.img),
        (a.real*b.img)+(a.img*b.real)
    };
}

complex conjugate(complex a) {
    return (complex) { a.real, -a.img };
}

complex div(complex a, complex b) {
    complex num = mul(a, conjugate(b));
    complex denom = mul(b, conjugate(b));
    return (complex) {
        num.real/denom.real, num.img/denom.real
    };
}

void print_complex(complex a) {
    printf(\"(%.2f%+.2fi)\", a.real, a.img);
}

int main() {
    complex a, b;
    scanf(\"%f%f\", &a.real, &a.img);
    scanf(\"%f%f\", &b.real, &b.img);

    print_complex(a);
    putchar('/');
    print_complex(b);
    putchar('=');
    print_complex(div(a, b));
    putchar(\\n);
}
#+end_src
* 10 
```c:line-numbers
#include <stdio.h>

typedef struct {
    int m, cm;
} length;

int main() {
    length l;
    scanf(\"%d%d\", &l.m, &l.cm);
    printf(\"Length in meter: %.2f\\n\", l.m + (float)l.cm/100);
    printf(\"Length in centimeter: %d\\n\", l.m*100+l.cm);
}
#+end_src
* 11 
```c:line-numbers
#include <stdio.h>

typedef struct {
    int m, cm;
} length;

length add(length a, length b) {
    return (length) {
        (a.cm + b.cm >= 100) ? a.m + b.m + 1 : a.m + b.m,
        (a.cm + b.cm >= 100) ? (a.cm+b.cm)%100 : a.cm + b.cm
    };
}

int main() {
    length a, b;
    scanf(\"%d%d\", &a.m, &a.cm);
    scanf(\"%d%d\", &b.m, &b.cm);

    length c = add(a, b);
    printf(\"The sum is %d meter %d centimeter\\n\", c.m, c.cm);
}
#+end_src
* 12 
```c:line-numbers
#include <stdio.h>

typedef struct {
    int h, m, s;
} time;

float h(time t) {
    return t.h + (float)t.m/60 + (float)t.s/3600;
}

float m(time t) {
    return t.h*60 + t.m + (float)t.s/60;
}

int s(time t) {
    return t.h*3600 + t.m*60 + t.s;
}

int main() {
    time t;
    scanf(\"%d%d%d\", &t.h, &t.m, &t.s);

    printf(\"Time interval in hour: %.2f\\n\", h(t));
    printf(\"Time interval in minute: %.2f\\n\", m(t));
    printf(\"Time interval in second: %d\\n\", s(t));
}
#+end_src
* 13 
```c:line-numbers
#include <stdio.h>

typedef struct {
    int h, m, s;
} time;

time sub(time a, time b) {
    time t = {
        a.h - b.h,
        a.m - b.m,
        a.s - b.s
    };
    if (t.s < 0) {
        t.s += 60;
        t.m -= 1;
    }
    if (t.m < 0) {
        t.m += 60;
        t.h -= 1;
    }
    return t;
}

int main() {
    time a, b;
    scanf(\"%d%d%d\", &a.h, &a.m, &a.s);
    scanf(\"%d%d%d\", &b.h, &b.m, &b.s);

    time c = sub(a, b);
    printf(\"%d %d %d\\n\", c.h, c.m, c.s);
}
#+end_src" . 414) (t 26160 52273 664089 537000) nil (76 . 5503) ("#+begin_src C -n
#include <stdio.h>

typedef struct {
    char name[20];
    char id[20];
    float cgpa;
} std;

int main() {
    std s;
    scanf(\"%[^\\n]%*c\", s.name);
    scanf(\"%[^\\n]%*c\", s.id);
    scanf(\"%f\", &s.cgpa);

    printf(\"Name: %s\\n\", s.name);
    printf(\"Student ID: %s\\n\", s.id);
    printf(\"CGPA: %.2f\\n\", s.cgpa);
}
#+end_src
* 02 
#+begin_src C -n
#include <stdio.h>

typedef struct {
    char name[20];
    char id[20];
    float cgpa;
} std;

int main() {
    int n; scanf(\"%d%*c\", &n);
    std s[n];
    for (int i = 0; i < n; i++) {
        scanf(\"%[^\\n]%*c\", s[i].name);
        scanf(\"%[^\\n]%*c\", s[i].id);
        scanf(\"%f%*c\", &s[i].cgpa);
    }

    for (int i = 0; i < n; i++) {
        printf(\"Student %d: %s\\n\", i+1, s[i].name);
        printf(\"Student ID: %s\\n\", s[i].id);
        printf(\"CGPA: %.2f\\n\", s[i].cgpa);
    }
}
#+end_src
* 03 
#+begin_src C -n
#include <stdio.h>
#include <math.h>

typedef struct {
    int x, y;
} point;

int main() {
    point a, b;
    scanf(\"%d%d\", &a.x, &a.y);
    scanf(\"%d%d\", &b.x, &b.y);
    float dis = sqrt( (a.x-b.x)*(a.x-b.x) + (a.y-b.y)*(a.y-b.y) );
    printf(\"The distance is %.2f unit\\n\", dis);
}
#+end_src
* 04 
#+begin_src C -n
#include <stdio.h>
#include <math.h>

typedef struct {
    int x, y;
} point;

float dis(point a, point b) {
    return sqrt( (a.x - b.x)*(a.x - b.x) + (a.y - b.y)*(a.y - b.y) );
}

int main() {
    point a, b, c;
    scanf(\"%d%d\", &a.x, &a.y);
    scanf(\"%d%d\", &b.x, &b.y);
    scanf(\"%d%d\", &c.x, &c.y);
    float A = dis(b, c);
    float B = dis(c, a);
    float C = dis(a, b);
    if (A+B <= C || B+C <= A || C+A <= B) {
        puts(\"They are in the same line\");
        return 0;
    }
    float s = (A+B+C) / 2;
    float area = sqrt( s*(s-A)*(s-B)*(s-C) );
    printf(\"The area is %.2f unit\\n\", area);
}
#+end_src
* 05 
#+begin_src C -n
#include <stdio.h>

typedef struct {
    float real, img;
} complex;

int main() {
    complex c;
    scanf(\"%f%f\", &c.real, &c.img);
    printf(\"%.2f%+.2fi\\n\", c.real, c.img);
}
#+end_src
* 06 
#+begin_src C -n
#include <stdio.h>
#include <math.h>

typedef struct {
    float real, img;
} complex;

int main() {
    complex c;
    scanf(\"%f%f\", &c.real, &c.img);

    float mod = sqrt( c.real*c.real + c.img*c.img );
    printf(\"Modulus = %.4f\\n\", mod);
    if (c.img*c.real < 0)
        printf(\"Argument = %.4f\\n\", 3.1416+atan(c.img/c.real));
    else
        printf(\"Argument = %.4f\\n\", atan(c.img/c.real));
}
#+end_src
* 07 
#+begin_src C -n
#include <stdio.h>

typedef struct {
    int real, img;
} complex;

int main() {
    complex a, b;
    scanf(\"%d%d\", &a.real, &a.img);
    scanf(\"%d%d\", &b.real, &b.img);

    printf(\"(%d%+di)+(%d%+di)=%d%+di\\n\",
           a.real, a.img, b.real, b.img,
           a.real+b.real, a.img+b.img);
    
    printf(\"(%d%+di)-(%d%+di)=%d%+di\\n\",
           a.real, a.img, b.real, b.img,
           a.real-b.real, a.img-b.img);
}
#+end_src
* 08 
#+begin_src C -n
#include <stdio.h>

typedef struct {
    int real, img;
} complex;

int main() {
    complex a, b;
    scanf(\"%d%d\", &a.real, &a.img);
    scanf(\"%d%d\", &b.real, &b.img);

    printf(\"(%d%+di)*(%d%+di)=%d%+di\\n\",
           a.real, a.img, b.real, b.img,
           (a.real*b.real)-(a.img*b.img),
           (a.real*b.img)+(a.img*b.real));
}
#+end_src
* 09 
#+begin_src C -n
#include <stdio.h>

typedef struct {
    float real, img;
} complex;

complex mul(complex a, complex b) {
    return (complex) {
        (a.real*b.real)-(a.img*b.img),
        (a.real*b.img)+(a.img*b.real)
    };
}

complex conjugate(complex a) {
    return (complex) { a.real, -a.img };
}

complex div(complex a, complex b) {
    complex num = mul(a, conjugate(b));
    complex denom = mul(b, conjugate(b));
    return (complex) {
        num.real/denom.real, num.img/denom.real
    };
}

void print_complex(complex a) {
    printf(\"(%.2f%+.2fi)\", a.real, a.img);
}

int main() {
    complex a, b;
    scanf(\"%f%f\", &a.real, &a.img);
    scanf(\"%f%f\", &b.real, &b.img);

    print_complex(a);
    putchar('/');
    print_complex(b);
    putchar('=');
    print_complex(div(a, b));
    putchar(\\n);
}
#+end_src
* 10 
#+begin_src C -n
#include <stdio.h>

typedef struct {
    int m, cm;
} length;

int main() {
    length l;
    scanf(\"%d%d\", &l.m, &l.cm);
    printf(\"Length in meter: %.2f\\n\", l.m + (float)l.cm/100);
    printf(\"Length in centimeter: %d\\n\", l.m*100+l.cm);
}
#+end_src
* 11 
#+begin_src C -n
#include <stdio.h>

typedef struct {
    int m, cm;
} length;

length add(length a, length b) {
    return (length) {
        (a.cm + b.cm >= 100) ? a.m + b.m + 1 : a.m + b.m,
        (a.cm + b.cm >= 100) ? (a.cm+b.cm)%100 : a.cm + b.cm
    };
}

int main() {
    length a, b;
    scanf(\"%d%d\", &a.m, &a.cm);
    scanf(\"%d%d\", &b.m, &b.cm);

    length c = add(a, b);
    printf(\"The sum is %d meter %d centimeter\\n\", c.m, c.cm);
}
#+end_src
* 12 
#+begin_src C -n
#include <stdio.h>

typedef struct {
    int h, m, s;
} time;

float h(time t) {
    return t.h + (float)t.m/60 + (float)t.s/3600;
}

float m(time t) {
    return t.h*60 + t.m + (float)t.s/60;
}

int s(time t) {
    return t.h*3600 + t.m*60 + t.s;
}

int main() {
    time t;
    scanf(\"%d%d%d\", &t.h, &t.m, &t.s);

    printf(\"Time interval in hour: %.2f\\n\", h(t));
    printf(\"Time interval in minute: %.2f\\n\", m(t));
    printf(\"Time interval in second: %d\\n\", s(t));
}
#+end_src
* 13 
#+begin_src C -n" . 76) (t 26160 52195 223865 895000) nil ("
" . -1) nil (1 . 5985) (t . -1)) (emacs-undo-equiv-table))