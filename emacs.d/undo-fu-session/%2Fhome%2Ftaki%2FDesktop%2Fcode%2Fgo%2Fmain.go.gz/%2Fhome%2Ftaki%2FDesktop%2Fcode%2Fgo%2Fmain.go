((buffer-size . 231) (buffer-checksum . "0b2c4931da6c394b53f26e1b951dc697392a41cc"))
((emacs-buffer-undo-list nil (179 . 180) ("mem[n]" . 179) ((marker . 179) . -5) ((marker . 179) . -5) ((marker . 179) . -5) ((marker . 179) . -5) ((marker . 179) . -5) ((marker . 179) . -5) ((marker . 179) . -5) ((marker . 179) . -5) ((marker . 179) . -5) ((marker . 179) . -5) ((marker . 179) . -5) ((marker . 179) . -5) ((marker . 179) . -5) ((marker . 179) . -5) ((marker . 179) . -5) ((marker . 179) . -5) ((marker . 179) . -5) ((marker . 179) . -5) ((marker . 179) . -5) ((marker . 179) . -5) ((marker . 179) . -5) ((marker . 179) . -5) ((marker . 179) . -4) ((marker . 179) . -4) ((marker . 179) . -4) ((marker . 179) . -4) ((marker . 179) . -4) ((marker . 179) . -4) ((marker . 179) . -4) ((marker . 179) . -4) ((marker . 179) . -4) ((marker . 179) . -4) ((marker . 179) . -4) ((marker . 179) . -4) ((marker . 179) . -4) ((marker . 179) . -4) ((marker . 179) . -3) ((marker . 179) . -3) ((marker . 179) . -3) ((marker . 179) . -3) ((marker . 179) . -3) ((marker . 179) . -3) ((marker . 179) . -3) ((marker . 179) . -2) ((marker . 179) . -2) ((marker . 179) . -2) ((marker . 179) . -2) ((marker . 179) . -2) ((marker . 179) . -2) ((marker . 179) . -2) ((marker . 179) . -2) ((marker . 179) . -2) ((marker . 179) . -2) ((marker . 179) . -2) ((marker . 179) . -2) ((marker . 179) . -2) ((marker . 179) . -2) ((marker . 179) . -1) ((marker . 179) . -1) ((marker . 179) . -1) ((marker . 179) . -1) ((marker . 179) . -1) ((marker . 179) . -1) ((marker . 179) . -1) ((marker . 179) . -1) ((marker . 179) . -1) ((marker . 179) . -1) ((marker . 179) . -1) ((marker . 179) . -1) ((marker . 179) . -1) ((marker . 179) . -1) ((marker) . -6) ((marker) . -6) ((marker) . -6) ((marker) . -6) nil (161 . 163) nil (159 . 160) nil (148 . 153) ("f" . -148) ((marker . 148) . -1) ((marker . 148) . -1) ((marker . 148) . -1) ((marker . 148) . -1) ((marker . 148) . -1) ((marker . 148) . -1) ((marker . 148) . -1) ((marker . 148) . -1) ((marker . 148) . -1) ((marker . 148) . -1) ((marker . 148) . -1) ((marker . 148) . -1) ((marker . 148) . -1) ((marker . 148) . -1) ((marker . 148) . -1) ((marker . 148) . -1) ((marker . 148) . -1) ((marker . 148) . -1) ((marker . 148) . -1) ((marker . 148) . -1) ((marker . 148) . -1) ((marker . 148) . -1) ((marker . 148) . -1) ((marker . 148) . -1) ((marker . 148) . -1) ((marker . 148) . -1) ((marker . 148) . -1) ((marker . 148) . -1) ((marker . 148) . -1) ((marker . 148) . -1) ((marker . 148) . -1) ((marker . 148) . -1) ((marker . 179) . -1) ((marker . 148) . -1) ((marker . 148) . -1) ((marker . 148) . -1) ((marker . 148) . -1) ((marker) . -1) 149 (148 . 149) (t 26062 5446 220585 732000) nil ("0" . 66) (67 . 68) 66 ("6" . 65) (t 26062 5440 280332 927000) (66 . 67) 65 (t 26062 5440 280332 927000) nil (65 . 66) nil ("6" . 65) (t 26062 5440 280332 927000) nil (65 . 66) ("5" . 65) (t 26062 5433 926729 216000) nil (nil rear-nonsticky nil 140 . 141) (nil fontified nil 140 . 141) (140 . 141) 139 nil (")" . 139) ((marker* . 180) . 1) nil (134 . 140) (t 26062 5421 796213 67000) nil (108 . 109) nil (86 . 87) (t 26062 5353 826655 966000) nil ("
" . -203) 186 nil (217 . 218) (213 . 218) ("fib(n-1) + fib(n-2)" . 213) ((marker . 179) . -18) nil (205 . 233) nil ("	return fib(n-1) + fib(n-2)
" . 205) ((marker . 179) . -27) ((marker . 230) . -28) ((marker . 230) . -28) ((marker . 179) . -26) 231 nil (nil rear-nonsticky nil 202 . 203) (nil fontified nil 184 . 203) (184 . 203) 183 nil (181 . 184) ("]" . -180) (180 . 181) ("]" . -180) (179 . 181) (178 . 180) (175 . 178) (174 . 175) ("	" . 173) ((marker . 179) . -1) (174 . 175) (172 . 174) (t 26062 5138 584191 590000) 171 nil (167 . 168) (156 . 168) (154 . 156) (155 . 156) ("		" . 154) (154 . 156) (153 . 155) (147 . 154) (">" . -147) ((marker . 179) . -1) (" " . -148) ((marker . 179) . -1) ("0" . -149) ((marker . 179) . -1) 150 (146 . 150) ("]" . -145) (145 . 146) ("]" . -145) (144 . 146) (137 . 145) (136 . 137) ("	" . 135) ((marker . 179) . -1) (136 . 137) (134 . 136) 125 nil (" " . -89) ((marker . 179) . -1) 90 (86 . 90) ("]" . -85) (85 . 86) ("]" . -85) (82 . 86) (81 . 83) ("i" . -81) ((marker . 230) . -1) ((marker . 230) . -1) ((marker . 179) . -1) ("n" . -82) ((marker . 230) . -1) ((marker . 230) . -1) ((marker . 179) . -1) ("t" . -83) ((marker . 230) . -1) ((marker . 230) . -1) ((marker . 179) . -1) 84 ("[" . -84) ((marker . 179) . -1) ("]" . 85) (81 . 86) ("p" . -81) ((marker . 230) . -1) ((marker . 230) . -1) ((marker . 179) . -1) ("r" . -82) ((marker . 230) . -1) ((marker . 230) . -1) ((marker . 179) . -1) ("i" . -83) ((marker . 230) . -1) ((marker . 230) . -1) ((marker . 179) . -1) 84 (81 . 84) (80 . 81) ("[" . -80) ((marker . 179) . -1) ("]" . 81) (80 . 82) (73 . 80) ("v" . -73) ((marker . 179) . -1) ("a" . -74) ((marker . 179) . -1) ("r" . -75) ((marker . 179) . -1) (" " . -76) ((marker . 179) . -1) 77 (73 . 77) (72 . 73) (71 . 72) (t 26062 4759 758250 177000) 70 nil (65 . 66) ("3" . 65) (t 26062 4756 688121 961000) nil (65 . 66) ("2" . 65) ((marker . 179) . -1) ((marker . 179) . -1) (t 26062 4753 791334 336000) nil ("5" . 66) (67 . 68) 66 ("1" . 65) (t 26062 4747 124389 365000) (66 . 67) 65 (t 26062 4747 124389 365000) nil (66 . 67) ("2" . 66) (t 26062 4743 294229 509000) nil (65 . 67) (61 . 66) nil ("	for i := 1; i <= 10; i++ {
		fmt.Printf(\"%d \", fib(i))
	}
" . 48) ((marker . 179) . -58) ((marker . 230) . -57) ((marker . 48) . -57) ((marker . 48) . -1) ((marker . 48) . -28) ((marker . 179) . -1) 49 (t 26062 4430 481307 457000) nil (199 . 200) 196 nil (")" . -196) (196 . 197) (")" . -196) (193 . 197) (186 . 194) (")" . -185) (185 . 186) (")" . -185) (183 . 186) (182 . 183) (173 . 183) ("u" . -173) ((marker . 179) . -1) ("t" . -174) ((marker . 179) . -1) ("r" . -175) ((marker . 179) . -1) ("n" . -176) ((marker . 179) . -1) 177 (171 . 177) (169 . 171) 169 nil ("	prev, curr, n := 1, 1, n-2
	for ; n > 0; n-- {
		tmp  := curr + prev
		prev  = curr
		curr  = tmp
	}
	return curr
" . 170) ((marker . 179) . -114) ((marker . 230) . -102) ((marker . 48) . -102) ((marker . 230) . -86) ((marker . 230) . -94) ((marker . 179) . -102) 272 nil ("
" . 123) ((marker . 179) . -1) ("
" . 124) ((marker . 179) . -1) nil (124 . 125) (123 . 124) 122 nil ("
" . -286) ((marker . 179) . -1) ((marker . 179) . -1) ((marker . 231) . -1) 285 nil ("
func fact(n int) int {
	if n < 2 {
		return 1
	}
	return n * fact(n-1)
}

type point struct {
	x int
	y int
}
" . 287) ((marker . 179) . -110) ((marker . 231) . -1) (t 26062 4193 758449 8000) nil (64 . 65) nil (58 . 59) ("0" . 58) (t 26062 4166 654045 32000) nil (";" . 120) nil (119 . 121) (")" . -119) (119 . 120) (nil rear-nonsticky nil 118 . 119) (nil fontified nil 107 . 119) (107 . 119) ("f" . -107) ((marker . 230) . -1) ((marker . 230) . -1) ((marker . 179) . -1) ("m" . -108) ((marker . 179) . -1) ("t" . -109) ((marker . 179) . -1) ("." . -110) ((marker . 179) . -1) ("P" . -111) ((marker . 179) . -1) ("r" . -112) ((marker . 179) . -1) ("i" . -113) ((marker . 179) . -1) 114 (111 . 114) (109 . 111) ("." . -109) ((marker . 179) . -1) 110 (107 . 110) (105 . 107) 104 nil (93 . 95) ("\"" . -92) (92 . 93) ("\"" . -92) (89 . 93) (88 . 90) ("\"" . -88) (88 . 89) ("%" . -88) ((marker . 179) . -1) 89 (88 . 89) nil (86 . 87) ("n" . 86) nil ("l" . 86) (t 26062 4136 919542 839000) nil (93 . 94) ("5" . 93) nil ("	" . -77) ((marker . 179) . -1) (75 . 77) 76 nil (nil rear-nonsticky nil 75 . 76) (75 . 96) nil ("	fmt.Println(fib(5))
" . 78) ((marker . 179) . -20) ((marker . 70) . -1) ((marker . 70) . -13) ((marker . 179) . -19) 97 nil ("		" . 74) ("
" . -74) 49 nil (75 . 77) (76 . 77) ("		" . 75) (75 . 77) (74 . 76) (68 . 75) (49 . 68) (47 . 49) (t 26062 4108 351759 88000) 46 nil (209 . 210) (194 . 195) nil (172 . 173) (t 26062 4099 898096 359000) nil ("	" . -116) ((marker . 179) . -1) 117 (115 . 117) 114 nil ("	" . 114) ("
" . -114) ("		" . 106) ("
" . -106) 105 nil (121 . 122) 146 nil (nil rear-nonsticky nil 146 . 147) (nil fontified nil 121 . 147) (121 . 147) nil ("	" . -121) ((marker . 179) . -1) 122 (120 . 122) 119 nil ("prev, curr, n := 1, 1, n-2" . 126) ((marker . 179) . -25) nil ("
	" . 120) ((marker . 230) . -2) ((marker . 230) . -2) ((marker . 179) . -2) ("prev" . 122) ((marker . 230) . -3) ((marker . 230) . -3) ((marker . 179) . -3) nil (122 . 126) (120 . 122) 119 nil (218 . 231) nil ("
	return curr
" . 214) ((marker . 179) . -1) ((marker . 179) . -13) ((marker . 179) . -2) (227 . 228) (nil rear-nonsticky t 215 . 216) nil ("		" . 215) (217 . 218) nil ("	" . -217) ((marker . 179) . -1) (215 . 217) 216 nil (nil rear-nonsticky nil 215 . 216) ("
" . -227) (214 . 228) 202 nil ("	return curr
" . 218) ((marker . 179) . -12) ((marker . 179) . -11) 229 nil ("
	" . 120) ((marker . 230) . -2) ((marker . 230) . -2) ((marker . 179) . -2) ("curr" . 122) ((marker . 230) . -3) ((marker . 230) . -3) ((marker . 179) . -3) nil (122 . 126) (120 . 122) 119 nil (":" . 209) nil (":" . 195) nil (":" . 174) (t 26062 4010 371309 916000) nil (75 . 76) (t 26062 3991 900536 607000) nil (345 . 346) 67 nil (67 . 68) (")" . -67) (67 . 68) (nil rear-nonsticky nil 66 . 67) (nil fontified nil 61 . 67) (61 . 67) (nil rear-nonsticky nil 60 . 61) (nil fontified nil 49 . 61) (49 . 61) ("fib(5)" . 49) ((marker . 179) . -5) nil (208 . 219) (206 . 208) 205 nil (159 . 160) nil (nil rear-nonsticky nil 175 . 176) (174 . 189) 175 nil ("		prev := curr
" . 188) ((marker . 230) . -13) ((marker* . 180) . 1) ((marker . 179) . -14) ((marker . 230) . -13) ((marker . 179) . -13) 201 nil (194 . 202) nil (184 . 187) ("prev" . 184) ((marker . 179) . -3) nil (184 . 188) ("tmp" . 184) ((marker . 230) . -1) ((marker . 230) . -1) nil (" " . 194) nil (194 . 195) nil (184 . 187) ("prev" . 184) ((marker . 179) . -3) nil (191 . 195) (188 . 191) (184 . 188) (180 . 184) (" = " . 180) ((marker . 179) . -2) nil (162 . 173) ("c" . -162) ((marker . 230) . -1) ((marker . 230) . -1) ((marker . 179) . -1) ("u" . -163) ((marker . 230) . -1) ((marker . 230) . -1) ((marker . 179) . -1) ("r" . -164) ((marker . 230) . -1) ((marker . 230) . -1) ((marker . 179) . -1) ("r" . -165) ((marker . 179) . -1) (" " . -166) ((marker . 179) . -1) 167 (166 . 167) (" " . -166) ((marker . 179) . -1) 167 (162 . 167) ("curr" . 162) ((marker . 179) . -3)) (emacs-pending-undo-list ("void" . 30) ((marker . 167) . -3) ((marker) . -4) nil ("    " . 67) ((marker . 154) . -4) ((marker . 154) . -4) ((marker . 154) . -4) ((marker . 154) . -4) ((marker . 154) . -4) ((marker . 154) . -4) ((marker . 154) . -4) ((marker . 154) . -4) ((marker . 154) . -4) ((marker . 154) . -4) ((marker . 154) . -4) ((marker . 179) . -4) ((marker . 154) . -4) ((marker . 154) . -4) ((marker . 154) . -4) ((marker . 154) . -4) ((marker) . -4) (71 . 72) ("}" . -71) (71 . 72) (67 . 71) ("    " . 66) ((marker . 153) . -4) ((marker . 153) . -4) ((marker . 153) . -4) ((marker . 153) . -4) ((marker . 153) . -4) ((marker . 153) . -4) ((marker . 153) . -4) ((marker . 153) . -4) ((marker . 153) . -4) ((marker . 153) . -4) ((marker . 153) . -4) ((marker . 153) . -4) ((marker . 153) . -4) ((marker . 153) . -4) ((marker . 153) . -4) ((marker . 153) . -4) ((marker . 153) . -4) ((marker . 153) . -4) ((marker . 153) . -4) ((marker . 179) . -4) ((marker . 153) . -4) ((marker . 153) . -4) ((marker . 153) . -4) ((marker . 153) . -4) ((marker) . -4) (70 . 71) (66 . 70) (66 . 67) ("
    for (int i = 1; i <= n; i++) {
        float result = 0, tmp;
        scanf(\"%f\", &tmp);
        result += tmp;
        scanf(\"%f\", &tmp);
        result += tmp;
        scanf(\"%f\", &tmp);
        result += tmp;
        scanf(\"%f\", &tmp);
        result += 30 * tmp / 50;
        scanf(\"%f\", &tmp);
        result += 40 * tmp / 100;

        if (result >= 90 && result <= 100)
            printf(\"Student %d: A\\n\", i);
        else if (result >= 86)
            printf(\"Student %d: A-\\n\", i);
        else if (result >= 82)
            printf(\"Student %d: B+\\n\", i);
        else if (result >= 78)
            printf(\"Student %d: B\\n\", i);
        else if (result >= 74)
            printf(\"Student %d: B-\\n\", i);
        else if (result >= 70)
            printf(\"Student %d: C+\\n\", i);
        else if (result >= 66)
            printf(\"Student %d: C\\n\", i);
        else if (result >= 62)
            printf(\"Student %d: C-\\n\", i);
        else if (result >= 58)
            printf(\"Student %d: D+\\n\", i);
        else if (result >= 55)
            printf(\"Student %d: D\\n\", i);
        else if (result < 55)
            printf(\"Student %d: F\\n\", i);
    }
}
" . 66) ((marker . 167) . -1166) ((marker* . 108) . 1101) ((marker . 153) . -67) ((marker* . 185) . 950) ((marker . 153) . -125) ((marker . 153) . -202) ((marker . 153) . -67) ((marker . 153) . -338) ((marker . 153) . -66) ((marker . 153) . -202) ((marker) . -1167) ((marker) . -1167) (t 26061 50048 672958 361000) nil (38 . 1231) ("
" . 38) ((marker* . 108) . 1) ("    " . 38) ((marker . 179) . -4) (38 . 42) nil ("    " . -38) ((marker . 179) . -4) 42 (38 . 42) (38 . 39) ("    int n; scanf(\"%d\", &n);

    for (int i = 1; i <= n; i++) {
        float result = 0, tmp;
        scanf(\"%f\", &tmp);
        result += tmp;
        scanf(\"%f\", &tmp);
        result += tmp;
        scanf(\"%f\", &tmp);
        result += tmp;
        scanf(\"%f\", &tmp);
        result += 30 * tmp / 50;
        scanf(\"%f\", &tmp);
        result += 40 * tmp / 100;

        if (result >= 90 && result <= 100)
            printf(\"Student %d: A\\n\", i);
        else if (result >= 86)
            printf(\"Student %d: A-\\n\", i);
        else if (result >= 82)
            printf(\"Student %d: B+\\n\", i);
        else if (result >= 78)
            printf(\"Student %d: B\\n\", i);
        else if (result >= 74)
            printf(\"Student %d: B-\\n\", i);
        else if (result >= 70)
            printf(\"Student %d: C+\\n\", i);
        else if (result >= 66)
            printf(\"Student %d: C\\n\", i);
        else if (result >= 62)
            printf(\"Student %d: C-\\n\", i);
        else if (result >= 58)
            printf(\"Student %d: D+\\n\", i);
        else if (result >= 55)
            printf(\"Student %d: D\\n\", i);
        else if (result < 55)
            printf(\"Student %d: F\\n\", i);
    }
" . 38) ((marker . 167) . -1192) ((marker* . 108) . 1099) ((marker . 153) . -95) ((marker* . 185) . 948) ((marker . 153) . -153) ((marker . 153) . -230) ((marker . 153) . -95) ((marker . 153) . -366) ((marker . 153) . -94) ((marker . 153) . -230) (t 26061 50048 672958 361000) nil ("
        " . 132) ((marker . 107) . -9) ((marker . 153) . -9) ((marker . 230) . -9) ((marker . 179) . -9) ("for " . 141) ((marker . 107) . -4) ((marker . 153) . -4) ((marker . 230) . -4) ((marker . 179) . -4) ("()" . 145) ((marker . 107) . -1) ((marker . 153) . -2) ((marker . 230) . -1) ((marker . 179) . -1) ("int i =0" . 146) ((marker . 107) . -2) ((marker . 230) . -2) ((marker . 179) . -8) (153 . 154) (" 0" . 153) ((marker . 179) . -2) (";" . 155) ((marker . 179) . -1) (" i < 3" . 156) ((marker . 179) . -6) (";" . 162) ((marker . 179) . -1) (" i++" . 163) nil (" " . 168) ((marker . 153) . -1) ("{}" . 169) ((marker* . 108) . 1) ((marker . 153) . -1) ("

        " . 170) ((marker* . 108) . 9) ((marker . 153) . -10) ("            " . 171) nil (170 . 171) (170 . 182) nil (181 . 208) nil ("        scanf(\"%f\", &tmp);
" . 171) nil (208 . 231) nil ("        result += tmp;
" . 198) nil ("            " . 171) (183 . 191) ("            " . 202) (214 . 222) nil (239 . 339) nil ("        scanf(\"%f\", &tmp);
        result += tmp;
        scanf(\"%f\", &tmp);
        result += tmp;
" . 239) ((marker . 167) . -99) ((marker . 107) . -85) ((marker . 153) . -8) ((marker . 153) . -85) ((marker . 179) . -85) 324 nil ("        " . -214) (202 . 214) ("        " . -183) ((marker . 179) . -8) (171 . 183) 179 nil (198 . 221) 206 nil ("        result += tmp;
" . 208) ((marker . 167) . -22) ((marker . 179) . -8) 216 nil (171 . 198) 179 nil ("        scanf(\"%f\", &tmp);
" . 181) ((marker . 167) . -26) ((marker . 153) . -8) ((marker . 179) . -25) 206 nil ("            " . 170) ("
" . -170) 144 nil (171 . 183) (170 . 180) (169 . 171) (168 . 169) nil ("            " . 169) (181 . 189) nil ("        " . -181) ((marker . 153) . -8) (169 . 181) 194 nil (163 . 167) (162 . 163) (156 . 162) (155 . 156) (153 . 155) ("0" . -153) ((marker . 179) . -1) 154 (146 . 154) (145 . 147) (141 . 145) (132 . 141) (t 26061 50048 672958 361000) 117 nil ("
        " . 132) ((marker . 179) . -9) (133 . 141) nil ("        " . -133) ((marker . 179) . -8) 141 (132 . 141) (t 26061 50048 672958 361000) 117 nil (1232 . 1233) 378 nil ("sum_of_ratio" . -378) (390 . 396) ("sum_of_ratio" . -318) (330 . 336) ("sum_of_ratio" . -268) (280 . 286) ("sum_of_ratio" . -218) (230 . 236) ("sum_of_ratio" . -168) (180 . 186) nil ("        float result = 100 * sum_of_ratio / 5;
" . 435) ((marker . 167) . -46) ((marker . 179) . -8) 443 nil (422 . 423) (421 . 422) (418 . 421) ("5" . -418) ((marker . 179) . -1) ("0" . -419) ((marker . 179) . -1) 420 (418 . 420) nil (356 . 357) (355 . 356) (352 . 355) (" " . -352) ((marker . 179) . -1) 353 (352 . 353) nil (358 . 359) ("3" . 358) nil (358 . 359) ("5" . 358) nil (" / 15" . 299) ((marker . 167) . -4) ((marker . 107) . -4) ((marker . 153) . -4) ((marker . 179) . -4) 303 nil (" / 10" . 243) ((marker . 167) . -4) ((marker . 107) . -4) ((marker . 153) . -4) ((marker . 179) . -4) 247 nil (" / 5" . 187) ((marker . 167) . -3) ((marker . 107) . -3) ((marker . 153) . -3) ((marker . 179) . -3) 190 nil (116 . 122) ("sum_of_ratio" . 116) ((marker . 167) . -11) ((marker . 179) . -8) 124 nil ("#include <stdio.h>


int main(void) {

    int n; scanf(\"%d\", &n);


    for (int i = 1; i <= n; i++) {

        float sum_of_ratio = 0, tmp;

        scanf(\"%f\", &tmp);

        sum_of_ratio += tmp / 5;

        scanf(\"%f\", &tmp);

        sum_of_ratio += tmp / 10;

        scanf(\"%f\", &tmp);

        sum_of_ratio += tmp / 15;

        scanf(\"%f\", &tmp);

        sum_of_ratio += tmp / 50;

        scanf(\"%f\", &tmp);

        sum_of_ratio += tmp / 100;


        float result = 100 * sum_of_ratio / 5;

        if (result >= 90 && result <= 100)

            printf(\"Student %d: A\\n\", i);

        else if (result >= 86)

            printf(\"Student %d: A-\\n\", i);

        else if (result >= 82)

            printf(\"Student %d: B+\\n\", i);

        else if (result >= 78)

            printf(\"Student %d: B\\n\", i);

        else if (result >= 74)

            printf(\"Student %d: B-\\n\", i);

        else if (result >= 70)

            printf(\"Student %d: C+\\n\", i);

        else if (result >= 66)

            printf(\"Student %d: C\\n\", i);

        else if (result >= 62)

            printf(\"Student %d: C-\\n\", i);

        else if (result >= 58)

            printf(\"Student %d: D+\\n\", i);

        else if (result >= 55)

            printf(\"Student %d: D\\n\", i);

        else if (result < 55)

            printf(\"Student %d: F\\n\", i);

    }

}

" . 1) ((marker . 19) . -18) ((marker . 167) . -1358) ((marker . 107) . -68) ((marker* . 108) . 1359) ((marker . 107) . -68) ((marker* . 185) . 1359) ((marker . 1) . -1356) ((marker . 1) . -1356) ((marker . 1) . -68) ((marker . 1) . -68) ((marker . 1) . -1079) ((marker . 1) . -68) ((marker . 1) . -68) ((marker . 1) . -68) ((marker . 230) . -68) ((marker . 179) . -1358) 1359 nil (nil rear-nonsticky nil 1359 . 1360) ("
" . -2678) (1359 . 2679) (t 26061 48845 781455 566000) nil (68 . 69) ("    " . 68) nil (107 . 108) nil (144 . 145) nil (171 . 172) nil (204 . 205) nil (231 . 232) nil (265 . 266) nil (292 . 293) nil (326 . 327) nil (353 . 354) nil (387 . 388) nil (414 . 415) nil (450 . 451) ("        " . 450) nil (450 . 458) ("
" . -450) nil ("
" . -414) 413 nil ("
" . -387) 379 nil ("
" . -353) 352 nil ("
" . -326) 318 nil ("
" . -292) 291 nil ("
" . -265) 257 nil ("
" . -231) 230 nil ("
" . -204) 197 nil ("
" . -171) 170 nil ("
" . -144) 141 nil ("
" . -107) 76 nil (68 . 72) ("
" . -68) (t 26061 48845 781455 566000) nil (1358 . 1359) 1 nil ("#include <stdio.h>

int main(void) {
}
" . 1) ((marker . 19) . -18) ((marker . 167) . -38) ((marker . 107) . -20) ((marker* . 108) . 2) ((marker . 107) . -37) ((marker . 153) . -37) ((marker . 1) . -36) ((marker . 1) . -19) ((marker . 1) . -39) ((marker . 1) . -20) ((marker . 1) . -20) ((marker . 1) . -37) ((marker . 1) . -37) ((marker . 1) . -37) ((marker . 1) . -37) ((marker . 1) . -36) ((marker . 1) . -37) ((marker . 1) . -20) ((marker . 1) . -20) ((marker . 1) . -20) ((marker . 1) . -39) ((marker . 1) . -39) ((marker . 230) . -20) ((marker . 179) . -37) 38 nil (nil rear-nonsticky nil 1396 . 1397) (nil fontified nil 62 . 1397) (nil fontified nil 59 . 62) (nil fontified nil 41 . 59) (nil fontified nil 40 . 41) (40 . 1397) nil ("
" . -37) ((marker . 167) . -1) ((marker . 167) . -1) ((marker . 107) . -1) ((marker . 1) . -1) ((marker . 1) . -1) ((marker . 230) . -1) 21 nil ("    int n = 89;
" . 38) ((marker . 167) . -15) ((marker . 107) . -4) ((marker . 1) . -4) ((marker . 230) . -4) nil ("    switch (1) {
    case n >= 90:
        printf(\"A\\n\");
        break;
    case n >= 86:
        printf(\"A\\n\");
        break;
    case n >= 83:
        printf(\"A-\\n\");
        break;
    default:
        printf(\"Fail\\n\");
        break;
    }
" . 55) ((marker . 167) . -245) ((marker* . 108) . 25) ((marker . 107) . -244) ((marker . 153) . -4) ((marker . 153) . -244) ((marker . 1) . -220) ((marker . 1) . -220) ((marker . 1) . -220) ((marker . 1) . -244) ((marker . 179) . -244) 299 (t 26060 56093 316801 683000) nil (270 . 276) ("A-\\n" . 270) ((marker . 167) . -3) 269 nil (nil rear-nonsticky nil 261 . 262) ("
" . -277) (253 . 278) 252 nil ("        " . 253) ("
" . -253) 248 nil (253 . 262) (241 . 245) ("        " . 241) (256 . 257) (" " . -256) ((marker . 179) . -1) 257 (249 . 257) (241 . 249) (241 . 242) 254 nil ("        printf(\"A\\n\");
" . 241) ((marker . 167) . -22) ((marker . 179) . -16) 257 nil ("    case n >= 90:
" . 241) ((marker . 167) . -17) ((marker . 179) . -16) 257 nil (219 . 220) nil ("-" . 163) nil (219 . 220) nil ("A" . 219) nil ("0" . 200) (201 . 202) 200 ("9" . 199) (200 . 201) 199 nil (163 . 164) nil ("0" . 143) (144 . 145) 143 ("9" . 142) (143 . 144) 142 nil (nil rear-nonsticky nil 131 . 132) ("
" . -295) (127 . 296) 126 nil (126 . 127) (121 . 126) (112 . 121) 111 nil (111 . 112) (")" . -110) (110 . 111) (")" . -110) (110 . 111) ("\"" . -109) (109 . 110) ("\"" . -109) (106 . 110) (105 . 107) ("\"" . -105) (105 . 106) (104 . 106) (103 . 104) (101 . 103) ("t" . -101) ((marker . 179) . -1) ("n" . -102) ((marker . 179) . -1) 103 (98 . 103) (89 . 98) (88 . 89) (82 . 88) (" " . -82) ((marker . 179) . -1) (">" . -83) ((marker . 179) . -1) (" " . -84) ((marker . 179) . -1) ("9" . -85) ((marker . 179) . -1) 86 (81 . 86) (80 . 81) nil ("        " . -85) ((marker . 179) . -8) (81 . 85) 89 nil (72 . 76) ("            " . 72) 67 nil (67 . 68) (66 . 68) ("1" . -66) ((marker . 107) . -1) ((marker . 230) . -1) ((marker . 179) . -1) (")" . -67) ((marker . 179) . -1) 68 (67 . 68) (")" . -67) (67 . 68) (66 . 67) ("(" . -66) ((marker . 179) . -1) (")" . 67) (66 . 68) ("1" . 66) nil (82 . 86) (70 . 82) (69 . 79) (68 . 70) (59 . 68) (55 . 59) ("    " . 54) ((marker . 179) . -4) (53 . 59) (52 . 53) (42 . 52) (38 . 42) (38 . 39) ("    int n, m; scanf(\"%d%d\", &n, &m);

    int sum  = 0;
    int sign = -1;
    int at   = 1; // the number we're currently at; 1 then 2 then 3

    // e.g. n = 12, m = 3
    for (int i = 0; i < n/m; i++) {   // 12/3 = 4; there will be 4 groups
        for (int j = 0; j < m; j++) { // each group has m=3 numbers
            sum += sign * at;
            at++;
        }

        sign = -sign;               // switching sign
    }

    printf(\"%d\\n\", sum);
" . 38) ((marker . 167) . -456) ((marker* . 108) . 87) ((marker . 1) . -233) ((marker . 230) . -37) ((marker . 179) . -37) 75 (t 26060 53144 439094 638000) nil ("        " . -408) ((marker . 179) . -8) 416 (407 . 416) 398 nil (396 . 397) (394 . 396) (" " . -394) ((marker . 179) . -1) ("+" . -395) ((marker . 179) . -1) ("=" . -396) ((marker . 179) . -1) (" " . -397) ((marker . 179) . -1) 398 (393 . 398) (392 . 393) (379 . 392) 378 nil ("+" . 378) nil ("+" . 378) nil (382 . 390) ("            " . 382) ((marker . 179) . -12) (394 . 395) ("}" . -394) (394 . 395) (381 . 394) 380 nil ("}" . 319) nil (" " . 245) nil (244 . 247) nil (316 . 318) (315 . 316) (t 26060 50299 542460 22000) nil (87 . 89) (" " . 87) (122 . 125) (" " . 122) nil ("e" . 188) nil (190 . 191) nil (186 . 191) nil (409 . 423) ("e" . -409) ((marker . 179) . -1) 410 (408 . 410) (406 . 408) (391 . 406) nil (325 . 337) (311 . 325) ("each " . -311) ((marker . 179) . -5) 316 (310 . 316) (308 . 310) (307 . 308) nil (259 . 271) (253 . 259) (" " . -253) ((marker . 179) . -1) ("w" . -254) ((marker . 179) . -1) 255 (248 . 255) (247 . 248) (243 . 247) nil (192 . 193) nil (185 . 198) (183 . 185) (178 . 183) 178 nil (221 . 222) (220 . 221) (217 . 220) (215 . 217) (214 . 215) nil ("    " . -178) ((marker . 179) . -4) 182 (177 . 182) 129 nil (" " . 111) ((marker . 179) . -1) ("//" . 112) ((marker . 179) . -2) (" " . 114) nil (114 . 115) (112 . 114) (111 . 112) nil (161 . 177) (160 . 161) nil (155 . 160) ("y" . -155) ((marker . 179) . -1) 156 (155 . 156) (146 . 155) ("e" . -146) ((marker . 179) . -1) 147 (142 . 147) ("i" . -142) ((marker . 107) . -1) ((marker . 230) . -1) ((marker . 179) . -1) 143 (130 . 143) (128 . 130) (127 . 128) (t 26060 50134 368759 931000) nil (284 . 285) (")" . -283) (283 . 284) (")" . -283) (283 . 284) (279 . 283) (278 . 279) ("\"" . -277) (277 . 278) ("\"" . -277) (273 . 278) (272 . 274) ("\"" . -272) (272 . 273) (271 . 273) (265 . 271) (261 . 265) ("    " . 260) ((marker . 179) . -4) (264 . 265) (259 . 264) 258 nil (252 . 253) (240 . 252) (231 . 240) 230 nil (230 . 231) (225 . 230) (224 . 225) (223 . 224) ("*" . -223) ((marker . 179) . -1) 224 (223 . 224) (219 . 223) ("(" . -219) ((marker . 107) . -1) ((marker . 230) . -1) ((marker . 179) . -1) (")" . 220) ("s" . -220) ((marker . 107) . -1) ((marker . 230) . -1) ((marker . 179) . -1) ("i" . -221) ((marker . 107) . -1) ((marker . 230) . -1) ((marker . 179) . -1) ("g" . -222) ((marker . 107) . -1) ((marker . 230) . -1) ((marker . 179) . -1) ("n" . -223) ((marker . 107) . -1) ((marker . 230) . -1) ((marker . 179) . -1) 224 (220 . 224) (219 . 221) (212 . 219) (199 . 212) (")" . -198) (198 . 199) (")" . -198) (198 . 199) (194 . 198) (193 . 194) (192 . 193) ("3" . -192) ((marker . 179) . -1) (";" . -193) ((marker . 179) . -1) 194 (193 . 194) (187 . 193) (186 . 187) (" " . -186) ((marker . 179) . -1) 187 (183 . 187) nil (126 . 127) (116 . 126) (111 . 116) 110 nil (161 . 167) (160 . 162) nil (110 . 111) (108 . 110) nil (134 . 135) (133 . 134) nil (105 . 108) (102 . 105) ("u" . -102) ((marker . 179) . -1) 103 (97 . 103) (92 . 97) 87 nil ("        int sign
" . 127) ((marker . 167) . -16) ((marker . 107) . -10) ((marker* . 108) . 1) ((marker . 230) . -10) ((marker . 179) . -15) 142 nil (141 . 143) ("g" . -141) ((marker . 179) . -1) ("n" . -142) ((marker . 179) . -1) 143 (140 . 143) ("u" . -140) ((marker . 179) . -1) 141 (135 . 141) (126 . 135) 108 nil (91 . 92) (80 . 91) (75 . 80) 75 nil (118 . 122) (110 . 118) (109 . 115) (108 . 110) (107 . 108) (")" . -106) (106 . 107) (")" . -106) (106 . 107) (102 . 106) (101 . 102) (" " . -101) ((marker . 179) . -1) 102 (100 . 102) ("n" . -100) ((marker . 107) . -1) ((marker . 230) . -1) ((marker . 179) . -1) ("/" . -101) ((marker . 107) . -1) ((marker . 230) . -1) ((marker . 179) . -1) ("m" . -102) ((marker . 107) . -1) ((marker . 230) . -1) ((marker . 179) . -1) (";" . -103) ((marker . 179) . -1) (" " . -104) ((marker . 179) . -1) ("i" . -105) ((marker . 179) . -1) ("+" . -106) ((marker . 179) . -1) ("+" . -107) ((marker . 179) . -1) 108 (104 . 108) (103 . 104) (102 . 103) (101 . 102) (96 . 101) (" " . -96) ((marker . 179) . -1) ("i" . -97) ((marker . 179) . -1) 98 (95 . 98) (94 . 95) (85 . 94) (84 . 86) (80 . 84) (76 . 80) ("    " . 75) ((marker . 179) . -4) (74 . 80) (73 . 74) (")" . -72) (72 . 73) (")" . -72) (72 . 73) (69 . 72) (68 . 69) (65 . 68) (64 . 65) ("\"" . -63) (63 . 64) ("\"" . -63) (59 . 64) (58 . 60) ("\"" . -58) (58 . 59) (57 . 59) ("9" . -57) ((marker . 179) . -1) 58 ("\"" . -58) ((marker . 179) . -1) ("\"" . 59) (58 . 60) ("\"" . -58) (51 . 59) (50 . 51) (48 . 50) (47 . 48) (42 . 47) (38 . 42) (38 . 39) ("    /* short grid = 0b001010100; */
    /* for (long i = 0; i < N; i++) */
    /*     if ( BITMATCH(grid, 0b111000000) || */
    /*          BITMATCH(grid, 0b000111000) || */
    /*          BITMATCH(grid, 0b000000111) || */
    /*          BITMATCH(grid, 0b100100100) || */
    /*          BITMATCH(grid, 0b010010010) || */
    /*          BITMATCH(grid, 0b001001001) || */
    /*          BITMATCH(grid, 0b100010001) || */
    /*          BITMATCH(grid, 0b001010100)  ); */

    int grid[9] = {2, 3, 0,
                   5, 0, 7,
                   0, 9, 10};
    //for (long i = 0; i < N; i++)
        if ( (grid[0] == grid[1] && grid[1] == grid[2]) ||
             (grid[3] == grid[4] && grid[4] == grid[5]) ||
             (grid[6] == grid[7] && grid[7] == grid[8]) ||
             (grid[0] == grid[3] && grid[3] == grid[6]) ||
             (grid[1] == grid[4] && grid[4] == grid[7]) ||
             (grid[2] == grid[5] && grid[5] == grid[8]) ||
             (grid[0] == grid[4] && grid[4] == grid[9]) ||
             (grid[2] == grid[4] && grid[4] == grid[6])  ) printf(\"WON\\n\");
" . 38) ((marker . 167) . -1086) nil ("
" . -20) ((marker . 1) . -1) ((marker . 19) . -1) ((marker . 167) . -1) ((marker . 167) . -1) nil ("#define N 10000000000
" . 21) ((marker . 19) . -21) ((marker . 167) . -21) nil ("
" . 21) nil ("#define BITMATCH(bits1, bits2) ((bits1 & bits2) == bits2)
" . 21) ((marker . 19) . -57) ((marker . 167) . -57) (t 26046 3743 918166 72000)) (emacs-undo-equiv-table (-32 . -34) (-8 . -20) (-7 . -21) (59 . 63) (-11 . -17) (78 . 82) (-25 . -27) (60 . 62) (58 . 64) (-9 . -19) (-22 . -24) (6 . 8) (16 . 18) (-41 . -65) (56 . 58) (64 . 66) (-13 . -15) (-80 . -82) (-5 . -25) (-40 . -66) (-10 . -18) (31 . 33) (-112 . -114) (-6 . -22) (-42 . -64) (79 . 81) (-12 . -16) (-48 . -58) (-43 . -63) (-46 . -60) (-49 . -57) (-3 . -5) (-51 . -55) (-47 . -59) (-50 . -56) (-45 . -61) (-44 . -62) (-52 . -54)))