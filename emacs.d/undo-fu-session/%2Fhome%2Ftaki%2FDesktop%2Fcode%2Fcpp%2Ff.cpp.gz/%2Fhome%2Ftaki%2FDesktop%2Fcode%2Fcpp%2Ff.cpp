((buffer-size . 522) (buffer-checksum . "28230b9c2409ed6053e52573254d51bb5e7e8d0d"))
((emacs-buffer-undo-list nil (59 . 523) nil ("int rev(int n, int r = 0) {
    if (n < 10) return r*10+n;
    return rev(n/10, r*10+n%10);
}

void rev_n_add(int n, int i) {
    n += rev(n);
    i++;
    if (n == rev(n)) {
        cout << i << ' ' << n << nl;
        return;
    }
    rev_n_add(n, i);
}

void input(int n) {
    if (n <= 0) return;
    int a; cin >> a;
    rev_n_add(a, 0);
    input(n-1);
}

int main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);

    int n; cin >> n;
    input(n);
}
" . 59) ((marker . 507) . -462) ((marker . 59) . -462) ((marker . 152) . -463) ((marker . 523) . -464) ((marker . 1250) . -462) 521 nil ("
" . -1) ((marker* . 153) . 1) nil ("#define rep(i, start, end) for (int i = (start); i < (end); i++)
#define deb(x) cout << #x << \" = \" << x <<nl
#define ig(c) cin.ignore(numeric_limits<streamsize>::max(), c)
#define debarr(arr, n) {cout<<#arr<<\" = \";rep(i, 0, n) cout << arr[i] << ' ';cout<<nl;}

#include <limits>
" . 1) ((marker . 57) . -64) ((marker . 507) . -262) ((marker . 151) . -262) ((marker . 152) . -279) (t 26102 59816 885284 13000)) (emacs-pending-undo-list) (emacs-undo-equiv-table (1 . 3)))