((buffer-size . 252) (buffer-checksum . "05111b48969e706ad13167a84a2292a287faed70"))
((emacs-buffer-undo-list nil (")" . 12) ((marker) . -1) ((marker) . -1) nil ("(" . 12) ((marker) . -1) ((marker) . -1) (t 26160 26832 323907 194000) nil ("l" . 101) nil ("n" . 101) nil (57 . 59) nil ("nl" . 58) ((marker . 12) . -1) ((marker . 65) . -1) ((marker . 58) . -1) ((marker . 12) . -1) 59 nil (";" . 26) ((marker . 24) . -1) nil (26 . 27) (")" . -25) (25 . 26) (")" . -25) (25 . 26) (23 . 25) (22 . 24) (14 . 22) (")" . -13) (13 . 14) (")" . -13) (13 . 14) (12 . 14) (" \"\\n\"" . 12) ((marker . 24) . -5) ((marker . 12) . -4) ((marker . 12) . -4) ((marker . 12) . -4) (t 26160 26787 968498 248000) nil (nil fontified nil 16 . 17) (nil face font-lock-string-face 16 . 17) ("'" . -16) (17 . 18) (nil c-in-sws t 13 . 14) (t 26160 26763 810671 440000) (nil fontified t 13 . 14) (t 26160 26763 810671 440000) (nil face font-lock-string-face 13 . 14) (t 26160 26763 810671 440000) ("'" . -13) (t 26160 26763 810671 440000) (14 . 15) (t 26160 26763 810671 440000) nil (247 . 248) 58 nil (76 . 77) ("c" . 76) nil (92 . 94) nil (49 . 51) nil (13 . 14) ("\"" . 13) nil (16 . 17) ("\"" . 16) ((marker . 24) . -1) nil ("\\n" . 48) ((marker . 12) . -1) ((marker . 65) . -1) ((marker . 58) . -1) ((marker . 12) . -1) 49 nil (128 . 131) ("ll" . 128) ((marker . 12) . -1) ((marker . 12) . -1) 129 nil (186 . 189) ("ll" . 186) ((marker . 12) . -1) ((marker) . -2) ((marker) . -2) nil (13 . 14) ("'" . 13) nil (16 . 17) ("'" . 16) ((marker . 24) . -1) nil (16 . 17) ("\"" . 16) ((marker) . -1) nil (13 . 14) ("\"" . 13) ((marker) . -1) nil (";" . 17) ((marker . 24) . -1) nil (17 . 18) ("\"" . -16) (16 . 17) ("\"" . -16) (14 . 17) (13 . 15) ("\"" . -13) (3 . 14) (2 . 3) (1 . 2) 1 nil ("#FOR
" . 83) ((marker . 24) . -4) ((marker . 65) . -3) ((marker . 12) . -4) ((marker . 65) . -3) ((marker . 106) . -3) ((marker . 106) . -3) ((marker . 65) . -3) nil (nil rear-nonsticky nil 87 . 88) ("
" . -232) (87 . 233) 86 nil (84 . 87) (83 . 84) (82 . 83) 42 nil (72 . 73) ("d" . 72) nil (46 . 47) ("c" . 46) nil (46 . 47) nil ("c" . 46) nil (nil fontified nil 79 . 80) ("i" . -79) (80 . 81) (nil fontified nil 66 . 67) ("i" . -66) (67 . 68) (nil fontified nil 60 . 61) ("i" . -60) (61 . 62) (nil fontified nil 55 . 56) (nil face font-lock-variable-name-face 55 . 56) ("i" . -55) (56 . 57) (nil c-in-sws t 46 . 47) (nil fontified t 46 . 47) (nil face font-lock-preprocessor-face 46 . 47) ("i" . -46) (47 . 48) nil (55 . 56) ("c" . 55) ((marker . 12) . -1) nil (55 . 56) ("i" . 55) nil (53 . 54) nil (nil rear-nonsticky nil 41 . 42) ("
" . -81) (41 . 82) 40 nil ("
" . -41) 2 nil (41 . 42) (")" . -40) (40 . 41) (")" . -40) (40 . 41) (")" . -39) (39 . 40) (")" . -39) (39 . 40) (38 . 39) (37 . 39) ("i" . -37) ((marker . 12) . -1) 38 (36 . 38) (35 . 36) ("\"" . -34) (34 . 35) ("\"" . -34) (28 . 35) (27 . 28) (26 . 28) ("\"" . -26) (25 . 27) (24 . 25) ("\"" . -24) ((marker . 12) . -1) ("\"" . 25) ("%" . -25) ((marker . 12) . -1) ("d" . -26) ((marker . 12) . -1) 27 (25 . 27) (24 . 26) ("\"" . -24) (24 . 25) (23 . 25) (16 . 23) (")" . -15) (15 . 16) (")" . -15) (15 . 16) (14 . 15) ("i" . -14) ((marker . 12) . -1) ("n" . -15) ((marker . 12) . -1) 16 (14 . 16) (13 . 15) (3 . 13) ("include " . -3) ((marker . 24) . -8) ((marker . 65) . -7) ((marker . 65) . -7) ((marker . 12) . -8) 11 (3 . 11) (2 . 3) (1 . 2) (t . -1) 1) (emacs-pending-undo-list (72 . 73) (")" . -71) (71 . 72) (")" . -71) (71 . 72) (70 . 72) (68 . 70) (63 . 68) (t 26160 26776 777963 833000) 62 nil (62 . 63) (")" . -61) (61 . 62) (")" . -61) (61 . 62) (59 . 61) (58 . 60) (55 . 58) (50 . 55) 38 nil ("    char c = getchar();
" . 51) ((marker . 70) . -23) ((marker . 12) . -14) 65 nil (11 . 16) (10 . 12) ("\"" . -10) (10 . 11) ("\"<#" . -10) ((marker . 12) . -3) 13 ("header" . -13) ((marker . 12) . -6) 19 ("#>\"" . -19) ((marker . 17) . -3) ((marker . 12) . -3) 22 (2 . 22) ("inc" . -2) ((marker . 17) . -3) ((marker . 70) . -3) ((marker . 65) . -3) ((marker . 12) . -3) 5 (2 . 5) (1 . 2) (1 . 2) 18 nil ("
" . 19) ((marker . 12) . -1) (nil fontified nil 19 . 20) (nil face nil 19 . 20) ("#" . 20) ((marker . 17) . -1) ((marker . 12) . -1) ("deb" . 21) ((marker . 17) . -3) ((marker . 12) . -3) ("()" . 24) ((marker . 17) . -2) ((marker* . 73) . 1) nil (24 . 26) (21 . 24) (20 . 21) (nil face (rainbow-delimiters-depth-1-face font-lock-string-face) 19 . 20) (nil fontified t 19 . 20) (nil c-in-sws t 19 . 20) (19 . 20) 18 nil ("    " . 57) ((marker . 70) . -4) ((marker . 65) . -4) ("
" . -57) 37 nil ("cout" . -62) ((marker . 70) . -2) ((marker . 65) . -2) ((marker . 12) . -4) 66 (62 . 66) (57 . 62) (56 . 57) (")" . -55) (55 . 56) (")" . -55) (55 . 56) (54 . 56) (44 . 54) ("=" . -44) ((marker . 12) . -1) (" " . -45) ((marker . 12) . -1) 46 (38 . 46) ("int " . -38) ((marker . 12) . -4) 42 (38 . 42) (33 . 38) 21 nil ("    return 0;
" . 34) ((marker . 70) . -13) ((marker . 12) . -11) 45 nil ("    " . 33) ("
" . -33) 31 nil (31 . 32) ("
" . -31) 24 nil (apply yas--snippet-revive 21 55 #s(yas--snippet nil (#s(yas--field 1 30 30 nil nil nil t #s(yas--exit 38 nil))) #s(yas--exit 38 nil) 2 nil #s(yas--field 1 30 30 nil nil nil t #s(yas--exit 38 nil)) nil nil)) (" " . -30) ((marker . 12) . -1) 31 ("int argc, char *argv[]" . 31) (30 . 31) (apply yas--take-care-of-redo #s(yas--snippet nil (#s(yas--field 1 30 30 nil nil nil t #s(yas--exit 38 nil))) #s(yas--exit 38 nil) 2 nil #s(yas--field 1 30 30 nil nil nil t #s(yas--exit 38 nil)) nil nil)) (21 . 77) ("main" . 21) ((marker . 12) . -4) 25 (21 . 25) (20 . 21) 20 nil ("
" . 20) ((marker . 12) . -1) ("main" . 21) ((marker . 12) . -4) (21 . 25) ("int main(int argc, char *argv[])
{
    
    return 0;
}
" . 21) ((marker* . 73) . 17) ((marker . 12) . -38) (apply yas--snippet-revive 21 77 #s(yas--snippet nil (#s(yas--field 1 30 52 nil nil nil nil #s(yas--exit 60 nil))) #s(yas--exit 60 nil) 1 nil #s(yas--field 1 30 52 nil nil nil nil #s(yas--exit 60 nil)) nil nil)) (apply yas--take-care-of-redo #s(yas--snippet nil (#s(yas--field 1 30 52 nil nil nil nil #s(yas--exit 60 nil))) #s(yas--exit 60 nil) 1 nil #s(yas--field 1 30 52 nil nil nil nil #s(yas--exit 60 nil)) nil nil)) nil (apply yas--snippet-revive 21 77 #s(yas--snippet nil (#s(yas--field 1 30 52 nil nil nil nil #s(yas--exit 60 nil))) #s(yas--exit 60 nil) 1 nil #s(yas--field 1 30 52 nil nil nil nil #s(yas--exit 60 nil)) nil nil)) (apply yas--take-care-of-redo #s(yas--snippet nil (#s(yas--field 1 30 52 nil nil nil nil #s(yas--exit 60 nil))) #s(yas--exit 60 nil) 1 nil #s(yas--field 1 30 52 nil nil nil nil #s(yas--exit 60 nil)) nil nil)) (21 . 77) ("main" . 21) ((marker . 12) . -4) 25 (21 . 25) (20 . 21) 20 nil ("
" . 20) ((marker . 70) . -1) ((marker . 65) . -1) ((marker . 12) . -1) ("in" . 21) ((marker . 70) . -2) ((marker . 65) . -2) ((marker . 12) . -2) (21 . 23) ("main" . 21) ((marker . 12) . -4) (21 . 25) ("int main(int argc, char *argv[])
{
    
    return 0;
}
" . 21) ((marker* . 73) . 24) ((marker . 12) . -9) (apply yas--snippet-revive 21 77 #s(yas--snippet nil (#s(yas--field 1 30 30 nil nil nil t #s(yas--exit 60 nil))) #s(yas--exit 60 nil) 0 nil #s(yas--field 1 30 30 nil nil nil t #s(yas--exit 60 nil)) nil nil)) (")" . 30) (30 . 53) (")" . 30) (nil face nil 30 . 31) (30 . 31) (apply yas--take-care-of-redo #s(yas--snippet nil (#s(yas--field 1 30 30 nil nil nil t #s(yas--exit 60 nil))) #s(yas--exit 60 nil) 0 nil #s(yas--field 1 30 30 nil nil nil t #s(yas--exit 60 nil)) nil nil)) nil (apply yas--snippet-revive 21 55 #s(yas--snippet nil (#s(yas--field 1 30 30 nil nil nil t #s(yas--exit 60 nil))) #s(yas--exit 60 nil) 0 nil #s(yas--field 1 30 30 nil nil nil t #s(yas--exit 60 nil)) nil nil)) (")" . -30) (nil fontified nil 30 . 31) (nil face (rainbow-delimiters-depth-1-face) 30 . 31) (30 . 31) (")" . -30) ("int argc, char *argv[]" . 31) (30 . 31) (apply yas--take-care-of-redo #s(yas--snippet nil (#s(yas--field 1 30 30 nil nil nil t #s(yas--exit 60 nil))) #s(yas--exit 60 nil) 0 nil #s(yas--field 1 30 30 nil nil nil t #s(yas--exit 60 nil)) nil nil)) (21 . 77) ("main" . 21) ((marker . 12) . -4) 25 (21 . 25) ("i" . -21) ((marker . 70) . -1) ((marker . 65) . -1) ((marker . 12) . -1) ("n" . -22) ((marker . 70) . -1) ((marker . 65) . -1) ((marker . 12) . -1) 23 (21 . 23) (20 . 21) 20 nil ("
struct player {
    char name[100], nation[100];
    int runs[3], wickets[3], points[3];
};

void calculatepoints(struct player *p) {
    for (int i = 0; i < 3; i++) {
        p->points[i] = p->wickets[i] * 12;
        if (p->runs[i] <= 25)
            p->points[i] += 5;
        else if (p->runs[i] > 25 && p->runs[i] < 50)
            p->points[i] += 10;
        else if (p->runs[i] > 50 && p->runs[i] < 75)
            p->points[i] += 15;
        else if (p->runs[i] > 75)
            p->points[i] += 20;
    }
}

int main() {
    // Write C code here
    struct player players[2];
    for (int i = 0; i < 2; i++) {
        printf(\"Enter the details of player %d\\n\", i + 1);
        printf(\"Name: \");
        fgets(players[i].name, 100, stdin);
        printf(\"Country: \");
        fgets(players[i].nation, 100, stdin);
        printf(\"Runs: \");
        scanf(\"%d %d %d\", &players[i].runs[0], &players[i].runs[1], &players[i].runs[2]);
        printf(\"Wickets: \");
        scanf(\"%d %d %d\", &players[i].wickets[0], &players[i].wickets[1], &players[i].wickets[2]);
        while (getchar() != '\\n')
            ;
    }

    for (int i = 0; i < 2; i++)
        calculatepoints(&players[i]);

    for (int i = 0; i < 2; i++) {
        printf(\"details for player %d:\\n\", i + 1);
        printf(\"Name:%s\\n\", players[i].name);
        printf(\"Country:%s\\n\", players[i].nation);
        printf(\"Runs:%d %d %d\\n\", players[i].runs[0], players[i].runs[1],
               players[i].runs[2]);

        printf(\"wickets:%d %d %d\\n\",
               players[i].wickets[0],
               players[i].wickets[1],
               players[i].wickets[2]);

        printf(\"points:%d %d %d\\n\",
               players[i].points[0],
               players[i].points[1],
               players[i].points[2]);

        printf(\"\\n\");
    }

    return 0;
}
" . 20) ((marker . 70) . -1833) nil ("#include <string.h>
" . 20) ((marker . 17) . -19) ((marker . 70) . -19) (t 26159 58580 953500 454000)) (emacs-undo-equiv-table (19 . 23) (20 . 22) (-13 . -15) (-5 . -7) (33 . 35) (-15 . -17) (30 . 32)))