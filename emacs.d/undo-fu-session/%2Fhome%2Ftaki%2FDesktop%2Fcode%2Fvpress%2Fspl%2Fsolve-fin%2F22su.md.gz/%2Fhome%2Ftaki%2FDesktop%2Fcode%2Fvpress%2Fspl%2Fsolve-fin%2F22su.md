((buffer-size . 1746) (buffer-checksum . "3216af6efebc3cf0a63bed7aa7a87ce82c663d8e"))
((emacs-buffer-undo-list nil (1740 . 1743) (1735 . 1738) ("    " . -1709) (1703 . 1709) ("    " . -1688) (1682 . 1688) ("        " . -1680) (1671 . 1680) ("    " . -1611) (1605 . 1611) ("    " . -1581) (1575 . 1581) ("    " . -1535) (1529 . 1535) (1513 . 1516) (1490 . 1493) (1469 . 1472) nil (nil rear-nonsticky nil 1486 . 1487) ("
" . -1716) (1486 . 1717) 1469 nil (nil rear-nonsticky nil 1490 . 1491) (nil fontified nil 1490 . 1491) (nil fontified nil 1487 . 1490) (nil fontified nil 1486 . 1487) (nil fontified nil 1469 . 1486) (1469 . 1491) (1468 . 1469) (1462 . 1468) (1461 . 1462) (t 26177 221 891757 882000) 1461 nil ("
" . 1461) ((marker . 1469) . -1) ((marker . 1467) . -1) ((marker . 1461) . -1) ((marker . 1461) . -1) ((marker . 1461) . -1) ((marker . 1461) . -1) ((marker . 1461) . -1) ((marker . 1461) . -1) ((marker . 1461) . -1) ((marker . 1461) . -1) ((marker . 1461) . -1) ((marker . 1461) . -1) ((marker . 1461) . -1) ((marker . 1461) . -1) ((marker . 1461) . -1) ((marker . 1467) . -1) ((marker . 1469) . -1) ((marker . 1461) . -1) ((marker . 1461) . -1) ("()" . 1462) ((marker . 1469) . -1) ((marker . 1467) . -2) ((marker* . 1747) . 1) ((marker . 1461) . -1) ((marker . 1461) . -2) ((marker . 1461) . -2) ((marker . 1461) . -2) ((marker . 1461) . -1) ((marker . 1461) . -2) ((marker . 1461) . -2) ((marker . 1461) . -1) ((marker . 1461) . -1) ((marker . 1461) . -2) ((marker . 1461) . -2) ((marker . 1461) . -1) ((marker . 1467) . -2) ((marker . 1469) . -1) ((marker . 1461) . -1) ((marker . 1461) . -1) ("make-local-va" . 1463) ((marker . 1469) . -13) ("make-local-variable" . 1463) ((marker . 1469) . -19) ((marker . 1461) . -19) ((marker . 1461) . -19) ((marker . 1461) . -5) ((marker . 1461) . -19) ((marker . 1461) . -19) ((marker . 1461) . -19) ((marker . 1461) . -19) (1482 . 1495) (" evil-shif" . 1482) ((marker . 1469) . -1) ((marker* . 1747) . 9) ((marker . 1461) . -1) ((marker . 1461) . -1) ((marker . 1461) . -1) ((marker . 1461) . -1) ((marker . 1469) . -1) ((marker . 1461) . -1) ((marker . 1461) . -1) ("evil-shift-" . 1483) ((marker* . 1747) . 11) (1494 . 1503) ("wi" . 1494) ("evil-shift-width" . 1483) ((marker . 1469) . -15) ((marker* . 1747) . 16) ((marker . 1469) . -15) ((marker . 1461) . -15) (1499 . 1512) nil ("
" . 1500) ((marker . 1467) . -1) ((marker . 1461) . -1) ((marker . 1461) . -1) ((marker . 1461) . -1) ((marker . 1461) . -1) ((marker . 1461) . -1) ((marker . 1461) . -1) ((marker . 1467) . -1) ((marker . 1461) . -1) ("()" . 1501) ((marker . 1467) . -1) ((marker . 1461) . -1) ((marker . 1461) . -1) ((marker . 1461) . -1) ((marker . 1461) . -2) ((marker . 1461) . -1) ((marker . 1461) . -1) ((marker . 1467) . -2) ((marker . 1461) . -1) ("setq evil-s" . 1502) ((marker . 1467) . -11) ((marker . 1461) . -5) ((marker . 1461) . -5) ((marker . 1461) . -11) ((marker . 1461) . -5) ((marker . 1461) . -5) ((marker . 1461) . -5) ("h" . 1513) ((marker . 1467) . -1) ((marker . 1461) . -1) ("evil-shift-width" . 1507) ((marker . 1461) . -15) ((marker . 1461) . -15) ((marker . 1461) . -15) (1523 . 1530) (" 3" . 1523) nil ("'" . 1483) nil (1483 . 1484) nil ("'" . 1507) nil (1507 . 1508) nil (1523 . 1525) ("evil-sh" . 1523) ((marker . 1467) . -7) ((marker . 1461) . -7) ((marker . 1467) . -7) ((marker . 1469) . -7) (1507 . 1523) 1514 (1513 . 1514) (1502 . 1513) (1501 . 1503) (1500 . 1501) 1498 nil ("evil-shift-wi" . 1499) ((marker . 1467) . -13) ((marker . 1461) . -13) ((marker . 1467) . -13) ((marker . 1469) . -13) (1483 . 1499) 1496 (1494 . 1496) ("evil-shif" . 1494) ((marker . 1467) . -6) ((marker . 1461) . -9) ((marker . 1467) . -6) ((marker . 1469) . -9) (1483 . 1494) 1492 (1482 . 1492) ("make-local-va" . 1482) ((marker . 1467) . -13) ((marker . 1467) . -13) ((marker . 1469) . -13) ((marker . 1461) . -13) (1463 . 1482) 1476 (1463 . 1476) (1462 . 1464) (1461 . 1462) (t 26177 221 891757 882000) 1461 nil (1456 . 1457) (1455 . 1456) (1454 . 1455) (1448 . 1449) (1447 . 1448) (1446 . 1447) (1440 . 1441) (1439 . 1440) (1438 . 1439) (1433 . 1434) (1432 . 1433) (1431 . 1432) (1411 . 1414) nil ("
" . -1441) 1437 nil (nil rear-nonsticky nil 1441 . 1442) (nil fontified nil 1428 . 1442) (1428 . 1442) nil (1427 . 1428) 1414 nil ("c" . 1414) nil (nil rear-nonsticky nil 1432 . 1433) (nil fontified nil 1432 . 1433) (nil fontified nil 1429 . 1432) (nil fontified nil 1428 . 1429) (nil fontified nil 1411 . 1428) (1411 . 1433) (1410 . 1411) (1401 . 1410) (1399 . 1401) (1394 . 1399) (1393 . 1394) (1392 . 1393) (t 26176 65397 15045 58000) 1392 nil (1387 . 1388) (1386 . 1387) (1385 . 1386) (1361 . 1362) (1360 . 1361) (1359 . 1360) (1334 . 1335) (1333 . 1334) (1332 . 1333) (1325 . 1328) (t 26176 65388 938155 283000) nil ("
" . -1352) ("
" . -1352) 1350 nil (nil rear-nonsticky nil 1376 . 1377) (nil fontified nil 1362 . 1377) (1362 . 1377) 1361 nil ("UIU IS THE BEST" . 1353) ((marker . 1746) . -14) nil (1335 . 1336) (" " . 1335) ((marker . 1469) . -1) ((marker . 1469) . -1) ("
" . -1336) ((marker . 1469) . -1) ((marker . 1469) . -1) 1329 nil (nil rear-nonsticky nil 1369 . 1370) (nil fontified nil 1337 . 1370) (1337 . 1370) nil (1336 . 1337) 1335 nil (1337 . 1344) (1336 . 1337) 1335 nil (1329 . 1336) nil (":line-numbers" . 1329) ((marker . 1469) . -12) ((marker . 1746) . -12) ((marker . 1469) . -12) ((marker . 1332) . -12) (nil rear-nonsticky nil 1341 . 1342) nil (nil rear-nonsticky nil 1341 . 1342) (nil fontified nil 1329 . 1342) (1329 . 1342) nil (1328 . 1329) 1327 nil (":line-numbers" . 1328) ((marker . 1746) . -12) nil ("c" . 1328) nil (nil rear-nonsticky nil 1346 . 1347) (nil fontified nil 1325 . 1347) (1325 . 1347) (1324 . 1325) (1323 . 1324) (1314 . 1323) (1293 . 1314) (1286 . 1293) nil (1282 . 1286) ("s" . -1282) ((marker . 1467) . -1) ((marker . 1467) . -1) ((marker . 1469) . -1) 1283 (1270 . 1283) nil (1263 . 1266) ("   " . 1263) ((marker . 1469) . -2) ("
" . -1266) 1265 nil (1268 . 1271) (1267 . 1268) 1267 nil (1265 . 1266) (1264 . 1265) (1263 . 1264) (1258 . 1259) (1257 . 1258) (1256 . 1257) (1253 . 1254) (1252 . 1253) (1251 . 1252) (1244 . 1245) (1243 . 1244) (1242 . 1243) (1231 . 1232) (1230 . 1231) (1229 . 1230) (1199 . 1200) (1198 . 1199) (1197 . 1198) (1179 . 1180) (1178 . 1179) (1177 . 1178) (1143 . 1144) (1142 . 1143) (1141 . 1142) (1104 . 1105) (1103 . 1104) (1102 . 1103) (1057 . 1058) (1056 . 1057) (1055 . 1056) (1018 . 1019) (1017 . 1018) (1016 . 1017) (994 . 995) (993 . 994) (992 . 993) (990 . 991) (989 . 990) (988 . 989) (960 . 961) (959 . 960) (958 . 959) (917 . 918) (916 . 917) (915 . 916) (901 . 902) (900 . 901) (899 . 900) (897 . 898) (896 . 897) (895 . 896) (874 . 875) (873 . 874) (872 . 873) (852 . 853) (851 . 852) (850 . 851) (829 . 832) nil (nil rear-nonsticky nil 846 . 847) ("
" . -1201) (846 . 1202) 829 nil ("   " . 829) ((marker . 1469) . -2) ((marker . 1469) . -2) ((marker . 829) . -2) (" " . 850) (" " . 851) (" " . 852) nil (852 . 853) (851 . 852) (850 . 851) (829 . 832) nil (nil rear-nonsticky nil 850 . 851) (nil fontified nil 829 . 851) (829 . 851) (828 . 829) (824 . 828) (t 26176 63663 950690 756000) nil (824 . 825) 823 nil (822 . 824) (821 . 822) (820 . 821) 815 nil ("   " . -814) 817 (813 . 817) 812 nil (814 . 819) (t 26176 61184 485946 45000) nil (812 . 813) (811 . 812) (810 . 811) (805 . 806) (804 . 805) (803 . 804) (800 . 801) (799 . 800) (798 . 799) (751 . 752) (750 . 751) (749 . 750) (717 . 718) (716 . 717) (715 . 716) (687 . 688) (686 . 687) (685 . 686) (669 . 670) (668 . 669) (667 . 668) (653 . 654) (652 . 653) (651 . 652) (649 . 650) (648 . 649) (647 . 648) (644 . 645) (643 . 644) (642 . 643) (623 . 624) (622 . 623) (621 . 622) (614 . 615) (613 . 614) (612 . 613) (575 . 576) (574 . 575) (573 . 574) (538 . 539) (537 . 538) (536 . 537) (516 . 517) (515 . 516) (514 . 515) (470 . 471) (469 . 470) (468 . 469) (466 . 467) (465 . 466) (464 . 465) (461 . 462) (460 . 461) (459 . 460) (452 . 453) (451 . 452) (450 . 451) (418 . 419) (417 . 418) (416 . 417) (383 . 384) (382 . 383) (381 . 382) (346 . 347) (345 . 346) (344 . 345) (294 . 295) (293 . 294) (292 . 293) (290 . 291) (289 . 290) (288 . 289) (268 . 269) (267 . 268) (266 . 267) (245 . 248) nil (nil rear-nonsticky nil 262 . 263) ("
" . -730) (262 . 731) 245 nil (nil rear-nonsticky nil 266 . 267) (nil fontified nil 245 . 267) (245 . 267) (244 . 245) (238 . 244) (237 . 238) (t 26176 60399 119369 617000) 237 nil (216 . 229) (210 . 216) (189 . 210) ("-" . -189) ("-" . -190) 191 (190 . 191) ("-" . -190) (" " . -191) 192 (188 . 192) ("/" . -188) ("/" . -189) (" " . -190) 191 (187 . 191) nil (" " . 188) (" " . 183) (" " . 178) (" " . 173) (" " . 168) (" " . 163) (" " . 157) (" " . 151) (" " . 145) (" " . 139) (" " . 133) (" " . 128) (" " . 123) (" " . 118) (" " . 113) (" " . 93) 212 nil (203 . 207) (197 . 201) (191 . 195) (185 . 189) (179 . 183) (173 . 177) (166 . 170) (159 . 163) (152 . 156) (145 . 149) (138 . 142) (132 . 136) (126 . 130) (120 . 124) (114 . 118) (93 . 97) nil (nil rear-nonsticky nil 141 . 142) (nil fontified nil 110 . 142) (110 . 142) nil (109 . 110) 95 nil ("    return 0;
" . 110) 114 nil (68 . 74) ("Fall" . 68) nil ("c" . 94) nil (nil rear-nonsticky nil 112 . 113) ("
" . -122) (108 . 123) 91 nil (nil rear-nonsticky nil 112 . 113) (nil fontified nil 91 . 113) (91 . 113) (90 . 91) (81 . 90) (80 . 81) 80 nil (78 . 79) ("1" . 78) nil (80 . 81) (79 . 80) 74 nil (74 . 79) (73 . 74) 73 nil ("
## 02

1. output
   ```:line-numbers
   12 0 0 
   12 24 24 
   24 24 24
   ```

2. WAP
   ```c:line-numbers
   #include <stdio.h>

   void additems(int items[], int add[], int n) {
      for (int i = 0; i < n; i++)
         items[i] += add[i];
   }

   void openDoor(char password[]) {
      char *p = \"Narnia\";
      for (; *p == *password && *p; p++, password++);

      if (*p != *password)
         puts(\"There is no door.\");
      else
         puts(\"Door to Narnia is open.\");
   }

   int main() {
      int items[1000], add[1000];
      int n; scanf(\"%d\", &n);
      for (int i = 0; i < n; i++)
         scanf(\"%d\", items+i);
      for (int i = 0; i < n; i++)
         scanf(\"%d\", add+i);
      additems(items, add, 1000);

      char pass[100]; scanf(\"%[^\\n]\", pass);
      openDoor(pass);
   }
   ```


## 03

1. output
   ```c:line-numbers
   Hello World
   ProgrammingHell
   ProgrammingHellHel
   ```

2. WAP
   ```c:line-numbers
   #include <stdio.h>

   int main() {
      char str[100], sub[100];
      scanf(\"%[^\\n]%*c\", str);
      scanf(\"%[^\\n]%*c\", sub);

      for (char *s = str; *s; s++) {
         if (*s == *sub) {
               char *a = s+1, *b = sub+1;
               for (;*a == *b && *b; a++, b++)
                  ;
               if (*b == '\\0') {
                  puts(\"Substring matches\");
                  return 0;
               }
         }
      }

      puts(\"Substring does not match\");
   }
   ```


## 04

```c:line-numbers
#include <stdio.h>

typedef struct {
    char name[50];
    int id;
    float marks[5];
} student;

int main() {
    student ar[50];
    for (int i = 0; i < 50; i++) {
        scanf(\" %[^\\n]\", ar[i].name);
        scanf(\"%d\", &ar[i].id);
        float total = 0;
        for (int j = 0; j < 5; j++) {
            scanf(\"%f\", &ar[i].marks[j]);
            total += ar[i].marks[j];
        }
    }

    for (int j = 0; j < 5; j++) {
        float max = 0;
        int k = 0;
        for (int i = 0; i < 50; i++)
            if (ar[i].marks[j] > max) {
                max = ar[i].marks[j];   
                k = i;
            }

        puts(ar[k].name);
    }
}
```


## 05

1. output
   ```:line-numbers
   5
   13
   19
   ```

2. WAP
   ```c:line-numbers
   #include <stdio.h>

   int main() {
       FILE *fptr = fopen(\"Sample.txt\", \"r\");
       int ar[100], n = 0;
       for (; fscanf(fptr, \"%d\", ar+n) != EOF; n++)
           ;
       fclose(fptr);

       fptr = fopen(\"Output.txt\", \"w\");
       for (int i = 0; i < n; i++)
           if (ar[i] % 2 == 0)
               fprintf(fptr, \"%d\\n\", ar[i]);
       fclose(fptr);
   }
   ```
" . 73) nil ("
" . -1) nil (1 . 2689) (t . -1)) (emacs-pending-undo-list (224 . 233) (220 . 224) ("printf(\"%d\\n\", " . 220) ((marker . 18) . -14) ((marker . 234) . -14) ((marker . 247) . -14) ((marker . 1469) . -14) ((marker) . -14) ((marker) . -15) ((marker) . -15) ((marker) . -15) 234 (t 26177 508 473572 59000) nil (216 . 249) nil (214 . 215) nil ("
" . -214) 197 nil ("    printf(\"%d\\n\", ar[count/2]);
" . 216) ((marker . 18) . -26) ((marker . 233) . -33) ((marker . 233) . -33) ((marker . 234) . -33) ((marker . 247) . -32) ((marker* . 233) . 1) ((marker . 246) . -33) ((marker . 246) . -33) ((marker . 246) . -33) ((marker . 246) . -33) ((marker . 246) . -33) ((marker . 246) . -33) ((marker . 246) . -33) ((marker . 246) . -33) ((marker . 246) . -33) ((marker . 246) . -33) (t 26177 508 473572 59000) nil (247 . 248) nil (244 . 245) (243 . 244) (238 . 243) (234 . 239) (233 . 234) ("\"" . -232) (232 . 233) ("\"" . -232) (228 . 233) (227 . 229) ("\"" . -227) (227 . 228) (226 . 228) (220 . 226) (216 . 220) ("    " . 215) ((marker . 1469) . -4) (219 . 220) (214 . 219) 204 nil ("
    " . 196) ((marker . 18) . -1) ((marker . 1469) . -5) ((marker . 196) . -1) (197 . 201) nil ("    " . -197) ((marker . 1469) . -4) 201 (196 . 201) 194 nil (186 . 195) nil (186 . 187) (")" . -185) (185 . 186) (")" . -185) (185 . 186) (181 . 185) ("]" . -180) (180 . 181) ("]" . -180) (178 . 181) (173 . 178) ("cou" . -173) ((marker . 1469) . -3) 176 (173 . 176) ("i" . -173) ((marker . 1469) . -1) 174 (173 . 174) (169 . 174) nil (110 . 111) ("]" . -109) (109 . 110) ("]" . -109) (106 . 110) (102 . 107) nil (112 . 113) (99 . 112) (94 . 99) 93 nil ("
        " . 142) ((marker . 18) . -1) ((marker . 1469) . -9) ((marker . 186) . -1) ((marker . 186) . -1) (143 . 151) nil ("        " . -143) ((marker . 1469) . -8) 151 (142 . 151) 141 nil (" " . 141) ((marker . 169) . -1) ((marker . 169) . -1) ((marker . 169) . -1) ((marker . 169) . -1) ((marker . 169) . -1) ((marker . 169) . -1) ((marker . 169) . -1) ((marker . 169) . -1) ((marker . 169) . -1) ((marker . 169) . -1) ((marker . 169) . -1) ((marker . 169) . -1) ((marker . 169) . -1) ((marker . 169) . -1) ((marker . 169) . -1) ((marker . 169) . -1) ((marker . 169) . -1) ((marker) . -1) ((marker) . -1) nil (")" . -142) (142 . 143) (")" . -142) (142 . 143) (141 . 142) (140 . 141) (137 . 140) (135 . 137) ("+" . -135) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 1469) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker) . -1) (" " . -136) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 1469) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker) . -1) ("E" . -137) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 1469) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker . 163) . -1) ((marker) . -1) 138 (133 . 138) (")" . -132) (132 . 133) (")" . -132) (132 . 133) (129 . 132) (128 . 129) ("\"" . -127) (127 . 128) ("\"" . -127) (125 . 128) (124 . 126) ("\"" . -124) (123 . 125) (122 . 123) (118 . 122) ("\"" . -118) ((marker . 1469) . -1) ("\"" . 119) ("%" . -119) ((marker . 1469) . -1) 120 (119 . 120) (118 . 120) ("\"" . -118) (118 . 119) (117 . 119) (110 . 117) (109 . 110) (" " . -109) ((marker . 1469) . -1) 110 (109 . 110) (" " . -109) ((marker . 1469) . -1) 110 (109 . 110) (" " . -109) ((marker . 1469) . -1) (" " . -110) ((marker . 1469) . -1) ("=" . -111) ((marker . 1469) . -1) 112 (104 . 112) ("itn " . -104) ((marker . 1469) . -4) 108 ("i " . -108) ((marker . 1469) . -2) 110 (104 . 110) (103 . 105) (99 . 103) (94 . 99) 67 nil (111 . 112) (")" . -110) (110 . 111) (")" . -110) (110 . 111) (106 . 110) (105 . 107) (99 . 105) (94 . 99) (93 . 94) (")" . -92) (92 . 93) (")" . -92) (92 . 93) ("\"" . -91) (91 . 92) ("\"" . -91) (90 . 92) (89 . 91) ("\"" . -89) (89 . 90) (88 . 89) (87 . 88) ("\"" . -86) (86 . 87) ("\"" . -86) (84 . 87) (75 . 84) (74 . 76) ("\"" . -74) (74 . 75) (73 . 75) (61 . 73) (60 . 61) (55 . 60) (50 . 55) 38 nil ("    int arr[] = {2, 3, 6, 7, 11, 8};
    f1(arr, 6);
" . 51) ((marker . 18) . -37) ((marker . 233) . -37) ((marker . 247) . -52) ((marker . 246) . -37) ((marker . 246) . -37) ((marker . 246) . -37) ((marker . 246) . -37) ((marker . 246) . -37) ((marker . 246) . -37) ((marker . 246) . -37) ((marker . 246) . -37) ((marker . 246) . -37) ((marker) . -53) nil ("
void f1(int *arr, int n) {
    for (int i = 0; i < n; i++) {
        if (*(arr + i) % 2 != 0) {
            printf(\"-%d-\\n\", *(arr + i) + i * 2);
        }
    }
}
" . 37) ((marker . 18) . -163) ((marker . 18) . -165) ((marker . 233) . -163) ((marker . 247) . -164) ((marker . 37) . -1) ((marker . 37) . -165) ((marker . 37) . -163) ((marker . 37) . -163) ((marker . 37) . -163) ((marker . 37) . -163) ((marker . 1467) . -165) ((marker . 37) . -163) ((marker . 37) . -163) ((marker . 37) . -163) ((marker . 37) . -163) ((marker . 37) . -163) ((marker) . -165) (t 26177 197 586565 508000) nil (201 . 202) (t 26176 65462 279359 24000) 200 nil (62 . 256) ("{
for (int i = 0; i < n; i++) {
if (*(arr + i) % 2 != 0) {
printf(\"-%d-\\n\", *(arr + i)+i*2);
}
}
}
int main(){
int arr[] = {2, 3, 6, 7, 11, 8};
" . 62) (t 26176 65460 399347 733000) nil (219 . 220) 37 nil (nil rear-nonsticky nil 218 . 219) (nil fontified nil 39 . 219) (nil fontified nil 38 . 39) (38 . 219) nil (37 . 38) 37 nil ("#include <string.h>

void strrev(char *s) {
    int len = strlen(s);
    for (int i = 0; i < len/2; i++) {
        char tmp = s[i];
        s[i] = s[len-1 - i];
        s[len-1 - i] = tmp;
    }
}

int main() {
    char str1[50] = {'\\0'}, str2[50] = \"BEST\";

    strcpy(str1, \"HELLO FELLAS\");

    int i = strlen(str1) * 0.5;

    for (int k = 0; str2[k] != '\\0'; ++k)
        str1[i + k] = str2[k];

    strrev(str1);
    strcat(str1, str2);

    if (strcmp(str2, str1) > 0) {
        strcpy(str1, \"CSE IS EASY\");
    } else {
        strcpy(str2, \"UIU IS THE BEST\");
    }
    puts(str1);
    puts(str2);
}
" . 37) ((marker . 18) . -591) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -19) ((marker . 1) . -21) ((marker . 18) . -591) ((marker . 233) . -607) ((marker* . 235) . 2) ((marker . 233) . -607) ((marker . 234) . -607) ((marker . 247) . -608) ((marker* . 233) . 421) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker*) . 1) ((marker) . -608) ((marker . 37) . -198) ((marker . 37) . -198) ((marker . 37) . -198) ((marker . 37) . -198) ((marker . 37) . -198) ((marker . 37) . -198) ((marker . 37) . -198) ((marker . 37) . -198) ((marker . 37) . -198) ((marker . 37) . -198) ((marker . 37) . -198) ((marker . 37) . -198) ((marker . 37) . -198) ((marker . 37) . -608) ((marker . 37) . -228) ((marker . 37) . -228) ((marker . 37) . -228) ((marker . 37) . -228) ((marker . 37) . -228) ((marker . 37) . -228) ((marker . 37) . -228) ((marker . 37) . -228) ((marker . 37) . -228) ((marker . 37) . -228) ((marker . 37) . -228) ((marker . 37) . -228) ((marker . 37) . -228) ((marker . 37) . -228) ((marker . 37) . -228) ((marker . 37) . -228) ((marker . 37) . -228) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -608) ((marker . 37) . -401) ((marker . 37) . -21) ((marker . 37) . -21) ((marker . 37) . -607) ((marker . 37) . -607) ((marker . 37) . -187) ((marker . 37) . -607) ((marker . 37) . -189) ((marker . 37) . -189) ((marker . 37) . -591) ((marker . 37) . -591) ((marker . 37) . -591) ((marker . 37) . -591) ((marker . 37) . -591) ((marker . 37) . -591) ((marker . 37) . -591) ((marker . 37) . -591) ((marker . 1467) . -591) (t 26176 65295 789724 891000) nil ("
" . -644) ((marker . 18) . -1) ((marker . 233) . -1) ((marker . 233) . -1) ((marker . 234) . -1) ((marker . 18) . -1) ((marker . 247) . -1) ((marker . 37) . -1) ((marker . 37) . -1) nil ("    char s[] = \"HELLO\";
    puts(s);
    strrev(s);
" . 645) ((marker . 18) . -37) ((marker . 233) . -37) ((marker . 247) . -51) ((marker . 37) . -15) ((marker . 37) . -24) nil ("    puts(s);
" . 697) ((marker . 247) . -12) ((marker . 1469) . -11) 708 (t 26176 65290 239227 591000) nil (224 . 225) (218 . 224) ("]" . -217) (217 . 218) ("]" . -217) (208 . 218) (206 . 209) (197 . 206) 192 nil (167 . 168) ("]" . -166) (166 . 167) ("]" . -166) (165 . 167) (152 . 166) (143 . 152) 119 nil (173 . 177) ("        " . 173) ((marker . 1469) . -8) (181 . 182) ("}" . -181) (181 . 182) (172 . 181) 171 nil ("}" . 143) ((marker* . 233) . 1) nil (142 . 144) (141 . 142) (t 26176 65266 380086 412000) nil ("    strrev(s);
" . 608) ((marker . 18) . -4) ((marker . 18) . -4) ((marker . 247) . -14) ((marker* . 233) . 1) ((marker . 1467) . -4) ((marker . 1469) . -4) 612 nil (nil rear-nonsticky nil 654 . 655) ("
" . -663) (650 . 664) 640 nil (nil rear-nonsticky nil 639 . 640) ("
" . -650) (635 . 651) 634 nil (621 . 622) nil (nil rear-nonsticky nil 620 . 621) (nil fontified nil 612 . 621) (612 . 621) 611 nil ("p" . -612) ((marker . 18) . -1) ((marker . 1467) . -1) ((marker . 1469) . -1) 613 (612 . 613) (607 . 612) 593 nil (617 . 618) nil ("strrev(s)" . 617) ((marker . 18) . -8) ((marker . 247) . -8) ((marker* . 233) . 1) ((marker . 1467) . -8) ((marker . 1469) . -1) 618 nil (624 . 625) nil (606 . 607) nil (nil rear-nonsticky nil 605 . 606) (nil fontified nil 599 . 606) (599 . 606) 598 nil ("\"HELLO\"" . 616) ((marker . 247) . -6) nil ("0" . 595) nil ("1" . 595) nil (598 . 601) ("]" . -597) (597 . 598) ("]" . -597) (595 . 598) (588 . 596) (583 . 588) (t 26176 65239 866593 226000) 583 nil (609 . 610) nil (601 . 606) (600 . 602) ("\"" . -600) (600 . 601) (599 . 601) (593 . 599) (592 . 594) (588 . 592) (584 . 588) ("    " . 583) ((marker . 1469) . -4) (587 . 588) (582 . 587) (t 26176 65196 918808 749000) 579 nil (579 . 580) ("1" . 579) nil (nil rear-nonsticky nil 570 . 571) ("
" . -582) (566 . 583) 565 nil (565 . 566) (")" . -564) (564 . 565) (")" . -564) (564 . 565) (560 . 564) (559 . 561) (555 . 559) (550 . 555) (t 26176 65188 633603 804000) 549 nil (169 . 170) nil (" " . 163) nil (" " . 162) nil (165 . 170) (159 . 165) (154 . 160) ("]" . -153) (153 . 154) ("]" . -153) (152 . 154) (151 . 153) ("t" . -151) ((marker . 18) . -1) ((marker . 1467) . -1) ((marker . 1469) . -1) 152 (150 . 152) (141 . 150) (")" . -140) (140 . 141) (")" . -140) (140 . 141) (136 . 140) (135 . 136) (134 . 135) (133 . 134) (130 . 133) ("n" . -130) ((marker . 1469) . -1) ("/" . -131) ((marker . 1469) . -1) ("2" . -132) ((marker . 1469) . -1) 133 (132 . 133) (131 . 132) (125 . 131) (124 . 125) (115 . 124) (114 . 116) (110 . 114) (105 . 110) (104 . 105) (")" . -103) (103 . 104) (")" . -103) (103 . 104) (102 . 103) (101 . 103) (99 . 101) ("n" . -99) ((marker . 1469) . -1) ("e" . -100) ((marker . 1469) . -1) 101 (85 . 101) (81 . 85) (80 . 82) (79 . 81) (78 . 79) (")" . -77) (77 . 78) (")" . -77) (77 . 78) (76 . 77) (75 . 76) (70 . 75) ("i" . -70) ((marker . 18) . -1) ((marker . 1467) . -1) ((marker . 1469) . -1) ("n" . -71) ((marker . 18) . -1) ((marker . 1467) . -1) ((marker . 1469) . -1) ("t" . -72) ((marker . 1469) . -1) 73 (70 . 73) (69 . 71) (58 . 69) nil ("
" . 58) ((marker . 18) . -1) ((marker . 1469) . -1) ((marker . 37) . -1) nil (58 . 59) 58 nil (57 . 58) (nil face font-lock-string-face 56 . 57) (nil fontified t 56 . 57) (nil c-in-sws t 56 . 57) (56 . 57) (t 26176 65144 80905 903000) 55 nil (409 . 410) ("“" . 409) nil (425 . 426) ("\"" . 425) ((marker) . -1) (t 26176 64838 757374 979000) nil ("    " . -118) ((marker . 1469) . -4) 122 (117 . 122) 71 nil ("    " . -152) ((marker . 1469) . -4) 156 (151 . 156) 118 nil ("    " . -184) ((marker . 1469) . -4) 188 (183 . 188) 152 nil ("    " . -257) ((marker . 1469) . -4) 261 (256 . 261) 226 nil ("    " . -299) ((marker . 1469) . -4) 303 (298 . 303) 275 nil ("    " . -391) (383 . 391) (t 26176 64797 462408 22000) nil (88 . 426) ("={'\\0'}, str2[50]=\"BEST\";
    strcpy(str1, \"HELLO FELLAS\");
    int i= strlen(str1) * 0.5;
    for(int k=0; str2[k] != '\\0'; ++k)
    str1[i+k]=str2[k];
    strrev(str1);
    strcat(str1, str2);
    if(strcmp(str2, str1)>0){
    strcpy(str1, \"CSE IS EASY\");
    }else{
    strcpy(str2, “UIU IS THE BEST\");
    }

    " . 88) ((marker*) . 15) ((marker . 37) . -312) ((marker . 37) . -312) ((marker . 37) . -312) ((marker . 37) . -312) ((marker . 37) . -312) ((marker . 37) . -312) ((marker . 37) . -312) ((marker . 37) . -312) ((marker . 37) . -312) ((marker . 37) . -312) ((marker . 37) . -312) ((marker . 37) . -312) ((marker . 37) . -312) ((marker . 37) . -312) ((marker . 37) . -312) ((marker . 37) . -312) ((marker . 37) . -312) ((marker . 1467) . -313) ((marker . 1469) . -313) (t 26176 64790 199291 436000) nil (406 . 407) 55 nil (apply yas--snippet-revive 37 56 #s(yas--snippet nil nil nil 2 nil nil nil nil)) (apply yas--take-care-of-redo #s(yas--snippet nil nil nil 2 nil nil nil nil)) (37 . 56) ("str" . 37) ((marker . 18) . -3) ((marker . 1467) . -3) ((marker . 1469) . -3) 40 (37 . 40) ("struct" . -37) ((marker . 1469) . -6) 43 (37 . 43) ("str" . -37) ((marker . 18) . -3) ((marker . 1467) . -3) ((marker . 1469) . -3) 40 (37 . 40) (36 . 37) (apply yas--snippet-revive 18 36 #s(yas--snippet nil nil nil 1 nil nil nil nil)) (apply yas--take-care-of-redo #s(yas--snippet nil nil nil 1 nil nil nil nil)) (18 . 36) ("io" . 18) ((marker . 18) . -1) ((marker . 1467) . -1) ((marker . 1469) . -2) 20 (18 . 20) (17 . 18) 1 nil ("
" . 17) ((marker . 18) . -1) ((marker . 18) . -1) ((marker . 1467) . -1) ((marker . 1469) . -1) ((marker . 17) . -1) ("#" . 18) ((marker . 18) . -1) ((marker . 37) . -1) ((marker . 18) . -1) ((marker . 1467) . -1) ((marker . 1469) . -1) ((marker . 17) . -1) ("inc" . 19) ((marker . 37) . -3) ((marker . 18) . -3) ((marker . 1467) . -3) ((marker . 1469) . -3) (19 . 22) ("include \"<#header#>\"" . 19) ((marker . 18) . -8) ((marker . 37) . -20) ((marker . 1469) . -8) ((marker . 17) . -8) (28 . 39) nil ("<" . -28) ((marker . 1469) . -1) ("#" . -29) ((marker . 1469) . -1) ("h" . -30) ((marker . 1469) . -1) ("e" . -31) ((marker . 1469) . -1) ("a" . -32) ((marker . 1469) . -1) ("d" . -33) ((marker . 1469) . -1) ("e" . -34) ((marker . 1469) . -1) ("r" . -35) ((marker . 1469) . -1) ("#" . -36) ((marker . 1469) . -1) (">" . -37) ((marker . 1469) . -1) ("\"" . -38) ((marker . 37) . -1) ((marker . 1469) . -1) 39 (19 . 39) ("inc" . -19) ((marker . 37) . -3) ((marker . 18) . -3) ((marker . 1467) . -3) ((marker . 1469) . -3) 22 (19 . 22) (18 . 19) (17 . 18) 1 nil (362 . 366) ("    " . -361) ((marker . 37) . -4) ((marker . 37) . -4) ((marker . 37) . -4) ((marker . 37) . -4) ((marker . 37) . -4) ((marker . 37) . -4) ((marker . 37) . -4) ((marker . 37) . -4) ((marker . 37) . -3) ((marker . 37) . -3) ((marker . 37) . -3) ((marker . 37) . -3) ((marker . 37) . -3) ((marker . 37) . -3) ((marker . 37) . -3) ((marker . 37) . -3) ((marker . 37) . -3) (355 . 359) (318 . 322) (307 . 311) (274 . 278) (244 . 248) (220 . 224) (202 . 206) (179 . 183) (140 . 144) (109 . 113) (75 . 79) (32 . 36) nil (nil rear-nonsticky nil 31 . 32) ("
" . -312) (31 . 313) 19 nil ("
char str1[50]={'\\0'}, str2[50]=\"BEST\";
strcpy(str1, \"HELLO FELLAS\");
int i= strlen(str1) * 0.5;
for(int k=0; str2[k] != '\\0'; ++k)
str1[i+k]=str2[k];
strrev(str1);
strcat(str1, str2);
if(strcmp(str2, str1)>0){
strcpy(str1, \"CSE IS EASY\");
}else{
strcpy(str2, “UIU IS THE BEST\");
}" . 38) ((marker . 18) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 18) . -1) ((marker . 233) . -1) ((marker . 233) . -1) ((marker . 234) . -1) ((marker . 18) . -1) ((marker . 247) . -280) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker*) . 5) ((marker) . -280) ((marker . 37) . -15) ((marker) . -1) ((marker) . -4) ((marker . 37) . -4) ((marker . 37) . -4) ((marker . 37) . -4) ((marker . 37) . -4) ((marker . 1467) . -1) ((marker . 1469) . -4) ((marker . 37) . -4) ((marker . 37) . -4) ((marker . 37) . -4) ((marker . 37) . -4) ((marker . 37) . -4) ((marker) . -281) 42 nil (apply yas--snippet-revive 19 38 #s(yas--snippet nil nil #s(yas--exit 36 nil) 0 nil nil nil nil)) (apply yas--take-care-of-redo #s(yas--snippet nil nil #s(yas--exit 36 nil) 0 nil nil nil nil)) (19 . 38) ("main()" . 19) ((marker . 37) . -6) ((marker . 37) . -6) ((marker . 37) . -6) ((marker . 37) . -6) ((marker . 37) . -6) ((marker . 37) . -6) ((marker . 37) . -6) ((marker . 37) . -6) ((marker . 1469) . -6) ((marker . 37) . -6) ((marker . 37) . -6) ((marker . 37) . -6) ((marker . 37) . -6) ((marker . 37) . -6) ((marker) . -6) 25 (")" . -24) (24 . 25) (")" . -24) (24 . 25) (23 . 25) (19 . 23) (18 . 19) (17 . 18) 1 nil (nil rear-nonsticky nil 297 . 298) (nil fontified nil 297 . 298) (nil fontified nil 296 . 297) (nil fontified nil 294 . 296) (nil fontified nil 293 . 294) (nil fontified nil 19 . 293) (nil fontified nil 18 . 19) (18 . 298) nil ("#include <stdio.h>
#include <string.h>

int main() {
    char str[50]; scanf(\"%[^\\n]\", str);
    int len = strlen(str);

    putchar(str[0]);
    for (int i = 1; i < len; i++) {
        if (strchr(\"aeiouAEIOU\", str[i])) {
            if (str[i] != str[i-1])
                putchar(str[i]);
        } else {
            putchar(str[i]);
        }
    }
}
" . 18) ((marker . 37) . -353) ((marker . 37) . -353) ((marker . 37) . -353) ((marker . 37) . -353) ((marker . 37) . -353) ((marker . 37) . -353) ((marker . 37) . -353) ((marker . 37) . -39) ((marker . 37) . -39) ((marker . 37) . -39) ((marker . 37) . -18) ((marker . 233) . -238) ((marker* . 235) . 99) ((marker . 233) . -238) ((marker . 234) . -238) ((marker . 247) . -354) ((marker* . 233) . 178) ((marker . 37) . -52) ((marker . 37) . -52) ((marker . 37) . -52) ((marker . 37) . -52) ((marker . 37) . -353) ((marker . 37) . -353) ((marker . 37) . -353) ((marker . 37) . -353) ((marker . 37) . -207) ((marker . 37) . -320) ((marker . 37) . -320) ((marker . 37) . -320) ((marker . 37) . -320) ((marker . 37) . -320) ((marker . 37) . -320) ((marker . 37) . -320) ((marker . 37) . -320) ((marker . 37) . -320) ((marker . 37) . -320) ((marker . 37) . -320) ((marker . 37) . -320) ((marker . 37) . -320) ((marker . 37) . -320) ((marker . 37) . -320) ((marker . 37) . -320) ((marker . 37) . -320) ((marker . 37) . -238) ((marker . 37) . -336) ((marker . 37) . -238) ((marker . 37) . -238) ((marker . 37) . -237) ((marker . 37) . -237) ((marker . 37) . -289) ((marker . 37) . -289) ((marker . 37) . -219) ((marker . 37) . -219) ((marker . 37) . -299) ((marker . 37) . -299) ((marker . 37) . -299) ((marker . 37) . -345) ((marker . 37) . -345) ((marker . 37) . -305) ((marker . 37) . -305) ((marker . 37) . -177) ((marker . 37) . -177) ((marker . 37) . -142) ((marker . 37) . -142) (t 26176 64701 395726 157000) nil ("
        " . 195) ((marker* . 233) . 9) (196 . 204) nil ("
        " . 195) ((marker . 18) . -9) ((marker . 18) . -9) ((marker . 1467) . -9) ((marker . 1469) . -9) ((marker . 37) . -9) ("swi" . 204) ((marker . 18) . -1) ((marker . 1467) . -1) ((marker . 1469) . -3) (204 . 207) ("if " . 204) ((marker . 18) . -2) ((marker . 18) . -1) ((marker . 1467) . -1) ((marker . 1469) . -2) ((marker . 37) . -2) nil (204 . 207) ("s" . -204) ((marker . 18) . -1) ((marker . 1467) . -1) ((marker . 1469) . -1) ("w" . -205) ((marker . 1469) . -1) ("i" . -206) ((marker . 1469) . -1) 207 (204 . 207) (195 . 204) 160 nil ("        " . -196) ((marker . 1469) . -8) 204 (195 . 204) (t 26176 64701 395726 157000) 174 nil (323 . 325) nil (353 . 363) nil (317 . 318) nil (317 . 318) nil (237 . 239) nil ("
        " . 306) (307 . 315) (t 26176 64684 881560 633000) nil ("        " . -307) ((marker . 1469) . -8) 315 (306 . 315) 305 nil (" {" . 237) ((marker . 247) . -1) nil (" " . 317) nil ("}" . 317) nil ("        }
" . 353) ((marker . 247) . -9) ((marker . 1469) . -8) 361 nil (" {" . 323) ((marker . 247) . -1) (t 26176 64659 156245 757000) nil (263 . 264) ("=" . 263) nil (270 . 273) (262 . 271) ("]" . -261) (261 . 262) ("]" . -261) (260 . 262) (256 . 261) ("strchr(\"aeiouAEIOU\", str[i-1]) == NULL" . 256) ((marker . 18) . -38) ((marker . 233) . -21) ((marker* . 235) . 9) ((marker . 233) . -21) ((marker . 234) . -21) ((marker . 247) . -37) ((marker . 37) . -8) ((marker . 37) . -38) (t 26176 64606 152101 565000) nil (" &&" . 294) ((marker . 18) . -2) ((marker . 1469) . -2) ((marker . 37) . -2) nil (294 . 297) (t 26176 64606 152101 565000) nil (75 . 79) ("int" . 75) ((marker . 247) . -2) (t 26176 64589 288493 999000) nil (369 . 370) (365 . 370) ("*s" . 365) ((marker . 247) . -1) ((marker . 1469) . -1) 366 nil (323 . 324) (319 . 324) ("*s" . 319) ((marker . 247) . -1) ((marker) . -2) ((marker) . -2) nil (280 . 283) (276 . 281) ("*(s-1)" . 276) ((marker . 18) . -5) ((marker . 234) . -5) ((marker . 247) . -5) ((marker . 1469) . -5) 281 nil (176 . 177) ("0" . 176) nil (232 . 233) (228 . 233) ("[" . -228) ((marker . 18) . -1) ((marker . 1467) . -1) ((marker . 1469) . -1) ("]" . 229) ("s" . -229) ((marker . 18) . -1) ((marker . 1467) . -1) ((marker . 1469) . -1) ("t" . -230) ((marker . 18) . -1) ((marker . 1467) . -1) ((marker . 1469) . -1) ("r" . -231) ((marker . 18) . -1) ((marker . 1467) . -1) ((marker . 1469) . -1) 232 (229 . 232) (228 . 230) ("*s" . 228) ((marker . 18) . -1) ((marker . 234) . -1) ((marker . 247) . -1) ((marker . 1469) . -1) 229 nil (187 . 191) (186 . 187) (184 . 186) ("n" . -184) ((marker . 1469) . -1) ("e" . -185) ((marker . 1469) . -1) (";" . -186) ((marker . 1469) . -1) 187 (186 . 187) (178 . 186) (177 . 178) (168 . 177) ("char *s = str[1]; *s; s++" . 168) ((marker . 247) . -24) ((marker . 1469) . -10) 178 nil (nil rear-nonsticky nil 141 . 142) ("
" . -158) (137 . 159) nil ("    putchar(str[0]);
" . 110) ((marker . 247) . -20) ((marker . 1469) . -19) 129 nil (156 . 157) (")" . -155) (155 . 156) (")" . -155) (155 . 156) (152 . 155) ("const char *s" . 152) (145 . 166) ("strle" . -145) ((marker . 18) . -5) ((marker . 1467) . -5) ((marker . 1469) . -5) 150 (135 . 150) (130 . 135) 127 nil ("&" . 151) (t 26176 64532 29462 79000) nil ("        " . -323) ((marker . 37) . -8) ((marker . 37) . -8) ((marker . 37) . -8) ((marker . 37) . -8) ((marker . 37) . -8) ((marker . 37) . -8) ((marker . 37) . -8) ((marker . 37) . -8) ((marker . 37) . -8) ((marker . 37) . -8) ((marker . 37) . -8) ((marker . 37) . -8) ((marker . 37) . -8) ((marker . 37) . -8) ((marker . 37) . -8) ((marker . 37) . -8) ((marker . 37) . -8) ((marker . 1469) . -8) (311 . 323) 319 nil (340 . 341) ("}" . -340) (340 . 341) (331 . 340) 326 nil ("}" . 310) ((marker* . 233) . 1) nil ("else" . 308) ((marker . 18) . -4) ((marker . 1467) . -4) (304 . 308) 310 (309 . 311) (308 . 309) ("else" . 308) ((marker . 18) . -4) ((marker . 1467) . -4) ((marker . 1469) . -4) (304 . 308) 308 (303 . 308) nil ("            " . -312) ((marker . 37) . -12) ((marker . 37) . -12) ((marker . 37) . -12) ((marker . 37) . -12) ((marker . 37) . -12) ((marker . 37) . -12) ((marker . 37) . -12) ((marker . 37) . -12) ((marker . 37) . -12) ((marker . 37) . -12) ((marker . 37) . -12) ((marker . 37) . -12) ((marker . 37) . -12) ((marker . 37) . -12) ((marker . 37) . -12) ((marker . 37) . -12) ((marker . 37) . -12) (304 . 312) 320 nil ("                " . -316) ((marker . 37) . -16) ((marker . 37) . -16) ((marker . 37) . -16) ((marker . 37) . -16) ((marker . 37) . -16) ((marker . 37) . -16) ((marker . 37) . -16) ((marker . 37) . -16) ((marker) . -16) ((marker . 37) . -16) ((marker . 37) . -16) ((marker . 37) . -16) ((marker . 37) . -16) ((marker . 1469) . -16) ((marker . 37) . -16) ((marker . 37) . -16) ((marker . 37) . -16) ((marker . 37) . -16) ((marker . 37) . -16) (304 . 316) 320 nil (nil rear-nonsticky nil 319 . 320) ("
" . -332) (303 . 333) 302 nil (292 . 293) (")" . -291) (291 . 292) (")" . -291) (291 . 292) (290 . 291) (289 . 290) (288 . 290) (281 . 288) (264 . 281) 251 nil (260 . 263) nil (256 . 257) nil ("!" . 256) nil (257 . 260) (255 . 257) nil (250 . 253) (249 . 251) ("s" . 249) nil (nil rear-nonsticky nil 250 . 251) (nil fontified nil 227 . 251) (227 . 251) 226 nil ("str" . 227) ((marker . 18) . -3) ((marker . 247) . -2) ((marker . 1467) . -3) ((marker . 1469) . -2) 229 nil (227 . 230) (226 . 228) (223 . 226) (211 . 223) (210 . 220) (209 . 211) (208 . 209) nil (" " . -207) ((marker . 1469) . -1) 208 (207 . 208) nil (")" . -206) (206 . 207) (")" . -206) (206 . 207) (205 . 206) (204 . 205) nil (203 . 204) (202 . 203) nil ("\"" . 191) nil ("\"" . 197) nil (nil rear-nonsticky nil 197 . 198) (nil fontified nil 191 . 198) (191 . 198) nil (191 . 196) ("aeiou" . 191) nil (191 . 196) (190 . 192) ("\"" . -190) (190 . 191) (189 . 191) (183 . 189) (182 . 184) (179 . 182) (171 . 179) (170 . 176) (169 . 171) (168 . 169) (")" . -167) (167 . 168) (")" . -167) (167 . 168) (164 . 167) (163 . 164) (162 . 163) (161 . 162) (160 . 161) (159 . 160) (158 . 159) ("]" . -157) (157 . 158) ("]" . -157) (156 . 158) (147 . 157) (146 . 147) (141 . 146) (140 . 142) (136 . 140) (132 . 136) ("    " . 131) ((marker . 1469) . -4) (135 . 136) (130 . 135) 129 nil (129 . 130) (")" . -128) (128 . 129) (")" . -128) (128 . 129) ("]" . -127) (127 . 128) ("]" . -127) (126 . 128) (124 . 127) (122 . 124) (121 . 123) (114 . 121) (109 . 114) 71 nil ("    putchar(str[0]);
    for (char *s = (char*)str+1; *s; s++) {
    }
" . 110) ((marker . 18) . -69) ((marker . 37) . -71) ((marker . 37) . -71) ((marker . 37) . -71) ((marker . 37) . -71) ((marker . 37) . -71) ((marker . 37) . -71) ((marker . 37) . -71) ((marker . 233) . -69) ((marker . 234) . -4) ((marker . 247) . -70) ((marker* . 233) . 25) ((marker . 37) . -35) ((marker . 37) . -35) ((marker . 37) . -50) ((marker . 1469) . -4) 114 nil ("        if (strchr(\"aeiouAEIOU\", s[-1]) == NULL)
            putchar(*s);
" . 175) ((marker . 18) . -72) ((marker . 233) . -72) ((marker . 234) . -23) ((marker . 247) . -73) ((marker . 1469) . -23) 198 (t 26176 64373 458622 405000) nil (155 . 156) (151 . 155) (150 . 152) (t 26176 64361 586537 104000) nil (153 . 154) nil (153 . 154) nil ("1" . 153) nil ("+" . 153) (t 26176 64361 586537 104000) nil (47 . 53) ("stdio" . 47) ((marker . 247) . -4) nil (nil rear-nonsticky nil 36 . 37) ("
" . -55) (37 . 56) (nil face font-lock-string-face 36 . 37) (nil fontified t 36 . 37) (nil c-in-sws t 36 . 37) (36 . 37) 18 (t 26176 64350 190472 99000) nil (220 . 221) (")" . -219) (219 . 220) (")" . -219) (219 . 220) (218 . 219) (217 . 218) (216 . 218) (209 . 216) (196 . 209) (")" . -195) (195 . 196) (")" . -195) (195 . 196) (187 . 195) nil (" " . -187) ((marker . 1469) . -1) 188 (187 . 188) (186 . 187) (")" . -186) (186 . 187) ("]" . -185) (185 . 186) ("]" . -185) (183 . 186) ("1" . -183) ((marker . 1469) . -1) 184 (183 . 184) ("1" . -183) ((marker . 1469) . -1) 184 (183 . 184) (180 . 184) (179 . 180) ("\"" . -178) (178 . 179) ("\"" . -178) (176 . 179) (168 . 176) (167 . 169) ("\"" . -167) (167 . 168) (166 . 168) (163 . 166) ("t" . -163) ((marker . 1469) . -1) 164 (160 . 164) ("*" . -160) ((marker . 18) . -1) ((marker . 1467) . -1) ((marker . 1469) . -1) 161 ("(" . -161) ((marker . 18) . -1) ((marker . 1467) . -1) ((marker . 1469) . -1) (")" . 162) ((marker* . 233) . 1) ("s" . -162) ((marker . 18) . -1) ((marker . 1467) . -1) ((marker . 1469) . -1) (" " . -163) ((marker . 1469) . -1) ("-" . -164) ((marker . 1469) . -1) (" " . -165) ((marker . 1469) . -1) ("1" . -166) ((marker . 1469) . -1) (")" . -167) ((marker* . 233) . 1) ((marker . 1469) . -1) (" " . -168) ((marker . 1469) . -1) 169 (168 . 169) nil (162 . 167) (161 . 163) (160 . 161) ("s" . -160) ((marker . 18) . -1) ((marker . 1467) . -1) ((marker . 1469) . -1) 161 ("[" . -161) ((marker . 1469) . -1) ("]" . 162) ("-" . -162) ((marker . 1469) . -1) 163 (162 . 163) (160 . 163) nil (109 . 110) nil (158 . 160) nil (132 . 134) nil ("]" . -107) (107 . 108) ("]" . -107) (106 . 108) (102 . 107) ("*" . -102) ((marker . 1469) . -1) 103 (102 . 103) (101 . 103) (94 . 101) (89 . 94) 61 nil (133 . 136) (125 . 133) (124 . 130) (123 . 125) (122 . 123) (")" . -121) (121 . 122) (")" . -121) (121 . 122) (117 . 121) (116 . 117) (115 . 116) (114 . 115) (113 . 114) (112 . 113) (105 . 112) (104 . 105) ("s" . -104) ((marker . 1469) . -1) 105 (99 . 105) (98 . 100) (94 . 98) (89 . 94) 51 nil ("    for (int i = 0; i < )
" . 90) ((marker . 37) . -26) ((marker . 37) . -26) ((marker . 37) . -26) ((marker . 37) . -26) ((marker . 37) . -26) ((marker . 37) . -26) ((marker . 37) . -26) ((marker . 18) . -6) ((marker . 247) . -25) ((marker* . 233) . 2) ((marker . 1467) . -6) ((marker . 1469) . -9) 99 nil (109 . 114) (108 . 109) (99 . 108) (98 . 100) (94 . 98) (89 . 94) 88 nil (88 . 89) (")" . -87) (87 . 88) (")" . -87) (87 . 88) (84 . 87) ("&" . -84) ((marker . 1469) . -1) 85 (83 . 85) (82 . 83) nil (77 . 80) (75 . 78) ("%" . -75) ((marker . 1469) . -1) 76 (75 . 76) (74 . 76) ("\"" . -74) (74 . 75) (73 . 75) (67 . 73) (66 . 67) ("]" . -65) (65 . 66) ("]" . -65) (63 . 66) (59 . 64) (55 . 59) (50 . 55) 38 nil ("
    " . 50) ((marker . 18) . -5) ((marker . 37) . -5) ((marker . 37) . -5) ((marker . 1469) . -5) ((marker . 37) . -5) ((marker . 37) . -5) ("meet" . 55) ((marker . 18) . -1) ((marker . 37) . -4) ((marker . 37) . -4) ((marker . 1469) . -1) ((marker . 37) . -4) ((marker . 37) . -1) nil ("
        " . 59) ((marker . 18) . -9) ((marker . 1469) . -9) ((marker . 37) . -9) ((marker . 37) . -9) ("met" . 68) ((marker . 18) . -2) ((marker . 1469) . -2) ((marker . 37) . -2) ((marker . 37) . -2) nil (68 . 71) (59 . 68) 56 nil (55 . 59) (50 . 55) 38 nil ("    int n = 5;
    int goals[n], mins[n];
    inputData(goals, mins, n);
    printf(\"%d\", countOfHattricks(goals, n));
" . 51) ((marker . 37) . -42) ((marker . 37) . -112) ((marker . 37) . -90) ((marker . 37) . -67) ((marker . 37) . -61) ((marker . 37) . -46) ((marker . 37) . -38) ((marker . 247) . -118) nil ("
" . -37) ((marker . 18) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 37) . -1) ((marker . 233) . -1) ((marker . 233) . -1) ((marker . 234) . -1) ((marker . 18) . -1) ((marker . 247) . -1) nil ("void inputData(int goals[], int mins[], int n) {
    for (int i = 0; i < n; i++) {
        scanf(\"%d\", goals + i);
        scanf(\"%d\", mins + i);
    }
}

int countOfHattricks(int goals[], int n) {
    int count = 0;
    for (int i = 0; i < n; i++) {
        if (goals[i] >= 3) count++;
    }
    return count;
}
" . 38) ((marker . 18) . -311) ((marker . 37) . -271) ((marker . 37) . -140) ((marker . 37) . -109) ((marker . 234) . -311) ((marker . 1469) . -311) ((marker . 247) . -312) 349 (t 26176 61014 825489 267000) nil (485 . 486) 18 nil (482 . 483) nil (479 . 480) ("m" . -479) ("i" . -480) ("n" . -481) ("s" . -482) 483 (479 . 483) ("int n" . 479) (472 . 477) ("goa" . -472) 475 (472 . 475) ("(" . -472) (")" . 473) (472 . 474) ("int *goals" . 472) (455 . 490) ("cou" . -455) 458 (454 . 458) (453 . 454) ("\"" . -452) (452 . 453) ("\"" . -452) (450 . 453) (449 . 451) ("\"" . -449) (449 . 450) (448 . 450) (442 . 448) (437 . 442) 436 nil (436 . 437) (")" . -435) (435 . 436) (")" . -435) (435 . 436) (434 . 435) ("int n" . 434) (428 . 432) ("int *mins" . 428) (421 . 426) ("goa" . -421) 424 (421 . 424) ("int *goals" . 421) (411 . 450) ("in" . -411) 413 (411 . 413) (406 . 411) 403 nil (403 . 404) ("5" . 403) nil ("
" . 17) nil (17 . 18) 6 nil (394 . 395) ("5" . 394) nil (378 . 379) (372 . 378) ("n" . -372) (" " . -373) (" " . -374) ("=" . -375) 376 (370 . 376) (369 . 370) (364 . 369) 363 nil (390 . 391) ("]" . -389) (389 . 390) ("]" . -389) (388 . 390) (382 . 389) (381 . 382) ("]" . -380) (380 . 381) ("]" . -380) (379 . 381) (377 . 380) (369 . 377) (apply yas--snippet-revive 352 371 #s(yas--snippet nil nil #s(yas--exit 369 nil) 4 nil nil nil nil)) (apply yas--take-care-of-redo #s(yas--snippet nil nil #s(yas--exit 369 nil) 4 nil nil nil nil)) (352 . 371) ("main()" . 352) 358 (")" . -357) (357 . 358) (")" . -357) (357 . 358) (356 . 358) (352 . 356) (351 . 352) (350 . 351) 349 nil (347 . 348) nil (342 . 347) ("cou" . -342) 345 (341 . 345) (335 . 341) ("retu" . -335) 339 (335 . 339) (330 . 335) 329 nil (323 . 324) (321 . 323) (" " . -321) 322 (321 . 322) (316 . 321) ("cou" . -316) 319 (315 . 319) (" " . -315) ("c" . -316) 317 (315 . 317) (")" . -314) (314 . 315) (")" . -314) (314 . 315) (311 . 314) (" " . -311) 312 (309 . 312) nil (nil rear-nonsticky nil 309 . 310) (nil fontified nil 309 . 310) (309 . 310) 308 nil (")" . 301) nil (300 . 302) (297 . 300) nil 304 nil ("]" . -304) (304 . 305) ("]" . -304) (303 . 305) (302 . 304) ("]" . -302) ("i" . -303) 304 (302 . 304) ("]" . -302) (297 . 303) (289 . 297) (288 . 294) (287 . 289) (286 . 287) (")" . -285) (285 . 286) (")" . -285) (285 . 286) (281 . 285) (280 . 281) (277 . 280) (274 . 277) (273 . 274) (264 . 273) (263 . 265) (259 . 263) (254 . 259) (253 . 254) (240 . 253) (236 . 240) (235 . 237) (234 . 236) (233 . 234) (")" . -232) (232 . 233) (")" . -232) (232 . 233) (226 . 232) (225 . 226) ("]" . -224) (224 . 225) ("]" . -224) (224 . 225) (214 . 225) (213 . 215) (193 . 213) (192 . 193) (191 . 192) 190 nil (179 . 180) (nil rear-nonsticky nil 178 . 179) (nil fontified nil 178 . 179) (178 . 179) (177 . 178) ("+" . 177) nil (148 . 149) (nil rear-nonsticky nil 147 . 148) (nil fontified nil 147 . 148) (147 . 148) (146 . 147) ("+" . 146) nil ("]" . 148) nil ("]" . 178) nil (176 . 177) ("[" . 176) nil (146 . 147) ("[" . 146) nil ("&" . 172) nil ("&" . 141) nil (174 . 178) ("goals" . 174) nil (nil rear-nonsticky nil 160 . 161) ("
" . -184) (152 . 185) 151 nil (151 . 152) nil ("]" . -149) (149 . 150) ("]" . -149) (148 . 150) (143 . 149) ("l" . -143) 144 (140 . 144) (139 . 140) ("\"" . -138) (138 . 139) ("\"" . -138) (138 . 139) (136 . 138) (135 . 137) ("\"" . -135) (135 . 136) ("%" . -135) 136 ("\"" . -136) ("\"" . 137) (136 . 138) ("\"" . -136) (135 . 137) (134 . 136) ("9" . -134) 135 ("\"" . -135) ("\"" . 136) ("%" . -136) 137 (136 . 137) (135 . 137) ("\"" . -135) (129 . 136) (121 . 129) (120 . 126) (119 . 121) (118 . 119) (")" . -117) (117 . 118) (")" . -117) (117 . 118) (113 . 117) (112 . 113) (106 . 112) (105 . 106) (96 . 105) (95 . 97) (91 . 95) ("f" . -91) ("o" . -92) ("r" . -93) (" " . -94) 95 (91 . 95) ("f" . -91) ("o" . -92) (" " . -93) 94 (91 . 94) (87 . 91) (86 . 88) (85 . 87) (84 . 85) (")" . -83) (83 . 84) (")" . -83) (83 . 84) (77 . 83) (76 . 77) ("]" . -75) (75 . 76) ("]" . -75) (75 . 76) (65 . 76) (64 . 65) ("]" . -63) (63 . 64) ("]" . -63) (63 . 64) (61 . 64) ("d" . -61) 62 (60 . 62) (53 . 60) (52 . 54) (44 . 52) ("i" . -44) 45 (38 . 45) ("i" . -38) 39 (38 . 39) (37 . 38) 37 nil ("
int func(int n) {
    printf(\"%d\\n\", n);
    if (n % 7 == 0)
        return 2;
    else if (n % 2 == 0)
        func(n + 2);
    else
        func(n + 1);
    printf(\"%d\\n\", n);
}

void main() {
    printf(\"%d\", func(3));
}
" . 37) (t 26176 60342 263588 147000) nil ("    return 0;
" . 216) (t 26176 60327 812964 457000) nil (228 . 229) (220 . 228) (215 . 220) 208 nil ("
    " . 215) (216 . 220) nil ("    " . -216) 220 (215 . 220) 208 nil (114 . 115) ("10" . 114) (t 26176 60313 805692 638000) nil (114 . 116) ("2" . 114) (t 26176 60210 11188 389000) nil (259 . 260) (" " . 259) nil (232 . 237) (" " . 232) nil (217 . 218) (t 26176 59840 824766 708000) 216 nil (26 . 255) ("<stdio.h>

int func(int n){
printf(\"%d\\n\", n);
if(n%7==0) return 2;
else if(n%2==0) func(n+2);
else func(n+1);
printf(\"%d\\n\",n);
}
void main(){
printf(\"%d\", func(3));
" . 26) (t 26176 59838 471325 974000) nil (194 . 195) 36 nil (nil face font-lock-string-face 35 . 36) (nil fontified t 35 . 36) (nil c-in-sws t 35 . 36) (35 . 36) 18 nil ("#include <stdio.h>
" . 18) nil (nil rear-nonsticky nil 211 . 212) (nil fontified nil 56 . 212) (nil fontified nil 55 . 56) (nil fontified nil 38 . 55) (nil fontified nil 37 . 38) (37 . 212) nil ("
// 1 2 3 4 5 6 7 8 
void main() {
    int i, j, data[5][5] = {0};
    for (i = 0; i < 5; i++) {
        for (j = i + 1; j < 5; j++)
            scanf(\"%d\", &data[i][j]);
    }
    for (i = 0; i < 5; i++) {
        for (j = i; j < 5; j++)
            printf(\"%d_\", data[i][j]);
        printf(\"\\n\");
    }
}

00 00 00 00 00
00 00 00 00 00
00 00 00 00 00
00 00 00 00 00
00 00 00 00 00
" . 37) nil (nil rear-nonsticky nil 360 . 361) ("
" . -420) (360 . 421) 359 nil (" " . -360) 361 (355 . 361) (346 . 355) (345 . 346) (344 . 345) 343 nil (40 . 57) (38 . 40) (37 . 38) (t 26176 59753 40729 688000) 37 nil (49 . 321) ("{
int i, j, data[5][5]={0};
for(i=0; i<5; i++) {
for(j=i+1; j<5; j++)
scanf(\"%d\", &data[i][j]);
}
for(i=0; i<5; i++) {
for(j=i; j<5; j++)
printf(\"%d_\", data[i][j]);
printf(\"\\n\");
" . 49) (t 26176 59747 607144 253000) nil (231 . 232) 37 nil (nil face font-lock-string-face 36 . 37) (nil fontified t 36 . 37) (nil c-in-sws t 36 . 37) (36 . 37) 18 nil ("#include <stdio.h>

int main() {

}
" . 18) nil (nil rear-nonsticky nil 265 . 266) (nil fontified nil 74 . 266) (nil fontified nil 73 . 74) (nil fontified nil 55 . 73) (nil fontified nil 54 . 55) (54 . 266) nil (53 . 54) 52 nil ("    " . -51) 55 nil (apply yas--snippet-revive 38 57 #s(yas--snippet nil nil #s(yas--exit 55 nil) 3 nil nil nil nil)) (apply yas--take-care-of-redo #s(yas--snippet nil nil #s(yas--exit 55 nil) 3 nil nil nil nil)) (38 . 57) ("main()" . 38) 44 (")" . -43) (43 . 44) (")" . -43) (43 . 44) (42 . 44) (38 . 42) (37 . 38) 37 nil ("
struct program {
    char name[60];
    int total_memory;
    int used_memory;
};

int all_caps(char *input) {
    for (; *input >= 'A' && *input <= 'Z' && *input; input++)
        ;
    return !*input;
}

int main() {
    int n; scanf(\"%d\", &n);
    struct program ar[n];
    int virs[n], count = 0;
    for (int i = 0; i < n; i++) {
        scanf(\" %s\", ar[i].name);
        scanf(\"%d\", &ar[i].total_memory);
        scanf(\"%d\", &ar[i].used_memory);

        if (ar[i].used_memory >= ar[i].total_memory && all_caps(ar[i].name))
            virs[count++] = i;
    }

    printf(\"%d\\n\", count);
    for (int i = 0; i < count; i++)
        puts(ar[virs[i]].name);
}
" . 37) (t 26176 45548 802015 233000) nil (239 . 240) (234 . 239) ("in" . -234) 236 (234 . 236) (233 . 234) (232 . 233) ("(*input) ? 0 : 1;" . 232) nil (248 . 249) (246 . 248) ("1" . -246) 247 (246 . 247) (245 . 246) (243 . 245) ("1" . -243) 244 (243 . 244) (242 . 243) nil (232 . 233) nil (238 . 239) (")" . -238) (238 . 239) nil (238 . 240) (233 . 238) ("in" . -233) 235 (233 . 235) (232 . 233) ("!*input;" . 232) (t 26176 45497 66498 791000) nil ("    deb(all_caps(\"codeblocks\"));
" . 606) (t 26176 45491 832944 744000) nil (723 . 724) (722 . 724) ("i" . -722) 723 (718 . 723) ("i" . 718) (t 26176 45454 278028 373000) nil (637 . 638) nil (631 . 634) ("s" . -631) 632 (625 . 632) ("d" . -625) 626 (624 . 626) nil ("        " . -610) (606 . 610) 619 nil (nil rear-nonsticky nil 613 . 614) ("
" . -631) (605 . 632) nil ("        deb(all_caps(\"\"))
" . 491) 512 nil (512 . 514) ("\"" . -512) (512 . 513) ("char *input" . 512) (503 . 524) ("all" . -503) 506 (503 . 506) (502 . 504) (499 . 502) (490 . 499) (t 26176 45304 71711 660000) 490 nil ("
        " . 490) ("()" . 499) ("deb" . 500) nil (500 . 503) (499 . 501) (490 . 499) (t 26176 45304 71711 660000) 490 nil ("
        " . 490) ("puts" . 499) ("()" . 503) nil (503 . 505) (499 . 503) (490 . 499) (t 26176 45304 71711 660000) 490 nil ("
        " . 490) ("de" . 499) nil (499 . 501) (490 . 499) (t 26176 45304 71711 660000) 490 nil (118 . 119) (t 26176 45293 661274 862000) nil (692 . 693) (")" . -691) (691 . 692) (")" . -691) (691 . 692) (686 . 691) ("]" . -685) (685 . 686) ("]" . -685) (684 . 686) (681 . 685) (680 . 682) (676 . 680) (667 . 676) (" " . -667) ("{" . -668) 669 nil ("    }
" . 670) 674 nil ("        printf(\"%\")
" . 670) 686 nil (686 . 687) (685 . 687) ("\"" . -685) (685 . 686) (684 . 686) (678 . 684) ("p" . -678) ("i" . -679) 680 (678 . 680) (669 . 678) 668 nil ("        " . 669) ("
" . -669) 657 nil (630 . 631) (")" . -629) (629 . 630) (")" . -629) (629 . 630) (624 . 629) ("cou" . -624) 627 (623 . 627) (622 . 623) ("\"" . -621) (621 . 622) ("\"" . -621) (617 . 622) (616 . 618) ("\"" . -616) (616 . 617) ("%" . -616) 617 ("\"" . -617) ("\"" . 618) (617 . 619) ("\"" . -617) (616 . 618) (615 . 617) ("9" . -615) 616 ("\"" . -616) ("\"" . 617) ("%" . -617) 618 (617 . 618) (616 . 618) ("\"" . -616) (609 . 617) (604 . 609) 604 nil (643 . 651) (642 . 648) (641 . 643) (640 . 641) (")" . -639) (639 . 640) (")" . -639) (639 . 640) (635 . 639) (634 . 635) (629 . 634) ("cou" . -629) 632 (624 . 632) (623 . 624) (621 . 623) ("0" . -621) 622 (614 . 622) (613 . 615) (609 . 613) (605 . 609) ("    " . 604) (608 . 609) (603 . 608) 602 nil (596 . 597) (592 . 596) ("]" . -591) (591 . 592) ("]" . -591) (589 . 592) (584 . 589) ("cou" . -584) 587 (584 . 587) (579 . 585) (566 . 579) ("
" . -566) 567 ("            " . -567) 579 (566 . 579) nil (560 . 564) ("na" . -560) 562 (559 . 562) ("]" . -558) (558 . 559) ("]" . -558) (557 . 559) (554 . 558) ("char *input" . 554) (545 . 566) ("all" . -545) 548 (541 . 548) nil (508 . 519) ("use" . -508) 511 (507 . 511) ("]" . -506) (506 . 507) ("]" . -506) (505 . 507) (502 . 506) nil (503 . 506) ("<" . -503) 504 (502 . 504) nil (" " . -520) 521 (520 . 521) (508 . 520) ("to" . -508) 510 (507 . 510) ("]" . -506) (506 . 507) ("]" . -506) (505 . 507) (502 . 506) nil (" " . 463) nil (" " . 421) nil (503 . 505) (500 . 503) (492 . 500) ("        " . 491) (499 . 500) (490 . 499) 474 nil (333 . 336) (" " . -333) 334 (327 . 334) ("i" . -327) ("n" . -328) ("t" . -329) (" " . -330) 331 (326 . 331) (325 . 326) nil ("
" . -485) ("
" . -485) 484 nil (325 . 326) ("]" . -324) (324 . 325) ("]" . -324) (323 . 325) (314 . 324) (309 . 314) 295 nil ("    " . -470) 474 (470 . 474) ("    " . 469) (473 . 474) (468 . 473) 463 nil ("
    " . 283) (284 . 288) nil ("    " . -284) 288 (283 . 288) 256 nil (438 . 439) ("s" . 438) nil (395 . 396) ("s" . 395) nil (449 . 460) ("use" . -449) 452 (449 . 452) ("name" . 449) 452 nil (406 . 418) ("to" . -406) 408 (406 . 408) ("name" . 406) nil (434 . 435) ("7" . -434) (399 . 400) ("7" . -399) 434 nil (434 . 435) (399 . 400) nil (nil rear-nonsticky nil 419 . 420) ("
" . -445) (411 . 446) 386 nil (nil rear-nonsticky nil 385 . 386) ("
" . -411) (377 . 412) 376 nil (376 . 377) (")" . -375) (375 . 376) (")" . -375) (375 . 376) (371 . 375) ("na" . -371) 373 (370 . 373) ("]" . -369) (369 . 370) ("]" . -369) (368 . 370) (365 . 369) ("..." . 365) (" " . -362) 363 (359 . 363) ("%" . -359) 360 ("d" . -360) (" " . -361) 362 (359 . 362) (358 . 360) ("\"" . -358) (358 . 359) ("const char *restrict format" . 358) (352 . 391) ("sca" . -352) 355 (353 . 355) ("a" . -353) ("c" . -354) ("n" . -355) 356 (352 . 356) (344 . 352) (343 . 349) (342 . 344) (341 . 342) (")" . -340) (340 . 341) (")" . -340) (340 . 341) (336 . 340) (335 . 336) (";" . -335) 336 (335 . 336) (329 . 335) (328 . 329) (326 . 328) ("0" . -326) 327 (323 . 327) (319 . 323) (318 . 320) (314 . 318) (309 . 314) (308 . 309) ("]" . -307) (307 . 308) ("]" . -307) (306 . 308) (302 . 307) (295 . 302) ("pro" . -295) 298 (294 . 298) (288 . 294) ("stru" . -288) 292 (288 . 292) (283 . 288) 260 nil ("/" . 260) nil ("/" . 260) nil ("    char s[20]; scanf(\" %s\", s);
    puts(all_caps(s) ? \"YES\" : \"NO\");
" . 286) 295 nil (115 . 116) (108 . 115) (102 . 108) (" " . -102) 103 (100 . 103) (95 . 100) (94 . 95) (91 . 94) ("r" . -91) ("o" . -92) 93 (78 . 93) (73 . 78) (72 . 73) ("]" . -71) (71 . 72) ("]" . -71) (71 . 72) (69 . 71) (59 . 70) (55 . 59) (54 . 56) (53 . 55) (44 . 53) (38 . 44) ("stru" . -38) 42 (38 . 42) (37 . 38) (nil face font-lock-string-face 36 . 37) (nil fontified t 36 . 37) (nil c-in-sws t 36 . 37) (36 . 37) (t 26176 44613 412430 544000) 18 nil ("
" . 17) ("
" . 18) nil (18 . 19) (17 . 18) (t 26176 44613 412430 544000) 1 nil (227 . 228) nil (228 . 229) ("[^\\n]" . 228) 232 nil (" " . 227) nil (84 . 86) ("<" . 84) nil (87 . 88) ("a" . 87) nil (100 . 102) (">" . 100) nil (103 . 104) ("z" . 103) nil (147 . 148) nil ("!" . 147) (t 26176 43980 595408 706000) nil (66 . 156) nil ("
    " . 65) (66 . 70) nil ("    " . -66) 70 (65 . 70) 38 nil ("    for (; *input < 'a' && *input > 'z' && *input; input++)
        ;
    return !*input;
" . 66) (t 26176 43980 595408 706000) nil (147 . 148) nil ("!" . 147) (t 26176 43943 733836 682000) nil (147 . 148) (t 26176 43913 915898 623000) nil ("!" . 147) (t 26176 43896 415152 532000) nil (103 . 104) ("Z" . 103) nil (100 . 101) ("<=" . 100) 101 nil (87 . 88) ("A" . 87) nil (84 . 85) (">=" . 84) 85 (t 26176 43751 562313 879000) nil (280 . 281) 277 nil (277 . 278) nil (273 . 275) (272 . 274) ("\"" . -272) (271 . 273) (270 . 271) (269 . 270) ("a" . -269) (" " . -270) 271 (269 . 271) nil (nil rear-nonsticky nil 267 . 268) (nil fontified nil 267 . 268) (267 . 268) 266 nil ("S" . 266) nil ("\"" . -268) (268 . 269) ("\"" . -268) (265 . 269) (264 . 266) ("\"" . -264) (261 . 265) (")" . -260) (260 . 261) (")" . -260) (260 . 261) (259 . 260) ("char *input" . 259) (250 . 271) ("al" . -250) 252 (250 . 252) ("\"" . -250) ("\"" . 251) (250 . 252) ("\"" . -250) (250 . 251) (249 . 251) (245 . 249) (240 . 245) (239 . 240) (")" . -238) (238 . 239) (")" . -238) (238 . 239) (236 . 238) (235 . 236) (234 . 235) ("\"" . -234) (234 . 235) nil (228 . 229) nil (229 . 232) (227 . 230) ("%" . -227) ("s" . -228) ("\"" . -229) ("," . -230) (" " . -231) 232 (231 . 232) (230 . 231) ("\"" . -229) (229 . 230) ("\"" . -229) (227 . 230) (226 . 228) ("\"" . -226) (226 . 227) (225 . 227) (223 . 225) ("f" . -223) 224 (220 . 224) (219 . 220) (218 . 219) ("]" . -217) (217 . 218) ("]" . -217) (217 . 218) ("[" . -217) ("]" . 218) (215 . 219) ("1" . -215) 216 (215 . 216) (208 . 216) (203 . 208) 178 nil (178 . 179) nil 178 nil (178 . 179) nil 183 nil ("    " . 201) ("
" . -201) ("
" . -201) 192 nil (156 . 157) (151 . 156) ("in" . -151) 153 (151 . 153) (150 . 151) (149 . 150) (" " . -149) 150 (148 . 150) (142 . 148) ("retur" . -142) 147 (142 . 147) (137 . 142) (136 . 137) (127 . 136) (")" . -126) (126 . 127) (")" . -126) (126 . 127) (124 . 126) (119 . 124) ("in" . -119) 121 (118 . 121) (117 . 118) (112 . 117) ("in" . -112) 114 (112 . 114) (111 . 112) (107 . 111) ("'" . -106) (106 . 107) ("'" . -106) (105 . 107) (104 . 106) ("'" . -104) (100 . 105) (95 . 100) ("in" . -95) 97 (95 . 97) (94 . 95) (90 . 94) ("'" . 90) nil (89 . 91) ("'" . -89) (88 . 90) ("a" . -88) ("'" . -89) 90 ("'" . -89) (89 . 90) ("'" . -89) (88 . 90) (87 . 89) ("'" . -87) (84 . 88) (78 . 84) (77 . 78) (76 . 77) (75 . 76) (74 . 76) (70 . 74) (66 . 70) (65 . 67) (64 . 66) (63 . 64) (")" . -62) (62 . 63) (")" . -62) (62 . 63) (57 . 62) (56 . 57) (51 . 56) (50 . 52) (38 . 50) (37 . 38) (nil face font-lock-string-face 36 . 37) (nil fontified t 36 . 37) (nil c-in-sws t 36 . 37) (36 . 37) 21 nil (80 . 84) ("    " . 79) (78 . 84) (77 . 78) (")" . -76) (76 . 77) (")" . -76) (76 . 77) (73 . 76) (72 . 73) ("\"" . -71) (71 . 72) ("\"" . -71) (69 . 72) (68 . 70) ("\"" . -68) (68 . 69) (67 . 69) (61 . 67) (60 . 61) (55 . 60) (apply yas--snippet-revive 38 57 #s(yas--snippet nil nil #s(yas--exit 55 nil) 2 nil nil nil nil)) (apply yas--take-care-of-redo #s(yas--snippet nil nil #s(yas--exit 55 nil) 2 nil nil nil nil)) (38 . 57) ("main()" . 38) 44 (")" . -43) (43 . 44) (")" . -43) (43 . 44) (42 . 44) (38 . 42) (37 . 38) 37 nil ("
int is_prime(int x) {
    if (x < 2) return 0;
    for (int i = 2; i <= x/2; i++)
        if (x % i == 0) return 0;
    return 1;
}

int digit_sum(unsigned int x) {
    if (x == 0) return 0;
    return x % 10 + digit_sum(x / 10);
}

int is_superprime(int x) {
    return is_prime(x) && is_prime(digit_sum(x));
}

int main() {
    int a, b; scanf(\"%d%d\", &a, &b);
    for (; a <= b; a++)
        if (is_superprime(a)) printf(\"%d\\n\", a);
}
" . 37) (t 26176 41771 4693 403000) nil (472 . 473) (")" . -471) (471 . 472) (")" . -471) (471 . 472) (469 . 471) (468 . 469) ("\"" . -467) (467 . 468) ("\"" . -467) (463 . 468) (462 . 464) ("\"" . -462) (462 . 463) (461 . 463) (457 . 461) (454 . 457) (")" . -453) (453 . 454) (")" . -453) (453 . 454) (")" . -452) (452 . 453) (")" . -452) (452 . 453) (451 . 452) ("int x" . 451) (437 . 457) ("is_su" . -437) 442 (437 . 442) (436 . 438) (433 . 436) (424 . 433) (")" . -423) (423 . 424) (")" . -423) (423 . 424) (419 . 423) (418 . 419) (414 . 418) ("," . -414) 415 (414 . 415) (411 . 414) (410 . 411) ("i" . -410) ("n" . -411) ("t" . -412) (" " . -413) ("i" . -414) 415 (" " . -415) 416 (410 . 416) (409 . 411) (405 . 409) (400 . 405) 364 nil ("    deb(digit_sum(n));
" . 401) 422 nil (395 . 398) (394 . 395) (393 . 394) ("n" . 393) nil (387 . 389) nil (374 . 376) (373 . 374) (372 . 373) ("n" . 372) nil (346 . 347) (")" . -345) (345 . 346) (")" . -345) (345 . 346) (nil rear-nonsticky nil 344 . 345) (nil fontified nil 333 . 345) (333 . 345) ("int x" . 333) (324 . 339) ("is" . -324) 326 (324 . 326) ("digit_sum(x)" . 324) nil (")" . -335) (335 . 336) (")" . -335) (335 . 336) (334 . 335) ("unsigned int x" . 334) (324 . 349) ("dig" . -324) 327 (320 . 327) (")" . -319) (319 . 320) (")" . -319) (319 . 320) (318 . 319) ("int x" . 318) (309 . 324) ("is_" . -309) 312 (309 . 312) (302 . 309) (298 . 302) (297 . 299) (296 . 298) (295 . 296) (")" . -294) (294 . 295) (")" . -294) (294 . 295) (289 . 294) (288 . 290) (277 . 288) (" " . -277) 278 (271 . 278) (270 . 271) (269 . 270) (t 26176 41619 101603 123000) 268 nil (nil fontified nil 259 . 260) ("n" . -259) (260 . 261) (nil fontified t 240 . 241) (t 26176 41607 924464 891000) ("n" . -240) (t 26176 41607 924464 891000) (241 . 242) (t 26176 41607 924464 891000) nil (336 . 337) 333 nil (333 . 334) nil (330 . 331) ("unsigned int x" . 330) (320 . 345) ("digi" . -320) 324 (321 . 324) ("g" . -321) 322 (320 . 322) (319 . 321) (316 . 319) (311 . 316) (310 . 311) (")" . -309) (309 . 310) (")" . -309) (309 . 310) (306 . 309) (305 . 306) ("\"" . -304) (304 . 305) ("\"" . -304) (302 . 305) (301 . 303) ("\"" . -301) (301 . 302) (300 . 302) (298 . 300) ("f" . -298) 299 (295 . 299) ("c" . -295) 296 (294 . 296) (293 . 294) (288 . 293) (apply yas--snippet-revive 271 290 #s(yas--snippet nil nil #s(yas--exit 288 nil) 1 nil nil nil nil)) (apply yas--take-care-of-redo #s(yas--snippet nil nil #s(yas--exit 288 nil) 1 nil nil nil nil)) (271 . 290) ("main()" . 271) 277 (")" . -276) (276 . 277) (")" . -276) (276 . 277) (275 . 277) (271 . 275) (270 . 271) (269 . 270) 268 nil (266 . 267) (")" . -265) (265 . 266) (")" . -265) (265 . 266) (262 . 265) (261 . 262) (259 . 261) ("unsigned int x" . 259) (249 . 274) ("dig" . -249) 252 (244 . 252) (240 . 244) ("n" . -240) (" " . -241) ("/" . -242) (" " . -243) ("1" . -244) ("0" . -245) (" " . -246) ("+" . -247) (" " . -248) (" " . -249) 250 (249 . 250) nil ("(" . 240) nil (")" . 247) nil (248 . 251) (")" . -247) (247 . 248) (")" . -247) (247 . 248) (244 . 247) (243 . 244) (242 . 243) ("/" . -242) 243 (242 . 243) (241 . 242) (240 . 242) (239 . 240) (233 . 239) ("retu" . -233) 237 (233 . 237) (228 . 233) (227 . 228) (225 . 227) (219 . 225) ("retu" . -219) 223 (218 . 223) (")" . -217) (217 . 218) (")" . -217) (217 . 218) (211 . 217) (210 . 212) (207 . 210) (203 . 207) (202 . 204) (201 . 203) (200 . 201) (")" . -199) (199 . 200) (")" . -199) (199 . 200) (195 . 199) ("t" . -195) ("n" . -196) (" " . -197) ("x" . -198) 199 (193 . 199) (185 . 193) ("uns" . -185) 188 (185 . 188) (184 . 186) (" " . -184) 185 (171 . 185) (170 . 171) (169 . 170) 168 nil ("int is_
" . 38) nil (nil rear-nonsticky nil 176 . 177) (nil fontified nil 46 . 177) (46 . 177) nil (45 . 46) 44 nil (38 . 45) (37 . 38) 37 nil ("
struct card {
    char name[60];
    int stage;
    int HP;
};

int ends_with(char *input, char letter) {
    for (; *input != letter && *input; input++)
        ;
    return *input;
}

int main() {
    int n; scanf(\"%d\", &n);
    struct card ar[n];
    int price = 0;
    for (int i = 0; i < n; i++) {
        scanf(\" %[^\\n]\", ar[i].name);
        scanf(\"%d\", &ar[i].stage);
        scanf(\"%d\", &ar[i].HP);

        price += 50;
        price += ar[i].HP;

        if (ar[i].stage == 1)      price += 30;
        else if (ar[i].stage == 2) price += 70;

        if (ends_with(ar[i].name, 'X')) price += 200;
    }

    printf(\"%d\\n\", price);
}
" . 37) (t 26176 40372 832168 779000) nil ("
        " . 446) ("int price = 0" . 455) (";" . 468) (t 26176 40368 301972 823000) nil (297 . 301) nil ("
        " . 665) ("p += price" . 674) (")" . 684) (684 . 685) (")" . 684) (";" . 685) nil (684 . 685) nil ("
        " . 665) ("deb" . 674) ("()" . 677) ("r" . 678) (678 . 679) ("price" . 678) (")" . 683) (683 . 684) (")" . 683) (683 . 684) (";" . 684) nil (733 . 737) (t 26176 40302 649133 368000) nil ("rice" . 733) nil (684 . 685) (")" . -683) (683 . 684) (")" . -683) (683 . 684) (678 . 683) ("r" . -678) 679 (678 . 679) (677 . 679) (674 . 677) (665 . 674) 630 nil (")" . 684) nil (685 . 686) (684 . 685) (")" . -684) (684 . 685) (674 . 684) (665 . 674) 621 nil ("rice" . 297) nil (468 . 469) (455 . 468) (446 . 455) (t 26176 40226 442504 898000) 446 nil (679 . 680) (")" . -678) (678 . 679) (")" . -678) (678 . 679) (673 . 678) ("pri" . -673) 676 (672 . 676) (671 . 672) ("\"" . -670) (670 . 671) ("\"" . -670) (666 . 671) (665 . 667) ("\"" . -665) (665 . 666) (664 . 666) (658 . 664) (654 . 658) (654 . 655) ("    deb(price);
" . 654) 660 (t 26176 40216 115391 774000) nil (482 . 483) nil ("+" . 482) nil (482 . 483) ("=" . 482) (t 26176 40208 871745 293000) nil (297 . 301) nil ("
        " . 442) ("int s" . 451) (455 . 456) ("pi" . 455) (456 . 457) ("rim" . 456) (458 . 459) ("ce = 0" . 458) (";" . 464) nil ("
        " . 665) ("deb" . 674) ("()" . 677) ("pri" . 678) (678 . 681) ("price" . 678) (")" . 683) (683 . 684) (")" . 683) (683 . 684) (";" . 684) nil ("
        " . 685) ("p += pri" . 694) (699 . 702) ("price" . 699) (";" . 704) nil (722 . 726) nil (501 . 502) ("+" . 501) (t 26176 40202 838151 132000) nil (501 . 502) ("=" . 501) (t 26176 40053 375025 504000) nil ("rice" . 722) nil (704 . 705) (699 . 704) ("pri" . -699) 702 (694 . 702) (685 . 694) 684 nil (684 . 685) (")" . -683) (683 . 684) (")" . -683) (683 . 684) (678 . 683) ("pri" . -678) 681 (678 . 681) (677 . 679) (674 . 677) (665 . 674) 633 nil (464 . 465) (458 . 464) ("m" . -458) 459 (456 . 459) ("i" . -456) 457 (455 . 457) ("s" . -455) 456 (451 . 456) (442 . 451) 442 nil ("rice" . 297) (t 26176 39963 341137 106000) nil ("
        " . 446) ("int sum = 0" . 455) (";" . 466) nil (466 . 467) (455 . 466) (446 . 455) (t 26176 39963 341137 106000) 446 nil (671 . 672) 668 nil (668 . 669) (")" . -667) (667 . 668) (")" . -667) (667 . 668) (662 . 667) ("pri" . -662) 665 (662 . 665) (661 . 663) (658 . 661) (654 . 658) ("    " . 653) (657 . 658) (652 . 657) 647 nil (526 . 531) nil (640 . 641) (634 . 640) ("=" . -634) ("+" . -635) 636 (633 . 636) (628 . 633) ("pri" . -628) 631 (627 . 631) (")" . -626) (626 . 627) (")" . -626) (626 . 627) (")" . -625) (625 . 626) (")" . -625) (625 . 626) ("'" . -624) (624 . 625) ("'" . -624) (623 . 625) (622 . 624) ("'" . -622) (622 . 623) ("char letter" . 622) (615 . 620) ("]" . -614) (614 . 615) ("]" . -614) (613 . 615) (610 . 614) ("char *input" . 610) (600 . 635) ("ends" . -600) 604 (602 . 604) ("s" . -602) 603 (600 . 603) (599 . 601) (596 . 599) (587 . 596) 587 nil ("
        " . 586) (587 . 595) nil ("        " . -587) 595 (586 . 595) 539 nil ("        " . -495) 503 (494 . 503) 476 nil (nil rear-nonsticky nil 475 . 476) ("
" . -494) (467 . 495) 447 nil ("        price == ar[i].HP;
" . 560) nil ("        " . -559) 567 (558 . 567) 536 nil (584 . 585) (581 . 584) ("]" . -580) (580 . 581) ("]" . -580) (579 . 581) (572 . 580) (567 . 572) ("pri" . -567) 570 (567 . 570) (558 . 567) 555 nil (555 . 556) ("3" . 555) nil (543 . 544) ("1" . 543) nil (" x" . -523) (523 . 525) ("else" . 523) (519 . 523) 524 (523 . 524) (" x" . -523) (523 . 525) ("else" . 523) (519 . 523) 523 (520 . 523) ("s" . -520) ("e" . -521) ("l" . -522) 523 (519 . 523) nil 519 nil (nil rear-nonsticky nil 518 . 519) ("
" . -553) (510 . 554) 509 nil (509 . 510) (507 . 509) (503 . 507) (498 . 503) ("pri" . -498) 501 (497 . 501) (")" . -496) (496 . 497) (")" . -496) (496 . 497) (491 . 496) (486 . 491) ("st" . -486) 488 (485 . 488) ("]" . -484) (484 . 485) ("]" . -484) (483 . 485) (480 . 484) (479 . 481) (476 . 479) (467 . 476) 447 nil ("        " . -446) 454 (445 . 454) 433 nil (465 . 466) (459 . 465) ("+" . -459) 460 (459 . 460) (454 . 459) ("pri" . -454) 457 (454 . 457) (445 . 454) 431 nil ("
        " . 340) ("pri" . 349) nil (349 . 352) (340 . 349) 324 nil ("
        " . 445) (446 . 454) nil ("        " . -446) 454 (445 . 454) 431 nil (305 . 306) (296 . 305) ("c" . -296) ("o" . -297) 298 (292 . 298) (287 . 292) 286 nil ("
    " . 432) ("
" . 437) (433 . 437) ("    " . 434) ("for " . 438) ("()" . 442) ("itn" . 443) nil (443 . 446) (442 . 444) (438 . 442) (434 . 438) ("    " . 433) (437 . 438) (432 . 437) 427 nil (apply 42 237 434 undo--wrap-and-run-primitive-undo 237 434 (("/* " . 241) (" */" . 267) ("/* " . 275) (" */" . 296) ("/* " . 304) (" */" . 336) ("/* " . 344) (" */" . 380) ("/* " . 388) (" */" . 421) ("/* " . 429) (" */" . 459) ("/* " . 467) (" */" . 471) 224)) nil ("
    " . 236) ("char " . 241) ("st" . 246) (247 . 248) ("10" . 247) (247 . 249) ("[]" . 247) ("20]" . 248) (250 . 251) ("]" . 250) (250 . 251) (";" . 251) (" scan" . 252) (253 . 257) ("scanf(const char *restrict format, ...)" . 253) (259 . 286) ("\"" . 259) (259 . 260) ("\"\"" . 259) ("%" . 260) ("[]" . 261) ("^\\n" . 262) nil (" " . 260) nil (260 . 261) nil (" " . 260) nil (270 . 274) ("s" . 270) (")" . 271) (271 . 272) (")" . 271) (";" . 272) nil ("
    " . 273) ("()" . 278) (278 . 280) ("puts" . 278) ("()" . 282) ("ens" . 283) (285 . 286) ("ds" . 285) (283 . 287) ("ends_with(char *input, char letter)" . 283) (293 . 304) ("s" . 293) ("," . 294) (" " . 295) (295 . 296) (297 . 308) ("'" . 297) (297 . 298) ("''" . 297) ("X" . 298) nil (295 . 296) nil (";" . 301) nil (" " . 300) (":" . 301) (" \"" . 302) (303 . 304) ("\"\"" . 303) (301 . 305) ("? \"" . 301) (303 . 304) ("\"\"" . 303) ("YES\"" . 304) (307 . 308) ("\"" . 307) (307 . 308) (" " . 308) (":" . 309) (" \"" . 310) (311 . 312) ("\"\"" . 311) ("NO" . 312) nil ("
" . 557) nil (297 . 298) (" " . 297) (t 26176 39731 404465 322000) nil (297 . 298) ("X" . 297) (t 26176 39511 164986 820000) nil (557 . 558) 313 nil (312 . 314) (311 . 313) ("\"" . -311) (310 . 312) (309 . 310) (308 . 309) ("\"" . -307) (307 . 308) ("\"" . -307) (304 . 308) (303 . 305) ("\"" . -303) (301 . 304) (":" . -301) (" " . -302) 303 ("\"" . -303) ("\"" . 304) (303 . 305) ("\"" . -303) (302 . 304) (301 . 302) (300 . 301) nil (301 . 302) nil ("," . 295) nil (298 . 299) (297 . 299) ("'" . -297) (297 . 298) ("char letter" . 297) (" " . -295) 296 (295 . 296) (294 . 295) (293 . 294) ("char *input" . 293) (283 . 318) ("ends" . -283) 287 (285 . 287) ("s" . -285) 286 (283 . 286) (282 . 284) (278 . 282) ("(" . -278) (")" . 279) (278 . 280) (273 . 278) 272 nil (272 . 273) (271 . 272) (")" . -271) (271 . 272) (270 . 271) ("...)" . 270) nil (260 . 261) nil (" " . 260) nil (260 . 261) nil (262 . 265) (261 . 263) (260 . 261) (259 . 261) ("\"" . -259) (259 . 260) ("const char *restrict format" . 259) (253 . 292) ("scan" . -253) 257 (252 . 257) (251 . 252) ("]" . -250) (250 . 251) ("]" . -250) (248 . 251) (247 . 249) ("1" . -247) ("0" . -248) 249 (247 . 249) ("t" . -247) 248 (246 . 248) (241 . 246) (236 . 241) 224 nil ("
    " . 236) ("int" . 241) nil (241 . 244) (236 . 241) 224 nil ("
    " . 236) ("puts" . 241) ("()" . 245) ("ens" . 246) (248 . 249) ("ds" . 248) (246 . 250) ("ends_with(char *input, char letter)" . 246) nil ("
    " . 236) (237 . 241) nil ("    " . -237) 241 (236 . 241) 235 nil (246 . 281) ("ends" . -246) 250 (248 . 250) ("s" . -248) 249 (246 . 249) (245 . 247) (241 . 245) (236 . 241) 224 nil ("
    " . 236) ("end" . 241) nil (241 . 244) (236 . 241) 224 nil (apply -42 237 476 undo--wrap-and-run-primitive-undo 237 476 ((471 . 474) (467 . 470) (459 . 462) (429 . 432) (421 . 424) (388 . 391) (380 . 383) (344 . 347) (336 . 339) (304 . 307) (296 . 299) (275 . 278) (267 . 270) (241 . 244) 237)) nil (214 . 219) ("in" . -214) 216 (214 . 216) (213 . 214) ("0" . 213) nil ("    if (*input) return 1;
" . 202) 214 nil (240 . 241) (238 . 240) (232 . 238) ("retu" . -232) 236 (234 . 236) (232 . 234) (227 . 232) (226 . 227) (224 . 226) (218 . 224) ("retu" . -218) 222 (217 . 222) (")" . -216) (216 . 217) (")" . -216) (216 . 217) (211 . 216) ("in" . -211) 213 (211 . 213) (210 . 211) ("*" . -210) 211 (210 . 211) (209 . 211) (206 . 209) (201 . 206) (200 . 201) (191 . 200) (")" . -190) (190 . 191) (")" . -190) (190 . 191) (188 . 190) (183 . 188) ("i" . -183) 184 (182 . 184) (181 . 182) (176 . 181) ("i" . -176) 177 (176 . 177) (175 . 176) (171 . 175) (165 . 171) ("let" . -165) 168 (163 . 168) (" " . -163) 164 (161 . 164) (156 . 161) ("in" . -156) 158 (156 . 158) (155 . 156) (154 . 155) (153 . 154) (152 . 154) (148 . 152) (144 . 148) (143 . 145) (142 . 144) (141 . 142) (")" . -140) (140 . 141) (")" . -140) (140 . 141) (135 . 140) ("t" . -135) 136 (135 . 136) ("t" . -135) 136 (128 . 136) (127 . 128) (122 . 127) (121 . 122) (116 . 121) (115 . 117) (102 . 115) (101 . 102) (101 . 102)) (emacs-undo-equiv-table (-159 . -161) (-3 . -5) (6 . 8) (-73 . -75) (5 . 11) (-59 . -61) (-158 . -162) (4 . 12) (8 . 10) (38 . 40) (-14 . -16) (27 . 29) (-81 . -85) (-90 . -92) (-86 . -96) (-85 . -97) (-89 . -93) (-87 . -95) (-2 . -6) (-82 . -84) (-88 . -94) (-8 . -10) (-99 . -101) (-141 . -143) (-140 . -144)))