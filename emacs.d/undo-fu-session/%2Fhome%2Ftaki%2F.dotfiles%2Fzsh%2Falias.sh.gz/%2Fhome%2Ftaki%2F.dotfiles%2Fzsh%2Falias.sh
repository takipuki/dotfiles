((buffer-size . 803) (buffer-checksum . "67f4434637f02138c24666011e27c7c3cf9e11e5"))
((emacs-buffer-undo-list nil (542 . 547) ("copy" . 542) ((marker . 542) . -3) ((marker) . -4) ((marker) . -4) ((marker) . -4) ((marker) . -4) nil (535 . 538) ("cpy" . 535) ((marker . 542) . -2) ((marker) . -3) ((marker) . -3) nil (nil rear-nonsticky nil 528 . 529) ("
" . -546) (528 . 547) 527 nil (511 . 528) (510 . 511) (t 26154 26237 882178 591000) 494) (emacs-pending-undo-list ("
" . -110) ((marker . 639) . -1) ((marker . 110) . -1) ((marker . 110) . -1) ((marker . 110) . -1) 90 nil (nil rear-nonsticky nil 111 . 112) ("
" . -566) (111 . 567) nil ("https://nurulalamador.github.io/UIUQuestionBank/question.html?id=CSE1112&term=final&tri=231-B" . 111) ((marker . 631) . -92) ((marker . 639) . -92) ((marker . 546) . -92) ((marker . 110) . -92) (nil rear-nonsticky nil 203 . 204) nil (nil rear-nonsticky nil 203 . 204) (nil fontified nil 111 . 204) (111 . 204) nil ("   " . -111) ((marker . 546) . -3) 114 (110 . 114) 95 nil (114 . 117) (110 . 114) 109 nil (90 . 110) (89 . 90) ("
" . -89) ((marker . 546) . -1) ("
" . -90) ((marker . 546) . -1) 91 (89 . 91) (83 . 89) nil (82 . 83) 82 nil ("
1. WAP
   ```c:line-numbers
   #include <stdio.h>
   
   int isEven(int n) {
       return !(n % 2);
   }
   
   int ComputeEvenSum(int *ar, int n) {
       int sum = 0;
       for (int i = 0; i < n; i++)
           if (isEven(ar[i])) sum += ar[i];
       return sum;
   }
   
   int main() {
       int ar[] = {1, 2, 3, 2};
       printf(\"%d\\n\", ComputeEvenSum(ar, 4));
   }
   ```

2. output
   ```:line-numbers
   1 3 5 2
   8 3 4 2
   16 3 4 12
   32 29 4 12
   ```
   

## 02

1. output
   ```:line-numbers
   Hello
   # Gen Z
   ```

2. WAP
   ```c:line-numbers
   #include <stdio.h>
   
   int main() {
       char s[100];
       int slen = 0;
       for (; (s[slen] = getchar()) != '\\n'; slen++) {
           if (s[slen] >= 'A' && s[slen] <= 'Z')
               s[slen] += ' ';
       }
       s[slen] = '\\0';
   
       char sub[100];
       int sublen = 0;
       for (; (sub[sublen] = getchar()) != '\\n'; sublen++) {
           if (sub[sublen] >= 'A' && sub[sublen] <= 'Z')
               sub[sublen] += ' ';
       }
       sub[sublen] = '\\0';
   
       int count = 0;
       for (int i = 0; i < slen - (sublen - 1); i++) {
           if (s[i] == sub[0]) {
               int flag = 1;
               for (int j = 1; j < sublen; j++)
                   if (s[i+j] != sub[j])
                       flag = 0;
               if (flag) count++;
           }
       }
       printf(\"%d\\n\", count);
   }
   ```
   

## 03

```c:line-numbers
#include <stdio.h>
#include <string.h>

typedef struct {
    char name[50], country[50], type[10];
    int wickets[30], runs[30], matches;
    float score;
} Cricketer;

#define n 100

int main() {
    Cricketer ar[n];
    int max_score = 0, max_indx = 0;
    for (int i = 0; i < n; i++) {
        scanf(\" %[^\\n]\", ar[i].name);
        scanf(\" %[^\\n]\", ar[i].country);
        scanf(\" %[^\\n]\", ar[i].type);

        int wicks = 0;
        for (int j = 0; j < 30; j++) {
            scanf(\"%d\", &ar[i].wickets[j]);
            wicks += ar[i].wickets[j];
        }

        int runs = 0;
        for (int j = 0; j < 30; j++) {
            scanf(\"%d\", &ar[i].runs[j]);
            runs += ar[i].runs[j];
        }

        scanf(\"%d\", &ar[i].matches);

        if (strcmp(ar[i].type, \"bowler\") == 0)
            ar[i].score = (float)wicks / ar[i].matches;
        else
            ar[i].score = (float)runs / ar[i].matches;

        if (ar[i].score > max_score) {
            max_score = ar[i].score;
            max_indx = i;
        }
    }

    printf(\"Name: %s\\n\", ar[max_indx].name);
    printf(\"Country: %s\\n\", ar[max_indx].country);
    printf(\"Type: %s\\n\", ar[max_indx].type);

    printf(\"Wickets:\");
    for (int i = 0; i < 30; i++)
        printf(\" %d\", ar[max_indx].wickets[i]);
    putchar('\\n');

    printf(\"Runs: \");
    for (int i = 0; i < 30; i++)
        printf(\" %d\", ar[max_indx].runs[i]);
    putchar('\\n');
    
    printf(\"Matches: %d\\n\", ar[max_indx].matches);
    printf(\"Score: %.2f\\n\", ar[max_indx].score);
}
```


## 04

1. output
   ```:line-numbers
   10 21 40
   20 24 40
   ```
   
2. output
   ```:line-numbers
   0 1 2 0 3 0 1
   ```
   
   
## 05

1. WAP
   ```c:line-numbers
   #include <stdio.h>
   
   int main() {
       FILE *fptr = fopen(\"sample.txt\", \"r\");
       int sum = 0;
       for (int i; fscanf(fptr, \" %d \", &i) != EOF;) {
           if (i % 2 == 0 && i % 4 == 0)
               sum += i;
       }
   
       printf(\"%d\\n\", sum);
   
       fclose(fptr);
   }
   ```
   
2. WAP
   ```c:line-numbers
   #include <stdio.h>
   
   int sumOfOddElements(int *arr, int size) {
       if (size == 0) return 0;
       if (*arr % 2)
           return *arr + sumOfOddElements(arr+1, size-1);
       return sumOfOddElements(arr+1, size-1);
   }
   
   int main() {
       int numbers[] = {10, 21, 35, 42, 57, 68, 73};
       int n = sizeof(numbers) / sizeof(numbers[0]);
       int sum = sumOfOddElements(numbers, n);
       printf(\"Sum of odd elements: %d\\n\", sum);
       return 0;
   }
   ```
" . 82) ((marker . 631) . -3983) nil (73 . 74) ("t" . -73) ((marker . 546) . -1) 74 (69 . 74) ("ummer" . 69) ((marker . 631) . -4) (t 26172 59835 480038 862000) nil (69 . 74) ("sp" . 69) ((marker . 639) . -1) ((marker . 546) . -1) ((marker . 69) . -1) ((marker . 69) . -1) nil (69 . 71) ("ummer" . 69) ((marker . 631) . -4) (t 26172 59835 480038 862000) nil ("
" . -1) nil (1 . 4067) (t . -1) nil ("
---
head:
  - - link
    - href: /custom.css
      rel: stylesheet
---

# 23 Summer

## 01

1. WAP
   ```c:line-numbers
   #include <stdio.h>
   
   int isEven(int n) {
       return !(n % 2);
   }
   
   int ComputeEvenSum(int *ar, int n) {
       int sum = 0;
       for (int i = 0; i < n; i++)
           if (isEven(ar[i])) sum += ar[i];
       return sum;
   }
   
   int main() {
       int ar[] = {1, 2, 3, 2};
       printf(\"%d\\n\", ComputeEvenSum(ar, 4));
   }
   ```

2. output
   ```:line-numbers
   1 3 5 2
   8 3 4 2
   16 3 4 12
   32 29 4 12
   ```
   

## 02

1. output
   ```:line-numbers
   Hello
   # Gen Z
   ```

2. WAP
   ```c:line-numbers
   #include <stdio.h>
   
   int main() {
       char s[100];
       int slen = 0;
       for (; (s[slen] = getchar()) != '\\n'; slen++) {
           if (s[slen] >= 'A' && s[slen] <= 'Z')
               s[slen] += ' ';
       }
       s[slen] = '\\0';
   
       char sub[100];
       int sublen = 0;
       for (; (sub[sublen] = getchar()) != '\\n'; sublen++) {
           if (sub[sublen] >= 'A' && sub[sublen] <= 'Z')
               sub[sublen] += ' ';
       }
       sub[sublen] = '\\0';
   
       int count = 0;
       for (int i = 0; i < slen - (sublen - 1); i++) {
           if (s[i] == sub[0]) {
               int flag = 1;
               for (int j = 1; j < sublen; j++)
                   if (s[i+j] != sub[j])
                       flag = 0;
               if (flag) count++;
           }
       }
       printf(\"%d\\n\", count);
   }
   ```
   

## 03

```c:line-numbers
#include <stdio.h>
#include <string.h>

typedef struct {
    char name[50], country[50], type[10];
    int wickets[30], runs[30], matches;
    float score;
} Cricketer;

#define n 100

int main() {
    Cricketer ar[n];
    int max_score = 0, max_indx = 0;
    for (int i = 0; i < n; i++) {
        scanf(\" %[^\\n]\", ar[i].name);
        scanf(\" %[^\\n]\", ar[i].country);
        scanf(\" %[^\\n]\", ar[i].type);

        int wicks = 0;
        for (int j = 0; j < 30; j++) {
            scanf(\"%d\", &ar[i].wickets[j]);
            wicks += ar[i].wickets[j];
        }

        int runs = 0;
        for (int j = 0; j < 30; j++) {
            scanf(\"%d\", &ar[i].runs[j]);
            runs += ar[i].runs[j];
        }

        scanf(\"%d\", &ar[i].matches);

        if (strcmp(ar[i].type, \"bowler\") == 0)
            ar[i].score = (float)wicks / ar[i].matches;
        else
            ar[i].score = (float)runs / ar[i].matches;

        if (ar[i].score > max_score) {
            max_score = ar[i].score;
            max_indx = i;
        }
    }

    printf(\"Name: %s\\n\", ar[max_indx].name);
    printf(\"Country: %s\\n\", ar[max_indx].country);
    printf(\"Type: %s\\n\", ar[max_indx].type);

    printf(\"Wickets:\");
    for (int i = 0; i < 30; i++)
        printf(\" %d\", ar[max_indx].wickets[i]);
    putchar('\\n');

    printf(\"Runs: \");
    for (int i = 0; i < 30; i++)
        printf(\" %d\", ar[max_indx].runs[i]);
    putchar('\\n');
    
    printf(\"Matches: %d\\n\", ar[max_indx].matches);
    printf(\"Score: %.2f\\n\", ar[max_indx].score);
}
```


## 04

1. output
   ```:line-numbers
   10 21 40
   20 24 40
   ```
   
2. output
   ```:line-numbers
   0 1 2 0 3 0 1
   ```
   
   
## 05

1. WAP
   ```c:line-numbers
   #include <stdio.h>
   
   int main() {
       FILE *fptr = fopen(\"sample.txt\", \"r\");
       int sum = 0;
       for (int i; fscanf(fptr, \" %d \", &i) != EOF;) {
           if (i % 2 == 0 && i % 4 == 0)
               sum += i;
       }
   
       printf(\"%d\\n\", sum);
   
       fclose(fptr);
   }
   ```
   
2. WAP
   ```c:line-numbers
   #include <stdio.h>
   
   int sumOfOddElements(int *arr, int size) {
       if (size == 0) return 0;
       if (*arr % 2)
           return *arr + sumOfOddElements(arr+1, size-1);
       return sumOfOddElements(arr+1, size-1);
   }
   
   int main() {
       int numbers[] = {10, 21, 35, 42, 57, 68, 73};
       int n = sizeof(numbers) / sizeof(numbers[0]);
       int sum = sumOfOddElements(numbers, n);
       printf(\"Sum of odd elements: %d\\n\", sum);
       return 0;
   }
   ```
" . 1) ((marker . 639) . -36) ((marker . 111) . -71) ((marker . 631) . -71) ((marker . 639) . -48) ((marker . 1) . -67) ((marker . 1) . -67) ((marker* . 625) . 4005) ((marker . 621) . -68) ((marker* . 640) . 4005) ((marker . 1) . -71) ((marker . 1) . -71) ((marker . 1) . -71) ((marker . 1) . -71) ((marker . 1) . -71) ((marker . 513) . -36) ((marker . 546) . -48) ((marker . 1) . -48) nil ("
ol li {
    list-style-type: lower-alpha;
}
" . 72) ((marker . 111) . -44) ((marker . 631) . -44) ((marker* . 625) . 44) ((marker . 1) . -44) ((marker . 1) . -44) ((marker . 1) . -44) ((marker . 1) . -43) ((marker . 1) . -43) (116 . 117) (nil rear-nonsticky nil 72 . 73) nil (1 . 73) ("
" . 1) ("<style>" . 1) ((marker . 639) . -5) ((marker . 513) . -5) nil ("
<style>
" . 52) ((marker . 111) . -1) ((marker . 631) . -8) ((marker . 639) . -2) ((marker* . 640) . 7) ((marker . 546) . -2) ((marker . 1) . -2) ((marker . 1) . -2) (60 . 61) (nil rear-nonsticky nil 52 . 53) nil ("/" . 54) nil (54 . 55) nil (nil rear-nonsticky nil 52 . 53) ("
" . -60) (52 . 61) 51 nil (1 . 8) (1 . 2) ("
---
head:
  - - link
    - href: /custom.css
      rel: stylesheet
---
" . 1) ((marker . 639) . -36) ((marker . 631) . -71) ((marker . 639) . -68) ((marker . 1) . -67) ((marker . 1) . -67) ((marker . 621) . -68) ((marker . 513) . -36) nil (nil rear-nonsticky nil 72 . 73) ("
" . -116) (72 . 117) 71 nil ("
ol li {
    list-style-type: lower-alpha;
}
" . 68) ((marker . 546) . -1) ((marker . 111) . -1) ((marker . 631) . -44) ((marker . 639) . -1) ((marker . 1) . -1) ((marker . 1) . -1) (112 . 113) (nil rear-nonsticky nil 68 . 69) nil (nil rear-nonsticky nil 68 . 69) ("
" . -112) (68 . 113) 61 nil (1 . 4077) (t . -1)) (emacs-undo-equiv-table (-18 . -22) (-17 . -23) (-16 . -24) (-11 . -13) (-3 . -5) (-15 . t) (-24 . -26) (-19 . -21)))