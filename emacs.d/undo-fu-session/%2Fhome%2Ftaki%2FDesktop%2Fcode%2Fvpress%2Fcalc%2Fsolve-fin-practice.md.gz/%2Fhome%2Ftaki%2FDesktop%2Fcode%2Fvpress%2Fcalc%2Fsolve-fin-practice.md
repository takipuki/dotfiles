((buffer-size . 312) (buffer-checksum . "76545659553b04cfe1bf88632e82b05b0fb9b240"))
((emacs-buffer-undo-list nil (nil rear-nonsticky nil 163 . 164) (nil fontified nil 62 . 164) (62 . 164) (t 26171 40248 525721 761000) nil (209 . 210) ("`" . 209) nil (203 . 204) ("`" . 203) ((marker) . -1) (t 26171 486 382678 833000) nil (196 . 211) nil ("   
5. `a + b`
" . 196) ((marker . 163) . -14) ((marker . 311) . -13) ((marker* . 312) . 1) ((marker . 313) . -15) ((marker . 313) . -15) ((marker . 313) . -15) ((marker . 313) . -15) ((marker . 313) . -15) ((marker . 313) . -15) ((marker . 313) . -15) ((marker . 313) . -15) ((marker . 313) . -15) ((marker . 311) . -13) ((marker . 62) . -13) 209 (t 26171 486 382678 833000) nil (209 . 210) (200 . 209) ("   " . -200) ((marker . 62) . -3) 203 (199 . 203) (195 . 199) 194 nil (194 . 195) nil (74 . 75) (t 26171 228 227768 165000) nil ("4" . 74) ((marker . 176) . -1) ((marker . 176) . -1) ((marker . 176) . -1) ((marker . 176) . -1) ((marker . 176) . -1) ((marker . 176) . -1) ((marker . 176) . -1) ((marker . 176) . -1) nil (74 . 75) (t 26171 228 227768 165000) nil ("
   " . 193) ((marker . 62) . -1) ((marker . 296) . -4) ((marker . 296) . -4) ((marker . 296) . -4) ((marker . 296) . -4) ((marker . 296) . -4) ((marker . 296) . -4) ((marker . 296) . -4) ((marker . 296) . -4) ((marker . 296) . -4) ((marker) . -1) ((marker . 296) . -1) ((marker . 296) . -1) ((marker . 296) . -1) ((marker . 296) . -1) ((marker . 62) . -4) ((marker . 296) . -1) ((marker . 296) . -1) ((marker . 296) . -1) ((marker . 296) . -1) ((marker . 296) . -1) ((marker . 296) . -1) ((marker . 296) . -1) (194 . 197) nil ("   " . -194) ((marker . 296) . -3) ((marker . 296) . -3) ((marker . 296) . -3) ((marker . 296) . -3) ((marker . 62) . -3) ((marker . 296) . -3) ((marker . 296) . -3) ((marker . 296) . -3) ((marker . 296) . -3) ((marker . 296) . -3) ((marker) . -3) 197 (193 . 197) (t 26171 228 227768 165000) 192 nil (123 . 124) ("\\" . -123) ((marker . 62) . -1) 124 nil ("&" . 132) nil ("&" . 82) nil ("   \\end{aligned}
" . 191) ((marker . 163) . -16) ((marker . 62) . -3) 194 nil ("$" . 212) nil ("   \\begin{aligned}
" . 75) ((marker . 163) . -18) ((marker . 62) . -3) 78 nil ("$" . 74) (t 26171 210 746982 367000) nil ("
" . 1) ((marker* . 312) . 1) nil ("<script src=\"https://polyfill.io/v3/polyfill.min.js?features=es6\"></script>
<script id=\"MathJax-script\" async src=\"https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js\"></script>" . 1) ((marker . 62) . -104) ((marker . 163) . -109) ((marker . 311) . -76) ((marker* . 312) . 9) ((marker . 62) . -15) ((marker . 1) . -76) ((marker . 1) . -76) ((marker . 1) . -76) ((marker . 1) . -76) ((marker . 1) . -91) ((marker . 1) . -176) ((marker . 311) . -76) ((marker . 62) . -15) ((marker . 1) . -176) ((marker . 1) . -104) ((marker . 1) . -104) ((marker . 1) . -76) ((marker . 1) . -15) (nil rear-nonsticky nil 185 . 186) nil (1 . 77) nil ("
" . 110) nil (29 . 35) nil ("
" . 95) (t 26171 201 519900 812000) nil (95 . 96) nil ("async " . 29) ((marker . 163) . -5) nil (110 . 111) 1 nil (1 . 111) (t 26171 161 641440 96000) nil ("<script id=\"MathJax-script\" async src=\"https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js\"></script>
" . 1) ((marker . 163) . -109) ((marker* . 312) . 1) ((marker . 1) . -15) (t 26171 110 89118 483000) nil (1 . 111) nil ("
<script id=\"MathJax-script\" async src=\"https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js\"></script>
" . 234) ((marker . 62) . -1) ((marker . 163) . -110) ((marker . 62) . -1) ((marker . 313) . -1) ((marker . 313) . -1) ((marker . 62) . -1) ((marker . 313) . -1) (344 . 345) (nil rear-nonsticky nil 234 . 235) nil ("
" . 344) (t 26171 97 471883 170000) nil (344 . 345) 235 nil (nil rear-nonsticky nil 234 . 235) ("
" . -344) (234 . 345) nil ("<script id=\"MathJax-script\" async src=\"https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js\"></script>
" . 1) ((marker . 163) . -109) ((marker . 311) . -15) ((marker* . 312) . 1) ((marker . 62) . -15) ((marker . 1) . -15) ((marker . 311) . -15) (t 26171 63 377012 270000) nil ("<script src=\"https://polyfill.io/v3/polyfill.min.js?features=es6\"></script>
" . 1) ((marker . 163) . -75) ((marker . 311) . -76) ((marker . 62) . -76) ((marker . 1) . -76) ((marker . 1) . -76) ((marker . 1) . -76) ((marker . 1) . -76) ((marker . 311) . -76) ((marker . 62) . -15) 16 (t 26171 47 682970 709000) nil (nil rear-nonsticky nil 185 . 186) (nil fontified nil 1 . 186) (1 . 186) nil (1 . 2) (t 26171 3 147625 894000) nil (70 . 71) ("1" . 70) (t 26170 65524 163615 191000) nil (142 . 145) (t 26170 65519 673412 145000) nil (" " . 98) nil ("    " . -103) (95 . 103) 137 nil ("   " . -99) (95 . 99) 137 nil (200 . 203) (198 . 200) ("}" . -197) (197 . 198) ("}" . -197) (191 . 198) ("c" . -191) ((marker . 311) . -1) ((marker . 311) . -1) ((marker . 62) . -1) ("o" . -192) ((marker . 311) . -1) ((marker . 311) . -1) ((marker . 62) . -1) 193 (191 . 193) (139 . 146) ("   " . 139) 187 (186 . 188) ("}" . -185) (185 . 186) ("}" . -185) (184 . 186) (172 . 185) ("\\" . -172) ((marker . 62) . -1) ("," . -173) ((marker . 62) . -1) 174 (171 . 174) ("}" . -170) (170 . 171) ("}" . -170) (164 . 171) (163 . 165) ("}" . -162) (162 . 163) ("}" . -162) (156 . 163) (142 . 157) (138 . 142) 95 nil (133 . 138) ("}" . -132) (132 . 133) ("}" . -132) (126 . 133) (124 . 126) ("c" . -124) ((marker . 311) . -1) ((marker . 311) . -1) ((marker . 62) . -1) 125 (124 . 125) (123 . 125) ("}" . -122) (122 . 123) ("}" . -122) (116 . 123) (110 . 117) nil (99 . 105) nil (98 . 104) (95 . 98) (95 . 96) 101 nil (99 . 102) ("begin" . 99) ((marker . 163) . -4) nil (nil rear-nonsticky nil 97 . 98) ("
" . -113) (94 . 114) 92 nil (86 . 93) (79 . 87) (76 . 79) (75 . 76) 74 nil (76 . 81) (75 . 76) ("\\" . -75) ((marker . 62) . -1) 76 (75 . 76) ("\\" . -75) ((marker . 62) . -1) 76 (73 . 76) ("$\\frac{1}{2}$" . 73) ((marker . 163) . -12) ((marker . 175) . -12) ((marker . 175) . -12) ((marker . 175) . -12) ((marker . 175) . -12) ((marker . 175) . -12) ((marker . 175) . -12) ((marker . 175) . -12) ((marker . 175) . -11) ((marker . 175) . -11) nil ("2. 
" . 87) ((marker . 163) . -3) ((marker . 311) . -3) ((marker* . 312) . 1) ((marker . 62) . -3) ((marker . 313) . -3) ((marker . 313) . -3) ((marker . 313) . -3) ((marker . 311) . -3) ((marker . 62) . -2) 89 nil ("$1/2$" . 90) ((marker . 163) . -4) ((marker . 311) . -4) ((marker . 62) . -4) ((marker . 313) . -4) ((marker . 313) . -4) ((marker . 311) . -4) ((marker . 313) . -4) nil (90 . 91) ("`" . 90) nil (94 . 95) ("`" . 94) (t 26170 65057 868983 149000) nil (94 . 95) ("$" . 94) nil (90 . 91) ("$" . 90) ((marker) . -1) (t 26170 65041 34869 899000) nil (90 . 95) ("there" . 90) ((marker . 163) . -4) ((marker . 62) . -4) 94 (t 26170 65028 920974 699000) nil (73 . 74) ("\\()" . 73) ((marker . 62) . -2) ((marker . 62) . -2) ((marker . 175) . -2) nil (75 . 76) nil (")" . 86) ((marker . 62) . -1) ((marker . 163) . -1) ((marker* . 312) . 1) ((marker . 175) . -1) ((marker . 175) . -1) (nil rear-nonsticky nil 86 . 87) nil ("\\" . 86) ((marker . 175) . -1) ((marker . 175) . -1) nil (88 . 89) (t 26170 64861 309804 629000) nil ("$" . 88) nil (86 . 87) nil (nil rear-nonsticky nil 86 . 87) (nil fontified nil 86 . 87) (86 . 87) 85 nil (")" . 75) ((marker* . 312) . 1) nil (73 . 76) ("$" . 73) (t 26170 64844 985700 962000) nil (85 . 86) ("}" . -84) (84 . 85) ("}" . -84) (83 . 85) (82 . 84) nil ("/" . 81) nil ("}" . -82) (82 . 83) ("}" . -82) (80 . 83) (73 . 81) ("hello" . 73) ((marker . 163) . -4) ((marker . 62) . -2) 75 nil (73 . 78) ("there" . 73) ((marker . 311) . -4) ((marker . 62) . -4) ((marker . 311) . -4) ((marker . 62) . -4) ((marker . 175) . -4) (t 26170 64776 865803 750000) nil (73 . 78) ("hello" . 73) ((marker . 163) . -4) ((marker . 62) . -2) 75 (t 26170 64772 862279 703000) nil ("
" . -1) ((marker* . 1) . 1) (t 26170 64762 768465 86000) nil ("---
head:
  - - link
    - href: /custom.css
      rel: stylesheet
---
" . 1) ((marker . 163) . -70) ((marker . 62) . -67) ((marker . 1) . -67) (t 26170 64637 75747 285000) nil (159 . 160) 158 nil ("r" . -159) ((marker . 62) . -1) 160 (151 . 160) (150 . 151) 149 nil (145 . 150) (142 . 145) (140 . 142) (136 . 140) (134 . 136) (133 . 134) 125 nil ("ol li
" . 81) ((marker . 163) . -5) ((marker . 311) . -4) ((marker . 62) . -4) ((marker . 9) . -4) ((marker . 9) . -4) ((marker . 9) . -4) ((marker . 9) . -5) ((marker . 9) . -5) ((marker . 9) . -5) ((marker . 9) . -4) ((marker . 311) . -4) nil (nil rear-nonsticky nil 86 . 87) ("
" . -130) (86 . 131) 85 nil ("
    list-style-type: lower-alpha;
" . 86) ((marker . 62) . -1) ((marker . 163) . -34) ((marker . 62) . -5) ((marker . 62) . -5) ((marker . 9) . -5) ((marker . 9) . -5) (120 . 121) (nil rear-nonsticky nil 90 . 91) nil (nil rear-nonsticky nil 90 . 91) ("
" . -120) (86 . 121) 85 nil (81 . 86) ("u" . -81) ((marker . 62) . -1) 82 (81 . 82) (81 . 82) 88 nil (88 . 89) (83 . 88) ("sty" . -83) ((marker . 311) . -3) ((marker . 311) . -3) ((marker . 62) . -3) 86 (81 . 86) (80 . 81) 73 nil ("
" . -72) nil (74 . 81) (73 . 74) 73 nil ("2" . -73) ((marker . 311) . -1) ((marker . 311) . -1) ((marker . 62) . -1) ("7" . -74) ((marker . 311) . -1) ((marker . 311) . -1) ((marker . 62) . -1) ("." . -75) ((marker . 311) . -1) ((marker . 311) . -1) ((marker . 62) . -1) (" " . -76) ((marker . 311) . -1) ((marker . 311) . -1) ((marker . 62) . -1) 77 ("1" . -77) ((marker . 311) . -1) ((marker . 311) . -1) ((marker . 62) . -1) ("." . -78) ((marker . 62) . -1) 79 (73 . 79) (72 . 73) (t 26170 64317 226353 0) 72 nil ("
# 23 Summer

## 01

1. WAP
   ```c:line-numbers
   #include <stdio.h>
   
   int isEven(int n) {
       return !(n % 2);
   }
   
   int ComputeEvenSum(int *ar, int n) {
       int sum = 0;
       for (int i = 0; i < n; i++)
           if (isEven(ar[i])) sum += ar[i];
       return sum;
   }
   
   int main() {
       int ar[] = {1, 2, 3, 2};
       printf(\"%d\\n\", ComputeEvenSum(ar, 4));
   }
   ```

2. output
   ```:line-numbers
   1 3 5 2
   8 3 4 2
   16 3 4 12
   32 29 4 12
   ```
   

## 02

1. output
   ```:line-numbers
   Hello
   # Gen Z
   ```

2. WAP
   ```c:line-numbers
   #include <stdio.h>
   
   int main() {
       char s[100];
       int slen = 0;
       for (; (s[slen] = getchar()) != '\\n'; slen++) {
           if (s[slen] >= 'A' && s[slen] <= 'Z')
               s[slen] += ' ';
       }
       s[slen] = '\\0';
   
       char sub[100];
       int sublen = 0;
       for (; (sub[sublen] = getchar()) != '\\n'; sublen++) {
           if (sub[sublen] >= 'A' && sub[sublen] <= 'Z')
               sub[sublen] += ' ';
       }
       sub[sublen] = '\\0';
   
       int count = 0;
       for (int i = 0; i < slen - (sublen - 1); i++) {
           if (s[i] == sub[0]) {
               int flag = 1;
               for (int j = 1; j < sublen; j++)
                   if (s[i+j] != sub[j])
                       flag = 0;
               if (flag) count++;
           }
       }
       printf(\"%d\\n\", count);
   }
   ```
   

## 03

```c:line-numbers
#include <stdio.h>
#include <string.h>

typedef struct {
    char name[50], country[50], type[10];
    int wickets[30], runs[30], matches;
    float score;
} Cricketer;

#define n 100

int main() {
    Cricketer ar[n];
    int max_score = 0, max_indx = 0;
    for (int i = 0; i < n; i++) {
        scanf(\" %[^\\n]\", ar[i].name);
        scanf(\" %[^\\n]\", ar[i].country);
        scanf(\" %[^\\n]\", ar[i].type);

        int wicks = 0;
        for (int j = 0; j < 30; j++) {
            scanf(\"%d\", &ar[i].wickets[j]);
            wicks += ar[i].wickets[j];
        }

        int runs = 0;
        for (int j = 0; j < 30; j++) {
            scanf(\"%d\", &ar[i].runs[j]);
            runs += ar[i].runs[j];
        }

        scanf(\"%d\", &ar[i].matches);

        if (strcmp(ar[i].type, \"bowler\") == 0)
            ar[i].score = (float)wicks / ar[i].matches;
        else
            ar[i].score = (float)runs / ar[i].matches;

        if (ar[i].score > max_score) {
            max_score = ar[i].score;
            max_indx = i;
        }
    }

    printf(\"Name: %s\\n\", ar[max_indx].name);
    printf(\"Country: %s\\n\", ar[max_indx].country);
    printf(\"Type: %s\\n\", ar[max_indx].type);

    printf(\"Wickets:\");
    for (int i = 0; i < 30; i++)
        printf(\" %d\", ar[max_indx].wickets[i]);
    putchar('\\n');

    printf(\"Runs: \");
    for (int i = 0; i < 30; i++)
        printf(\" %d\", ar[max_indx].runs[i]);
    putchar('\\n');
    
    printf(\"Matches: %d\\n\", ar[max_indx].matches);
    printf(\"Score: %.2f\\n\", ar[max_indx].score);
}
```


## 04

1. output
   ```:line-numbers
   10 21 40
   20 24 40
   ```
   
2. output
   ```:line-numbers
   0 1 2 0 3 0 1
   ```
   
   
## 05

1. WAP
   ```c:line-numbers
   #include <stdio.h>
   
   int main() {
       FILE *fptr = fopen(\"sample.txt\", \"r\");
       int sum = 0;
       for (int i; fscanf(fptr, \" %d \", &i) != EOF;) {
           if (i % 2 == 0 && i % 4 == 0)
               sum += i;
       }
   
       printf(\"%d\\n\", sum);
   
       fclose(fptr);
   }
   ```
   
2. WAP
   ```c:line-numbers
   #include <stdio.h>
   
   int sumOfOddElements(int *arr, int size) {
       if (size == 0) return 0;
       if (*arr % 2)
           return *arr + sumOfOddElements(arr+1, size-1);
       return sumOfOddElements(arr+1, size-1);
   }
   
   int main() {
       int numbers[] = {10, 21, 35, 42, 57, 68, 73};
       int n = sizeof(numbers) / sizeof(numbers[0]);
       int sum = sumOfOddElements(numbers, n);
       printf(\"Sum of odd elements: %d\\n\", sum);
       return 0;
   }
   ```
" . 72) ((marker . 163) . -4003) nil ("
" . -1) nil (1 . 4077) (t . -1)) (emacs-pending-undo-list (".render" . 3055) ((marker . 302) . -6) ((marker . 62) . -6) ((marker . 3066) . -6) (t 26171 40466 288738 79000) nil (3055 . 3062) (t 26171 40199 400197 412000) nil ("2" . 3055) nil ("3" . 83) nil ("3" . 57) nil ("let MathJax = {
  loader: {load: ['input/asciimath', 'output/chtml', 'ui/menu']},
};
" . 88) ((marker . 302) . -82) ((marker . 3086) . -84) ((marker . 302) . -3) ((marker . 3085) . -82) ((marker . 88) . -83) ((marker . 88) . -3) ((marker . 88) . -3) ((marker . 88) . -3) ((marker . 311) . -3) nil (3142 . 3143) ("3" . 3142) nil ("
  " . 3157) ((marker . 302) . -1) ((marker . 3001) . -1) ((marker . 3086) . -1) ((marker . 3001) . -1) ((marker . 3085) . -1) ((marker . 3007) . -1) ((marker . 3086) . -1) ((marker . 3086) . -1) ((marker . 3086) . -1) ((marker . 3086) . -1) ((marker . 3086) . -1) ((marker . 3086) . -1) ((marker . 3086) . -1) ((marker . 3086) . -1) ((marker . 3086) . -1) ((marker . 3086) . -1) ((marker . 3086) . -1) ((marker . 3086) . -1) ((marker . 3086) . -1) ((marker . 3086) . -1) ((marker . 3086) . -1) ((marker . 3086) . -1) ((marker . 3086) . -1) ((marker . 62) . -3) ((marker . 3086) . -1) (3158 . 3160) nil (" markdown: {
    config: (md) => {
      md.use(mathjax3);
    },
  },
  vue: {
    template: {
      compilerOptions: {
        isCustomElement: (tag) => customElements.includes(tag),
      },
    },
  }," . 3158) ((marker . 3001) . -66) ((marker . 3086) . -69) ((marker . 3001) . -71) ((marker . 3085) . -202) ((marker . 3007) . -72) ((marker . 3086) . -2) ((marker . 3086) . -2) ((marker . 3086) . -3) ((marker . 3086) . -3) ((marker . 3086) . -59) ((marker . 3086) . -59) ((marker . 3086) . -55) ((marker . 3086) . -55) ((marker . 3086) . -1) ((marker . 3086) . -1) ((marker . 3086) . -70) ((marker . 3086) . -69) ((marker . 3086) . -69) ((marker . 3086) . -66) ((marker . 3086) . -66) ((marker . 3086) . -72) ((marker . 3086) . -72) (nil fontified t 3357 . 3359) (nil fontified t 3356 . 3357) (nil fontified t 3350 . 3356) (nil fontified t 3349 . 3350) (nil fontified t 3341 . 3349) (nil fontified t 3340 . 3341) (nil fontified t 3337 . 3340) (nil fontified t 3336 . 3337) (nil fontified t 3309 . 3336) (nil fontified t 3308 . 3309) (nil fontified t 3305 . 3308) (nil fontified t 3304 . 3305) (nil fontified t 3278 . 3304) (nil fontified t 3277 . 3278) (nil fontified t 3253 . 3277) (nil fontified t 3252 . 3253) (nil fontified t 3237 . 3252) (nil fontified t 3236 . 3237) (nil fontified t 3229 . 3236) (nil fontified t 3228 . 3229) (nil fontified t 3227 . 3228) (nil fontified t 3226 . 3227) (nil fontified t 3224 . 3226) (nil fontified t 3222 . 3224) (nil fontified t 3221 . 3222) (nil fontified t 3217 . 3221) (nil fontified t 3215 . 3217) (nil fontified t 3214 . 3215) (nil fontified t 3213 . 3214) (nil fontified t 3206 . 3213) (nil fontified t 3205 . 3206) (nil fontified t 3193 . 3205) (nil fontified t 3192 . 3193) (nil fontified t 3191 . 3192) (nil fontified t 3187 . 3191) (nil fontified t 3186 . 3187) (nil fontified t 3184 . 3186) (nil fontified t 3183 . 3184) (nil fontified t 3171 . 3183) (nil fontified t 3170 . 3171) (nil fontified t 3169 . 3170) (nil fontified t 3159 . 3169) (nil fontified t 3158 . 3159) (nil rear-nonsticky t 3362 . 3363) nil (3086 . 3158) nil (" " . 3087) (t 26171 535 574880 233000) nil (3158 . 3293) nil (3157 . 3158) nil ("
" . -3157) ((marker . 302) . -1) ((marker . 3001) . -1) ((marker . 3086) . -1) ((marker . 3001) . -1) ((marker . 3085) . -1) ((marker . 3007) . -1) ((marker . 3087) . -1) 3153 nil ("  vue: {
    template: {
      compilerOptions: {
        isCustomElement: (tag) => customElements.includes(tag),
      },
    },
  },
" . 3158) ((marker . 302) . -131) ((marker* . 45) . 1) ((marker . 3086) . -134) ((marker . 3085) . -131) ((marker . 3007) . -1) ((marker . 3087) . -135) ((marker . 62) . -1) 3159 (t 26171 535 574880 233000) nil (3142 . 3143) ("2" . 3142) nil (3142 . 3143) ("3" . 3142) (t 26171 535 574880 233000) nil (3087 . 3088) 3085 nil (" " . 3087) nil (3087 . 3088) 3089 nil ("  markdown: {
    config: (md) => {
      md.use(mathjax3);
    },
  },
" . 3086) ((marker . 302) . -70) ((marker . 3086) . -71) ((marker . 3085) . -70) ((marker . 3085) . -70) ((marker . 3007) . -3) ((marker . 3007) . -3) ((marker . 3007) . -3) ((marker . 3079) . -67) ((marker . 3079) . -67) ((marker . 3016) . -12) ((marker . 3079) . -67) ((marker . 3079) . -67) ((marker . 3079) . -67) ((marker . 3079) . -67) ((marker . 3079) . -67) ((marker . 3026) . -19) ((marker . 62) . -3) 3089 nil (nil rear-nonsticky nil 3362 . 3363) (nil fontified nil 3158 . 3363) (3158 . 3363) nil ("  " . -3158) ((marker . 62) . -2) 3160 (3157 . 3160) (t 26171 461 298222 464000) 3156 nil (88 . 92) (t 26171 453 504540 130000) nil 93 nil (nil rear-nonsticky nil 3147 . 3148) (nil fontified nil 3096 . 3148) (3096 . 3148) nil ("    " . -3096) ((marker . 62) . -4) 3100 (3095 . 3100) 3082 nil ("    math: true,
" . 3096) ((marker . 302) . -15) ((marker* . 45) . 1) ((marker . 3086) . -15) ((marker . 3079) . -3) ((marker . 3079) . -3) ((marker . 3079) . -15) ((marker . 3079) . -15) ((marker . 3079) . -14) ((marker . 3079) . -14) ((marker . 3079) . -15) nil ("
    " . 3111) ((marker . 302) . -1) ((marker . 3079) . -1) ((marker . 3079) . -1) ((marker . 62) . -5) ((marker . 3079) . -1) (3112 . 3116) nil (" config: (md) => {
      md.use(mathjax3);" . 3112) ((marker . 3079) . -14) ((marker . 3079) . -14) (nil fontified t 3130 . 3131) (nil fontified t 3129 . 3130) (nil fontified t 3125 . 3129) (nil fontified t 3124 . 3125) (nil fontified t 3122 . 3124) (nil fontified t 3121 . 3122) (nil fontified t 3113 . 3121) (nil fontified t 3112 . 3113) (nil rear-nonsticky t 3153 . 3154) nil (3096 . 3112) nil ("    " . 3096) (3100 . 3101) ("        " . 3118) (3126 . 3132) nil (3124 . 3126) (3142 . 3144) ("    " . 3142) ("  " . 3150) nil (3150 . 3152) (3142 . 3146) ("  " . 3142) ("  " . -3124) 3094 nil ("      " . -3126) (3118 . 3126) (" " . -3100) (3096 . 3100) 3110 nil ("    math: true,
" . 3096) ((marker . 302) . -16) ((marker . 3086) . -15) ((marker . 3079) . -3) ((marker . 3079) . -3) ((marker . 62) . -14) 3110 nil (nil rear-nonsticky nil 3153 . 3154) (nil fontified nil 3112 . 3154) (3112 . 3154) nil ("    " . -3112) ((marker . 62) . -4) 3116 (3111 . 3116) 3096 nil (" config: (md) => {
      md.use(mathjax3);" . 3117) ((marker . 302) . -41) ((marker . 3086) . -41) ((marker . 62) . -41) ((marker . 3087) . -41) (nil fontified t 3135 . 3136) (nil fontified t 3134 . 3135) (nil fontified t 3130 . 3134) (nil fontified t 3129 . 3130) (nil fontified t 3127 . 3129) (nil fontified t 3126 . 3127) (nil fontified t 3117 . 3126) (nil rear-nonsticky t 3158 . 3159) nil (nil rear-nonsticky nil 3158 . 3159) (nil fontified nil 3117 . 3159) (3117 . 3159) nil ("  " . -3117) ((marker . 62) . -2) 3119 (3116 . 3119) 3113 nil (nil rear-nonsticky nil 167 . 168) (nil fontified nil 88 . 168) (88 . 168) nil (87 . 88) 43 nil (41 . 42) 40 nil (nil rear-nonsticky nil 85 . 86) (nil fontified nil 42 . 86) (42 . 86) nil (41 . 42) (t 26171 217 147270 106000) 1 nil (apply 9 2955 2993 undo--wrap-and-run-primitive-undo 2955 2993 (("// " . 2957) ("// " . 2974) ("// " . 2993) 2808)) nil (apply -9 2955 3002 undo--wrap-and-run-primitive-undo 2955 3002 ((2993 . 2996) (2974 . 2977) (2957 . 2960) 2955)) nil (2988 . 2989) nil (2978 . 2984) ("t" . -2978) ((marker . 302) . -1) ((marker . 311) . -1) ((marker . 62) . -1) 2979 (2973 . 2979) (2969 . 2973) (2970 . 2972) ("    " . 2969) (2969 . 2973) (2968 . 2970) (2957 . 2969) (2955 . 2957) ("  " . 2954) ((marker . 62) . -2) (2953 . 2957) (" " . -2953) ((marker . 62) . -1) 2954 (2952 . 2954) nil ("
    " . 336) ((marker . 302) . -5) ((marker . 3001) . -5) ((marker . 3086) . -5) ((marker . 302) . -5) ((marker . 382) . -5) ((marker . 382) . -5) ((marker . 382) . -5) ((marker . 311) . -5) ((marker . 62) . -5) ((marker . 382) . -5) ((marker . 382) . -5) ("
" . 341) ((marker . 302) . -1) ((marker . 3001) . -1) ((marker . 3086) . -1) ((marker . 302) . -1) ((marker . 382) . -1) ((marker . 382) . -1) ((marker . 382) . -1) ((marker . 311) . -1) ((marker . 62) . -1) ((marker . 382) . -1) ((marker . 382) . -1) (337 . 341) ("    " . 338) ((marker . 302) . -4) ((marker . 3001) . -4) ((marker . 3086) . -4) ((marker . 302) . -4) ((marker . 382) . -4) ((marker . 382) . -4) ((marker . 382) . -4) ((marker . 311) . -4) ((marker . 62) . -4) ((marker . 382) . -4) ((marker . 382) . -4) ("markdown: {}" . 342) ((marker . 302) . -11) ((marker . 3001) . -11) ((marker . 3086) . -11) ((marker . 302) . -12) ((marker . 382) . -12) ((marker . 382) . -12) ((marker . 382) . -12) ((marker . 311) . -12) ((marker . 62) . -11) ((marker . 382) . -11) ((marker . 382) . -11) ("

" . 353) ((marker . 302) . -1) ((marker . 3001) . -1) ((marker . 3086) . -1) ((marker . 62) . -1) ((marker . 382) . -2) ((marker . 382) . -1) ("      " . 354) (354 . 360) ("    " . 355) ((marker . 382) . -4) ("      " . 354) ((marker . 302) . -6) ((marker . 3001) . -6) ((marker . 3086) . -6) ((marker . 62) . -6) ((marker . 382) . -6) ("math:t" . 360) ((marker . 302) . -5) ((marker . 3001) . -5) ((marker . 3086) . -5) ((marker . 62) . -6) ((marker . 382) . -5) (365 . 366) (" true;" . 365) ((marker . 302) . -5) ((marker . 3001) . -5) ((marker . 3086) . -5) ((marker . 62) . -5) ((marker . 382) . -5) nil (370 . 371) ("," . 370) nil ("," . 377) (t 26170 64972 451681 422000) nil (377 . 378) nil (370 . 371) (";" . 370) nil (365 . 371) ("t" . -365) ((marker . 302) . -1) ((marker . 311) . -1) ((marker . 62) . -1) 366 (360 . 366) (354 . 360) (355 . 359) ("      " . 354) (354 . 360) (353 . 355) (342 . 354) (338 . 342) ("    " . 337) ((marker . 62) . -4) (341 . 342) (336 . 341) (t 26170 64749 477830 392000) 327 nil (2832 . 2841) ("." . -2832) ((marker . 62) . -1) 2833 (2817 . 2833) ("/spl/misc" . 2817) ((marker . 3086) . -8) ((marker . 62) . -1) 2818 nil (2795 . 2799) ("Miscellaneous" . 2795) ((marker . 3086) . -12) ((marker . 62) . -1) 2796 nil ("            " . -2819) (2811 . 2819) ("            " . -2788) (2780 . 2788) 2795 nil (nil rear-nonsticky nil 2791 . 2792) ("
" . -2845) (2779 . 2846) 2778 nil ("        " . 2779) ("
" . -2779) 2778 nil (2796 . 2797) nil (2780 . 2788) (2781 . 2787) ("        " . 2780) (2780 . 2788) (2779 . 2781) (2778 . 2780) (2771 . 2778) (t 26165 17777 375819 128000) 2769 nil ("a" . 2413) (2414 . 2415) 2413 ("f" . 2412) (2413 . 2414) 2412 nil (" " . 2387) nil (" " . 2387) nil (2379 . 2385) ("Fall" . 2379) nil (nil rear-nonsticky nil 2366 . 2367) ("
" . -2418) (2352 . 2419) 2287 (t 26165 6017 283575 243000)) (emacs-undo-equiv-table (-8 . -24) (-9 . -23) (-10 . -22) (-11 . -19) (-12 . -16) (-13 . -15) (-1 . -3) (22 . 38) (31 . 37) (21 . 39) (-29 . -39) (32 . 36) (20 . 40) (-47 . -49) (-33 . -35) (4 . 6) (33 . 35) (24 . 28) (9 . 11) (11 . 13) (-31 . -37) (73 . 75) (60 . 70) (64 . 66) (-16 . -18) (61 . 69) (55 . 59) (23 . 29) (-32 . -36) (62 . 68) (82 . 84) (-39 . -41) (-30 . -38) (-19 . -21) (63 . 67) (-51 . -57) (-53 . -55) (56 . 58) (-52 . -56) (25 . 27) (29 . 31)))